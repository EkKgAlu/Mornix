package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.calendar.EnglishDate
import com.example.data.calendar.FestivalCategory
import com.example.data.calendar.HolidayScope
import com.example.data.calendar.NepaliDate
import com.example.data.calendar.NepaliDateConverter
import com.example.data.calendar.NepaliFestival
import com.example.data.calendar.NepaliFestivalData
import com.example.ui.theme.AmberGoldPrimary
import com.example.ui.theme.CoralWarning
import com.example.ui.theme.EmeraldLive
import java.time.temporal.ChronoUnit

@Composable
fun UpcomingEventsAndHolidaysView(
    todayBs: NepaliDate,
    todayAd: EnglishDate,
    isTablet: Boolean,
    onNavigateToDate: (NepaliDate) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedFilter by remember { mutableStateOf("ALL") } // "ALL", "HOLIDAYS", "FESTIVALS"

    val nextMajor = remember(todayBs) { NepaliFestivalData.getNextMajorFestival(todayBs) }
    val todayOccasions = remember(todayBs) { NepaliFestivalData.getTodaySpecialOccasions(todayBs) }
    val allUpcoming = remember(todayBs) { NepaliFestivalData.getUpcomingFestivals(todayBs, limit = 40) }

    val filteredList = remember(selectedFilter, allUpcoming) {
        when (selectedFilter) {
            "HOLIDAYS" -> allUpcoming.filter { it.isPublicHoliday }
            "FESTIVALS" -> allUpcoming.filter { !it.isPublicHoliday }
            else -> allUpcoming
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("upcoming_events_list")
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Spacer(modifier = Modifier.height(4.dp)) }

        // 1. Next Major Festival Hero Card
        if (nextMajor != null) {
            item {
                val fest = nextMajor.first
                val daysRemain = nextMajor.second
                val festAd = NepaliDateConverter.bsToAd(fest.bsDate)

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("next_major_festival_hero_card"),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                    ),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.primary.copy(alpha = 0.4f))
                    )
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(AmberGoldPrimary),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Star,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "NEXT MAJOR FESTIVAL",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.sp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = if (daysRemain == 0L) "🎉 Happening Today!" else "In $daysRemain day(s)",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (daysRemain == 0L) EmeraldLive else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }

                            if (fest.isPublicHoliday) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = CoralWarning.copy(alpha = 0.15f),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, CoralWarning)
                                ) {
                                    Text(
                                        text = "PUBLIC HOLIDAY",
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = CoralWarning
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = fest.nameNe,
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = fest.nameEn,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "Date: ${fest.bsDate.formattedNe} (${fest.bsDate.formattedEn}) • ${festAd.formatted}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = fest.description,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = { onNavigateToDate(fest.bsDate) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("view_next_festival_in_calendar_btn"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("View in Monthly Calendar")
                        }
                    }
                }
            }
        }

        // 2. Today's Special Occasions (if any today)
        if (todayOccasions.isNotEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("today_occasions_card"),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = EmeraldLive.copy(alpha = 0.1f)
                    ),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = androidx.compose.ui.graphics.SolidColor(EmeraldLive.copy(alpha = 0.4f))
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "✨", fontSize = 18.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Today's Festivals & Occasions (आजको चाडपर्व)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        todayOccasions.forEach { ev ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${ev.nameNe} (${ev.nameEn})",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = ev.description,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                if (ev.isPublicHoliday) {
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = CoralWarning
                                    ) {
                                        Text(
                                            text = "HOLIDAY",
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 3. Filter Chips
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = (selectedFilter == "ALL"),
                    onClick = { selectedFilter = "ALL" },
                    label = { Text("All (${allUpcoming.size})", fontSize = 12.sp) },
                    modifier = Modifier.weight(1f).testTag("filter_all_events")
                )
                FilterChip(
                    selected = (selectedFilter == "HOLIDAYS"),
                    onClick = { selectedFilter = "HOLIDAYS" },
                    label = { Text("Public Holidays", fontSize = 12.sp) },
                    modifier = Modifier.weight(1.2f).testTag("filter_holidays_only")
                )
                FilterChip(
                    selected = (selectedFilter == "FESTIVALS"),
                    onClick = { selectedFilter = "FESTIVALS" },
                    label = { Text("Cultural Only", fontSize = 12.sp) },
                    modifier = Modifier.weight(1f).testTag("filter_festivals_only")
                )
            }
        }

        // 4. Upcoming Events List
        items(filteredList, key = { it.id }) { fest ->
            val festAd = remember(fest.bsDate) { NepaliDateConverter.bsToAd(fest.bsDate) }
            val daysRemain = remember(festAd, todayAd) {
                val diff = ChronoUnit.DAYS.between(todayAd.toLocalDate(), festAd.toLocalDate())
                maxOf(0L, diff)
            }

            FestivalEventItemCard(
                festival = fest,
                adDate = festAd,
                daysRemaining = daysRemain,
                onViewInCalendar = { onNavigateToDate(fest.bsDate) }
            )
        }

        item { Spacer(modifier = Modifier.height(28.dp)) }
    }
}

@Composable
fun FestivalEventItemCard(
    festival: NepaliFestival,
    adDate: EnglishDate,
    daysRemaining: Long,
    onViewInCalendar: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("festival_item_${festival.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Top Row: Countdown Pill + Scope & Holiday Tag
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = when {
                        daysRemaining == 0L -> EmeraldLive.copy(alpha = 0.15f)
                        daysRemaining <= 7L -> AmberGoldPrimary.copy(alpha = 0.15f)
                        else -> MaterialTheme.colorScheme.surfaceVariant
                    }
                ) {
                    Text(
                        text = when (daysRemaining) {
                            0L -> "✨ Today"
                            1L -> "Tomorrow"
                            else -> "In $daysRemaining days"
                        },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = when {
                            daysRemaining == 0L -> EmeraldLive
                            daysRemaining <= 7L -> AmberGoldPrimary
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (festival.isPublicHoliday) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = CoralWarning.copy(alpha = 0.15f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, CoralWarning)
                        ) {
                            Text(
                                text = "PUBLIC HOLIDAY",
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = CoralWarning
                            )
                        }
                    }

                    if (festival.holidayScope == HolidayScope.KATHMANDU_VALLEY) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Text(
                                text = "Valley",
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else if (festival.holidayScope == HolidayScope.WOMEN_ONLY) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                        ) {
                            Text(
                                text = "Women Only",
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Nepali & English Names
            Text(
                text = festival.nameNe,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = festival.nameEn,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Date line
            Text(
                text = "${festival.bsDate.formattedEn}  •  ${adDate.formatted}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Description
            Text(
                text = festival.description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface,
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Cultural significance
            Text(
                text = "Significance: ${festival.significance}",
                style = MaterialTheme.typography.bodySmall,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
            Spacer(modifier = Modifier.height(6.dp))

            // Bottom Actions Row: Source + Jump to Calendar Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (festival.isProvisional) "Provisional Notice" else "Official MoHA Gazette",
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.outline
                )

                OutlinedButton(
                    onClick = onViewInCalendar,
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("jump_to_calendar_${festival.id}")
                ) {
                    Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("View in Calendar", fontSize = 11.sp)
                }
            }
        }
    }
}
