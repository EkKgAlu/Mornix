package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.ui.res.painterResource
import com.example.R
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CurrencyExchange
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.automirrored.filled.ShowChart
import androidx.compose.material.icons.filled.Cake
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CurrencyBitcoin
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material.icons.filled.Event
import androidx.compose.material3.OutlinedButton
import com.example.data.calendar.NepaliDateConverter
import com.example.data.calendar.NepaliDateUtils
import com.example.data.calendar.NepaliFestivalData
import com.example.data.model.BibleVerse
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import android.view.HapticFeedbackConstants
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DisasterAlert
import com.example.data.model.ForexRateItem
import com.example.data.model.FreshnessStatus
import com.example.data.model.GoldSilverRates
import com.example.data.model.MarketQuote
import com.example.data.model.MorningBriefing
import com.example.data.model.NewsArticle
import com.example.data.model.TemperatureUnit
import com.example.data.model.WeatherInfo
import com.example.ui.components.FreshnessBadge
import com.example.ui.components.MiniSparkline
import com.example.ui.components.SectionHeader
import com.example.ui.theme.AmberGoldLight
import com.example.ui.theme.AmberGoldPrimary
import com.example.ui.theme.CoralWarning
import com.example.ui.theme.EmeraldLive
import com.example.ui.viewmodel.MornixViewModel
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: MornixViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val briefing by viewModel.briefing.collectAsState()
    val bullion by viewModel.bullionRates.collectAsState()
    val forexList by viewModel.forexRates.collectAsState()
    val weather by viewModel.weather.collectAsState()
    val newsList by viewModel.allNews.collectAsState()
    val markets by viewModel.markets.collectAsState()
    val alerts by viewModel.alerts.collectAsState()
    val userPrefs by viewModel.userPreferences.collectAsState()
    val isRefreshing by viewModel.isRefreshing.collectAsState()

    val isPlayingTts by viewModel.isPlayingTts.collectAsState()
    val isPausedTts by viewModel.isPausedTts.collectAsState()
    val speechRate by viewModel.speechRate.collectAsState()

    var isDisasterDismissed by remember { mutableStateOf(false) }

    // Prioritize verified Nepal & local news articles first
    val preferredNewsList = remember(newsList) {
        val (local, international) = newsList.partition { article ->
            article.category.equals("Nepal News", ignoreCase = true) ||
            article.sourceName.contains("OnlineKhabar", ignoreCase = true) ||
            article.sourceName.contains("Kathmandu", ignoreCase = true) ||
            article.sourceName.contains("Nepali Times", ignoreCase = true) ||
            article.sourceName.contains("Setopati", ignoreCase = true) ||
            article.sourceName.contains("Ratopati", ignoreCase = true) ||
            article.sourceName.contains("Himalayan", ignoreCase = true)
        }
        local + international
    }

    val haptic = LocalHapticFeedback.current
    val view = LocalView.current
    val pullToRefreshState = rememberPullToRefreshState()
    var hasTriggeredPullThresholdHaptic by remember { mutableStateOf(false) }

    LaunchedEffect(pullToRefreshState.distanceFraction, isRefreshing) {
        if (isRefreshing || pullToRefreshState.distanceFraction < 0.2f) {
            hasTriggeredPullThresholdHaptic = false
        } else if (pullToRefreshState.distanceFraction >= 1f && !hasTriggeredPullThresholdHaptic) {
            hasTriggeredPullThresholdHaptic = true
            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        }
    }

    PullToRefreshBox(
        isRefreshing = isRefreshing,
        onRefresh = {
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            viewModel.refreshAll()
        },
        state = pullToRefreshState,
        modifier = modifier
            .fillMaxSize()
            .testTag("home_swipe_refresh")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            AnimatedVisibility(visible = isRefreshing) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f))
                        .testTag("home_syncing_banner")
                ) {
                    LinearProgressIndicator(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(2.dp),
                        color = MaterialTheme.colorScheme.primary
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Syncing latest news, weather & market rates...",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                val isTablet = maxWidth >= 700.dp

                if (isTablet) {
                    // Adaptive Tablet 2-Column Dashboard Layout
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                    .testTag("home_screen_tablet_row")
                    .padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                val activeWidgets = userPrefs.widgetOrder.filter { userPrefs.enabledWidgets.contains(it) }
                val halfCount = (activeWidgets.size + 1) / 2
                val leftWidgets = activeWidgets.take(halfCount)
                val rightWidgets = activeWidgets.drop(halfCount)

                // Left Column: Disaster Banner + First Half of Reordered Widgets
                LazyColumn(
                    modifier = Modifier
                        .weight(1.15f)
                        .fillMaxHeight()
                        .testTag("home_tablet_left_column"),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item { Spacer(modifier = Modifier.height(4.dp)) }

                    // Top Natural Disaster & Hazard Notification Banner
                    if (alerts.isNotEmpty() && !isDisasterDismissed) {
                        item {
                            HomeDisasterTopBanner(
                                alerts = alerts,
                                onViewAlertDetails = { viewModel.selectTab(1) },
                                onDismiss = { isDisasterDismissed = true }
                            )
                        }
                    }

                    if (userPrefs.dailyBibleVerseEnabled) {
                        item {
                            val verse = briefing?.bibleVerse ?: viewModel.getTodayBibleVerse()
                            DailyBibleVerseCard(
                                verse = verse,
                                onShare = {
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_SUBJECT, "Daily Scripture: ${verse.reference}")
                                        putExtra(Intent.EXTRA_TEXT, "\"${verse.text}\"\n— ${verse.reference} (${verse.translation})\nShared via Mornix")
                                    }
                                    try {
                                        context.startActivity(Intent.createChooser(shareIntent, "Share Scripture"))
                                    } catch (_: Exception) {}
                                }
                            )
                        }
                    }

                    leftWidgets.forEach { widgetId ->
                        when (widgetId) {
                            "briefing" -> {
                                item {
                                    MorningBriefingCard(
                                        briefing = briefing,
                                        isPlayingTts = isPlayingTts,
                                        isPausedTts = isPausedTts,
                                        speechRate = speechRate,
                                        showUpcomingEvents = userPrefs.showUpcomingEventsInBriefing,
                                        onToggleUpcomingEvents = { viewModel.toggleShowUpcomingEventsInBriefing(it) },
                                        onPlay = { viewModel.playBriefing() },
                                        onPause = { viewModel.pauseBriefing() },
                                        onResume = { viewModel.resumeBriefing() },
                                        onStop = { viewModel.stopBriefing() },
                                        onSpeedChange = { viewModel.setTtsSpeed(it) },
                                        onOpenChat = { viewModel.selectTab(5) }
                                    )
                                }
                            }
                            "calendar" -> {
                                item {
                                    HomeCalendarWidgetCard(
                                        onOpenCalendar = {
                                            viewModel.selectTab(3)
                                            viewModel.selectCalendarSubTab(0)
                                        },
                                        onOpenFestivals = {
                                            viewModel.selectTab(3)
                                            viewModel.selectCalendarSubTab(1)
                                        },
                                        onOpenConverter = {
                                            viewModel.selectTab(3)
                                            viewModel.selectCalendarSubTab(2)
                                        },
                                        onOpenAgeCalc = {
                                            viewModel.selectTab(3)
                                            viewModel.selectCalendarSubTab(3)
                                        }
                                    )
                                }
                            }
                            "breaking_news" -> {
                                item {
                                    SectionHeader(
                                        title = "Today's Verified News",
                                        subtitle = "Nepal & local news prioritized • Official publishers",
                                        icon = Icons.Default.Newspaper,
                                        actionLabel = "View All",
                                        onActionClick = { viewModel.selectTab(1) }
                                    )
                                }
                                val topArticles = preferredNewsList.take(6)
                                items(topArticles, key = { it.id }) { article ->
                                    NewsArticleCard(
                                        article = article,
                                        onToggleBookmark = { viewModel.toggleBookmark(article.id) },
                                        onOpenUrl = {
                                            if (article.sourceUrl.isNotBlank()) {
                                                try {
                                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(article.sourceUrl))
                                                    context.startActivity(intent)
                                                } catch (_: Exception) {}
                                            }
                                        }
                                    )
                                }
                            }
                            "gold_silver" -> {
                                item {
                                    NepalBullionCard(
                                        bullion = bullion,
                                        onNavigateToCalculator = {
                                            viewModel.selectTab(2)
                                            viewModel.selectMarketsSubTab(3)
                                        }
                                    )
                                }
                            }
                            "forex" -> {
                                item {
                                    ForexOverviewCard(
                                        forexList = forexList,
                                        favoriteCodes = userPrefs.favoriteCurrencies,
                                        onToggleFavorite = { viewModel.toggleFavoriteCurrency(it) },
                                        onNavigateToConverter = {
                                            viewModel.selectTab(2)
                                            viewModel.selectMarketsSubTab(2)
                                        }
                                    )
                                }
                            }
                            "weather" -> {
                                item {
                                    WeatherCard(
                                        weather = weather,
                                        tempUnit = userPrefs.temperatureUnit,
                                        onViewFullForecast = { viewModel.selectTab(4) }
                                    )
                                }
                            }
                            "crypto" -> {
                                item {
                                    CryptoPricesCard(
                                        markets = markets,
                                        onViewAllMarkets = {
                                            viewModel.selectTab(2)
                                            viewModel.selectMarketsSubTab(4)
                                        }
                                    )
                                }
                            }
                            "markets" -> {
                                item {
                                    MarketsOverviewCard(
                                        markets = markets,
                                        onToggleFavorite = { viewModel.toggleFavoriteMarket(it) },
                                        onViewAllMarkets = {
                                            viewModel.selectTab(2)
                                            viewModel.selectMarketsSubTab(4)
                                        }
                                    )
                                }
                            }
                            "alerts" -> {
                                if (alerts.isNotEmpty()) {
                                    item {
                                        DisasterAlertsCard(
                                            alerts = alerts,
                                            onViewAllAlerts = { viewModel.selectTab(1) }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    item { Spacer(modifier = Modifier.height(24.dp)) }
                }

                // Right Column: Second Half of Reordered Widgets
                LazyColumn(
                    modifier = Modifier
                        .weight(0.85f)
                        .fillMaxHeight()
                        .testTag("home_tablet_right_column"),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item { Spacer(modifier = Modifier.height(4.dp)) }

                    rightWidgets.forEach { widgetId ->
                        when (widgetId) {
                            "briefing" -> {
                                item {
                                    MorningBriefingCard(
                                        briefing = briefing,
                                        isPlayingTts = isPlayingTts,
                                        isPausedTts = isPausedTts,
                                        speechRate = speechRate,
                                        showUpcomingEvents = userPrefs.showUpcomingEventsInBriefing,
                                        onToggleUpcomingEvents = { viewModel.toggleShowUpcomingEventsInBriefing(it) },
                                        onPlay = { viewModel.playBriefing() },
                                        onPause = { viewModel.pauseBriefing() },
                                        onResume = { viewModel.resumeBriefing() },
                                        onStop = { viewModel.stopBriefing() },
                                        onSpeedChange = { viewModel.setTtsSpeed(it) },
                                        onOpenChat = { viewModel.selectTab(5) }
                                    )
                                }
                            }
                            "calendar" -> {
                                item {
                                    HomeCalendarWidgetCard(
                                        onOpenCalendar = {
                                            viewModel.selectTab(3)
                                            viewModel.selectCalendarSubTab(0)
                                        },
                                        onOpenFestivals = {
                                            viewModel.selectTab(3)
                                            viewModel.selectCalendarSubTab(1)
                                        },
                                        onOpenConverter = {
                                            viewModel.selectTab(3)
                                            viewModel.selectCalendarSubTab(2)
                                        },
                                        onOpenAgeCalc = {
                                            viewModel.selectTab(3)
                                            viewModel.selectCalendarSubTab(3)
                                        }
                                    )
                                }
                            }
                            "weather" -> {
                                item {
                                    WeatherCard(
                                        weather = weather,
                                        tempUnit = userPrefs.temperatureUnit,
                                        onViewFullForecast = { viewModel.selectTab(4) }
                                    )
                                }
                            }
                            "gold_silver" -> {
                                item {
                                    NepalBullionCard(
                                        bullion = bullion,
                                        onNavigateToCalculator = {
                                            viewModel.selectTab(2)
                                            viewModel.selectMarketsSubTab(3)
                                        }
                                    )
                                }
                            }
                            "forex" -> {
                                item {
                                    ForexOverviewCard(
                                        forexList = forexList,
                                        favoriteCodes = userPrefs.favoriteCurrencies,
                                        onToggleFavorite = { viewModel.toggleFavoriteCurrency(it) },
                                        onNavigateToConverter = {
                                            viewModel.selectTab(2)
                                            viewModel.selectMarketsSubTab(2)
                                        }
                                    )
                                }
                            }
                            "crypto" -> {
                                item {
                                    CryptoPricesCard(
                                        markets = markets,
                                        onViewAllMarkets = {
                                            viewModel.selectTab(2)
                                            viewModel.selectMarketsSubTab(4)
                                        }
                                    )
                                }
                            }
                            "alerts" -> {
                                if (alerts.isNotEmpty()) {
                                    item {
                                        DisasterAlertsCard(
                                            alerts = alerts,
                                            onViewAllAlerts = { viewModel.selectTab(1) }
                                        )
                                    }
                                }
                            }
                            "markets" -> {
                                item {
                                    MarketsOverviewCard(
                                        markets = markets,
                                        onToggleFavorite = { viewModel.toggleFavoriteMarket(it) },
                                        onViewAllMarkets = {
                                            viewModel.selectTab(2)
                                            viewModel.selectMarketsSubTab(4)
                                        }
                                    )
                                }
                            }
                            "breaking_news" -> {
                                item {
                                    SectionHeader(
                                        title = "Today's Verified News",
                                        subtitle = "Nepal & local news prioritized • Official publishers",
                                        icon = Icons.Default.Newspaper,
                                        actionLabel = "View All",
                                        onActionClick = { viewModel.selectTab(1) }
                                    )
                                }
                                val topArticles = preferredNewsList.take(4)
                                items(topArticles, key = { it.id }) { article ->
                                    NewsArticleCard(
                                        article = article,
                                        onToggleBookmark = { viewModel.toggleBookmark(article.id) },
                                        onOpenUrl = {
                                            if (article.sourceUrl.isNotBlank()) {
                                                try {
                                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(article.sourceUrl))
                                                    context.startActivity(intent)
                                                } catch (_: Exception) {}
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }

                    item {
                        OutlinedButton(
                            onClick = { viewModel.selectTab(6) },
                            modifier = Modifier.fillMaxWidth().testTag("tablet_rearrange_widgets_btn")
                        ) {
                            Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Rearrange Widgets", fontSize = 12.sp)
                        }
                    }

                    item { Spacer(modifier = Modifier.height(24.dp)) }
                }
            }
        } else {
            // Standard Phone Single Column Layout - Iterates through widgetOrder
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("home_screen_lazy_column")
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item { Spacer(modifier = Modifier.height(4.dp)) }

                // Top Natural Disaster Alert Notification Banner
                if (alerts.isNotEmpty() && !isDisasterDismissed) {
                    item {
                        HomeDisasterTopBanner(
                            alerts = alerts,
                            onViewAlertDetails = { viewModel.selectTab(1) },
                            onDismiss = { isDisasterDismissed = true }
                        )
                    }
                }

                if (userPrefs.dailyBibleVerseEnabled) {
                    item {
                        val verse = briefing?.bibleVerse ?: viewModel.getTodayBibleVerse()
                        DailyBibleVerseCard(
                            verse = verse,
                            onShare = {
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_SUBJECT, "Daily Scripture: ${verse.reference}")
                                    putExtra(Intent.EXTRA_TEXT, "\"${verse.text}\"\n— ${verse.reference} (${verse.translation})\nShared via Mornix")
                                }
                                try {
                                    context.startActivity(Intent.createChooser(shareIntent, "Share Scripture"))
                                } catch (_: Exception) {}
                            }
                        )
                    }
                }

                // Render widgets strictly according to user's custom widgetOrder
                userPrefs.widgetOrder.forEach { widgetId ->
                    if (userPrefs.enabledWidgets.contains(widgetId)) {
                        when (widgetId) {
                            "briefing" -> {
                                item {
                                    MorningBriefingCard(
                                        briefing = briefing,
                                        isPlayingTts = isPlayingTts,
                                        isPausedTts = isPausedTts,
                                        speechRate = speechRate,
                                        showUpcomingEvents = userPrefs.showUpcomingEventsInBriefing,
                                        onToggleUpcomingEvents = { viewModel.toggleShowUpcomingEventsInBriefing(it) },
                                        onPlay = { viewModel.playBriefing() },
                                        onPause = { viewModel.pauseBriefing() },
                                        onResume = { viewModel.resumeBriefing() },
                                        onStop = { viewModel.stopBriefing() },
                                        onSpeedChange = { viewModel.setTtsSpeed(it) },
                                        onOpenChat = { viewModel.selectTab(5) }
                                    )
                                }
                            }
                            "calendar" -> {
                                item {
                                    HomeCalendarWidgetCard(
                                        onOpenCalendar = {
                                            viewModel.selectTab(3)
                                            viewModel.selectCalendarSubTab(0)
                                        },
                                        onOpenFestivals = {
                                            viewModel.selectTab(3)
                                            viewModel.selectCalendarSubTab(1)
                                        },
                                        onOpenConverter = {
                                            viewModel.selectTab(3)
                                            viewModel.selectCalendarSubTab(2)
                                        },
                                        onOpenAgeCalc = {
                                            viewModel.selectTab(3)
                                            viewModel.selectCalendarSubTab(3)
                                        }
                                    )
                                }
                            }
                            "gold_silver" -> {
                                item {
                                    NepalBullionCard(
                                        bullion = bullion,
                                        onNavigateToCalculator = {
                                            viewModel.selectTab(2) // Markets tab
                                            viewModel.selectMarketsSubTab(3) // Calculator
                                        }
                                    )
                                }
                            }
                            "forex" -> {
                                item {
                                    ForexOverviewCard(
                                        forexList = forexList,
                                        favoriteCodes = userPrefs.favoriteCurrencies,
                                        onToggleFavorite = { viewModel.toggleFavoriteCurrency(it) },
                                        onNavigateToConverter = {
                                            viewModel.selectTab(2) // Markets tab
                                            viewModel.selectMarketsSubTab(2) // Converter
                                        }
                                    )
                                }
                            }
                            "weather" -> {
                                item {
                                    WeatherCard(
                                        weather = weather,
                                        tempUnit = userPrefs.temperatureUnit,
                                        onViewFullForecast = {
                                            viewModel.selectTab(4) // Weather tab
                                        }
                                    )
                                }
                            }
                            "crypto" -> {
                                item {
                                    CryptoPricesCard(
                                        markets = markets,
                                        onViewAllMarkets = {
                                            viewModel.selectTab(2)
                                            viewModel.selectMarketsSubTab(4)
                                        }
                                    )
                                }
                            }
                            "alerts" -> {
                                if (alerts.isNotEmpty()) {
                                    item {
                                        DisasterAlertsCard(
                                            alerts = alerts,
                                            onViewAllAlerts = { viewModel.selectTab(1) }
                                        )
                                    }
                                }
                            }
                            "markets" -> {
                                item {
                                    MarketsOverviewCard(
                                        markets = markets,
                                        onToggleFavorite = { viewModel.toggleFavoriteMarket(it) },
                                        onViewAllMarkets = {
                                            viewModel.selectTab(2)
                                            viewModel.selectMarketsSubTab(4) // International
                                        }
                                    )
                                }
                            }
                            "breaking_news" -> {
                                item {
                                    SectionHeader(
                                        title = "Today's Verified News",
                                        subtitle = "Nepal & local news prioritized • Official publishers",
                                        icon = Icons.Default.Newspaper,
                                        actionLabel = "View All",
                                        onActionClick = { viewModel.selectTab(1) } // News tab
                                    )
                                }

                                val topArticles = preferredNewsList.take(4)
                                items(topArticles, key = { it.id }) { article ->
                                    NewsArticleCard(
                                        article = article,
                                        onToggleBookmark = { viewModel.toggleBookmark(article.id) },
                                        onOpenUrl = {
                                            if (article.sourceUrl.isNotBlank()) {
                                                try {
                                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(article.sourceUrl))
                                                    context.startActivity(intent)
                                                } catch (_: Exception) {}
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                // Quick Customize Widgets Button
                item {
                    OutlinedButton(
                        onClick = { viewModel.selectTab(6) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .testTag("rearrange_dashboard_widgets_btn")
                    ) {
                        Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Customize & Rearrange Widgets", fontSize = 12.sp)
                    }
                }

                item { Spacer(modifier = Modifier.height(24.dp)) }
            }
        }
            }
        }
    }
}

fun formatDailyBriefingShareText(
    briefing: MorningBriefing?,
    bsDate: com.example.data.calendar.NepaliDate = NepaliDateConverter.todayBs(),
    adDate: com.example.data.calendar.EnglishDate = NepaliDateConverter.todayAd()
): String {
    val dow = NepaliDateConverter.getDayOfWeek(bsDate)
    val weekdayNe = NepaliDateUtils.WEEKDAYS_FULL_NE[dow.value % 7]
    val weekdayEn = NepaliDateUtils.WEEKDAYS_FULL_EN[dow.value % 7]

    return buildString {
        appendLine("☀️ ${briefing?.greeting ?: "Good Morning"} • Mornix Daily Briefing")
        appendLine("📅 ${bsDate.formattedNe} • ${adDate.formatted} ($weekdayNe / $weekdayEn)")
        appendLine()
        val summary = briefing?.executiveSummary?.takeIf { it.isNotBlank() }
            ?: "Today's verified Nepal & global morning intelligence report."
        appendLine(summary)

        val highlights = briefing?.newsHighlights?.filter { it.isNotBlank() }.orEmpty()
        if (highlights.isNotEmpty()) {
            appendLine()
            appendLine("📰 Top Highlights:")
            highlights.take(5).forEach { item ->
                appendLine("• $item")
            }
        }

        if (!briefing?.goldForexSnippet.isNullOrBlank()) {
            appendLine()
            appendLine("📊 Markets: ${briefing?.goldForexSnippet}")
        }
        if (!briefing?.weatherSnippet.isNullOrBlank()) {
            appendLine("🌤️ Weather: ${briefing?.weatherSnippet}")
        }
        briefing?.bibleVerse?.let { verse ->
            if (verse.text.isNotBlank()) {
                appendLine()
                appendLine("📖 Daily Scripture: \"${verse.text}\" — ${verse.reference} (${verse.translation})")
            }
        }
        appendLine()
        append("Shared via Mornix • Daily Intelligence")
    }
}

@Composable
fun MorningBriefingCard(
    briefing: MorningBriefing?,
    isPlayingTts: Boolean,
    isPausedTts: Boolean,
    speechRate: Float,
    showUpcomingEvents: Boolean = true,
    onToggleUpcomingEvents: (Boolean) -> Unit = {},
    onPlay: () -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onStop: () -> Unit,
    onSpeedChange: (Float) -> Unit,
    onOpenChat: () -> Unit
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val view = LocalView.current
    var showMore by remember { mutableStateOf(false) }

    val todayAd = remember { NepaliDateConverter.todayAd() }
    val todayBs = remember { NepaliDateConverter.todayBs() }
    val dayOfWeek = remember { NepaliDateConverter.getDayOfWeek(todayBs) }
    val weekdayNe = NepaliDateUtils.WEEKDAYS_FULL_NE[dayOfWeek.value % 7]
    val weekdayEn = NepaliDateUtils.WEEKDAYS_FULL_EN[dayOfWeek.value % 7]
    val upcomingEvents = remember(todayBs) {
        NepaliFestivalData.getUpcomingFestivals(todayBs, limit = 3)
    }

    val shareBriefingAction = {
        val shareText = formatDailyBriefingShareText(
            briefing = briefing,
            bsDate = todayBs,
            adDate = todayAd
        )
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Mornix Daily Briefing • ${todayAd.formatted}")
            putExtra(Intent.EXTRA_TEXT, shareText)
        }
        try {
            context.startActivity(Intent.createChooser(sendIntent, "Share Daily Briefing"))
        } catch (_: Exception) {}
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("morning_briefing_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
        ),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.primary.copy(alpha = 0.25f))
        )
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(id = R.drawable.mornix_logo),
                        contentDescription = "Mornix",
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = briefing?.greeting ?: "Good Morning",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Made with AI by Resham",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { shareBriefingAction() }
                            .testTag("briefing_share_button"),
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
                        border = CardDefaults.outlinedCardBorder()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = "Share Daily Briefing",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Share",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    FreshnessBadge(
                        status = if (briefing?.isOfflineCached == true) FreshnessStatus.STALE else FreshnessStatus.LIVE,
                        sourceName = if (briefing?.isOfflineCached == true) "Offline Cache" else "Synthesized"
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Current Nepali (BS) & English (AD) Date + Option to Enable/Disable Upcoming Events
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("briefing_date_section"),
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CalendarMonth,
                                    contentDescription = "Current Date",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "${todayBs.formattedNe} • ${todayAd.formatted}",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "$weekdayNe ($weekdayEn)",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        // Toggle chip to enable/disable Upcoming Events from Calendar (Down arrow when OFF, Up arrow when ON)
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                                    onToggleUpcomingEvents(!showUpcomingEvents)
                                }
                                .testTag("briefing_upcoming_events_toggle"),
                            color = if (showUpcomingEvents) {
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
                            },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Event,
                                    contentDescription = null,
                                    tint = if (showUpcomingEvents) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Events",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (showUpcomingEvents) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.width(2.dp))
                                Icon(
                                    imageVector = if (showUpcomingEvents) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                    contentDescription = if (showUpcomingEvents) "Collapse Upcoming Events" else "Expand Upcoming Events",
                                    tint = if (showUpcomingEvents) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier
                                        .size(15.dp)
                                        .testTag("briefing_upcoming_events_arrow")
                                )
                            }
                        }
                    }

                    // Upcoming Events from Calendar (shown when enabled)
                    AnimatedVisibility(visible = showUpcomingEvents && upcomingEvents.isNotEmpty()) {
                        Column(modifier = Modifier.padding(top = 10.dp)) {
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Upcoming Calendar Events",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                upcomingEvents.forEach { fest ->
                                    val eventAd = NepaliDateConverter.bsToAd(fest.bsDate)
                                    val daysRemain = java.time.temporal.ChronoUnit.DAYS.between(
                                        todayAd.toLocalDate(),
                                        eventAd.toLocalDate()
                                    ).coerceAtLeast(0L)
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(7.dp)
                                                    .clip(CircleShape)
                                                    .background(
                                                        if (fest.isPublicHoliday) CoralWarning else AmberGoldPrimary
                                                    )
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column {
                                                Text(
                                                    text = "${fest.nameNe} (${fest.nameEn})",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    fontWeight = FontWeight.SemiBold,
                                                    color = if (fest.isPublicHoliday) CoralWarning else MaterialTheme.colorScheme.onSurface
                                                )
                                                Text(
                                                    text = "${fest.bsDate.formattedEn} • ${eventAd.formatted}",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontSize = 10.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }

                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(
                                                    if (daysRemain == 0L) CoralWarning.copy(alpha = 0.15f)
                                                    else MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                                                )
                                                .padding(horizontal = 6.dp, vertical = 3.dp)
                                        ) {
                                            Text(
                                                text = if (daysRemain == 0L) "Today" else "In ${daysRemain}d",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (daysRemain == 0L) CoralWarning else MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Audio Player Controls (Prominent clean Play control)
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = {
                                when {
                                    isPlayingTts -> onPause()
                                    isPausedTts -> onResume()
                                    else -> onPlay()
                                }
                            },
                            modifier = Modifier
                                .testTag("tts_main_play_button")
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(
                                imageVector = if (isPlayingTts) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isPlayingTts) "Pause" else "Play Briefing",
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        if (isPlayingTts || isPausedTts) {
                            Spacer(modifier = Modifier.width(8.dp))
                            IconButton(
                                onClick = onStop,
                                modifier = Modifier
                                    .testTag("tts_stop_button")
                                    .size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Stop,
                                    contentDescription = "Stop Briefing",
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = if (isPlayingTts) "Reading Briefing..." else if (isPausedTts) "Paused" else "Listen to Briefing",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Natural Voice TTS",
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // Speed Pill Selector
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        listOf(0.75f, 1.0f, 1.25f, 1.5f).forEach { speed ->
                            val isSelected = (speechRate == speed)
                            Box(
                                modifier = Modifier
                                    .padding(horizontal = 2.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                                    .clickable { onSpeedChange(speed) }
                                    .padding(horizontal = 6.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "${speed}x",
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Clean Show more / Show less toggle button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { showMore = !showMore }
                    .padding(vertical = 4.dp)
                    .testTag("briefing_show_more_btn"),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (showMore) "Show less" else "Show more",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                    imageVector = if (showMore) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
            }

            // Hidden text info inside Show More
            AnimatedVisibility(visible = showMore) {
                Column {
                    Spacer(modifier = Modifier.height(10.dp))

                    // Executive Summary
                    Text(
                        text = briefing?.executiveSummary ?: "Synthesizing today's morning briefing from live data sources...",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        lineHeight = 20.sp
                    )

                    // Highlights
                    if (briefing != null && briefing.newsHighlights.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            briefing.newsHighlights.take(3).forEach { highlight ->
                                Row(verticalAlignment = Alignment.Top) {
                                    Text(
                                        text = "• ",
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = highlight,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        lineHeight = 16.sp
                                    )
                                }
                            }
                        }
                    }

                    // Daily Bible Verse (shown in Morning Brief if user enabled it)
                    if (briefing?.bibleVerse != null) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("morning_brief_bible_verse_card"),
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.MenuBook,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Daily Scripture",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    Text(
                                        text = briefing.bibleVerse.reference,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "\"${briefing.bibleVerse.text}\"",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontStyle = FontStyle.Italic,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    lineHeight = 18.sp
                                )
                                if (briefing.bibleVerse.theme.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Theme: ${briefing.bibleVerse.theme} • ${briefing.bibleVerse.translation}",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenChat() },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Ask Mornix AI Assistant (Gemini)",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun HomeCalendarWidgetCard(
    onOpenCalendar: () -> Unit,
    onOpenFestivals: () -> Unit = {},
    onOpenConverter: () -> Unit,
    onOpenAgeCalc: () -> Unit
) {
    val todayAd = remember { NepaliDateConverter.todayAd() }
    val todayBs = remember { NepaliDateConverter.todayBs() }
    val dayOfWeek = NepaliDateConverter.getDayOfWeek(todayBs)
    val weekdayNe = NepaliDateUtils.WEEKDAYS_FULL_NE[dayOfWeek.value % 7]
    val weekdayEn = NepaliDateUtils.WEEKDAYS_FULL_EN[dayOfWeek.value % 7]
    val todayFestivals = remember { NepaliFestivalData.getFestivalsForBsDate(todayBs) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("home_calendar_widget_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
        ),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.primary.copy(alpha = 0.25f))
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CalendarMonth,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "${todayBs.formattedNe} (बि.सं.)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "$weekdayNe • $weekdayEn • ${todayAd.formatted}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (todayFestivals.isNotEmpty()) todayFestivals.first().nameNe else "BS & AD",
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action Buttons to jump into dedicated Calendar tabs
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OutlinedButton(
                    onClick = onOpenCalendar,
                    modifier = Modifier.weight(1f).testTag("quick_calendar_btn"),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 2.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("Calendar", fontSize = 10.sp, maxLines = 1)
                }

                OutlinedButton(
                    onClick = onOpenFestivals,
                    modifier = Modifier.weight(1f).testTag("quick_festivals_btn"),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 2.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Event, contentDescription = null, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("Festivals", fontSize = 10.sp, maxLines = 1)
                }

                OutlinedButton(
                    onClick = onOpenConverter,
                    modifier = Modifier.weight(1f).testTag("quick_converter_btn"),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 2.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.SwapHoriz, contentDescription = null, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("Converter", fontSize = 10.sp, maxLines = 1)
                }

                OutlinedButton(
                    onClick = onOpenAgeCalc,
                    modifier = Modifier.weight(1f).testTag("quick_age_btn"),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 2.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Cake, contentDescription = null, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("Age", fontSize = 10.sp, maxLines = 1)
                }
            }
        }
    }
}

@Composable
fun CryptoPricesCard(
    markets: List<MarketQuote>,
    onViewAllMarkets: () -> Unit
) {
    val cryptoQuotes = markets.filter { it.category.equals("Crypto", ignoreCase = true) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("crypto_prices_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            SectionHeader(
                title = "Crypto Prices",
                subtitle = "Live USD valuations & 24h market trends",
                icon = Icons.Default.CurrencyBitcoin,
                actionLabel = "Markets",
                onActionClick = onViewAllMarkets
            )

            Spacer(modifier = Modifier.height(10.dp))

            if (cryptoQuotes.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    cryptoQuotes.forEach { quote ->
                        val isPositive = quote.changePercent >= 0.0
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { onViewAllMarkets() },
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    val badgeColor = when (quote.symbol.uppercase()) {
                                        "BTC", "BITCOIN" -> androidx.compose.ui.graphics.Color(0xFFF7931A)
                                        "ETH", "ETHEREUM" -> androidx.compose.ui.graphics.Color(0xFF627EEA)
                                        "SOL", "SOLANA" -> androidx.compose.ui.graphics.Color(0xFF14F195)
                                        "BNB", "BINANCECOIN" -> androidx.compose.ui.graphics.Color(0xFFF3BA2F)
                                        "XRP", "RIPPLE" -> androidx.compose.ui.graphics.Color(0xFF23292F)
                                        "ADA", "CARDANO" -> androidx.compose.ui.graphics.Color(0xFF0033AD)
                                        "DOGE", "DOGECOIN" -> androidx.compose.ui.graphics.Color(0xFFC2A633)
                                        "AVAX", "AVALANCHE-2" -> androidx.compose.ui.graphics.Color(0xFFE84142)
                                        "DOT", "POLKADOT" -> androidx.compose.ui.graphics.Color(0xFFE6007A)
                                        "LINK", "CHAINLINK" -> androidx.compose.ui.graphics.Color(0xFF375BD2)
                                        "POL", "MATIC" -> androidx.compose.ui.graphics.Color(0xFF8247E5)
                                        else -> MaterialTheme.colorScheme.primary
                                    }
                                    val badgeSymbol = when (quote.symbol.uppercase()) {
                                        "BTC", "BITCOIN" -> "₿"
                                        "ETH", "ETHEREUM" -> "Ξ"
                                        "SOL", "SOLANA" -> "◎"
                                        "BNB", "BINANCECOIN" -> "BNB"
                                        "XRP", "RIPPLE" -> "✕"
                                        "ADA", "CARDANO" -> "₳"
                                        "DOGE", "DOGECOIN" -> "Ð"
                                        "AVAX", "AVALANCHE-2" -> "▲"
                                        "DOT", "POLKADOT" -> "●"
                                        "LINK", "CHAINLINK" -> "⬡"
                                        "POL", "MATIC" -> "⬢"
                                        else -> quote.symbol.take(2).uppercase()
                                    }
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(badgeColor),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = badgeSymbol,
                                            color = androidx.compose.ui.graphics.Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = if (badgeSymbol.length > 2) 11.sp else 15.sp
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = quote.name,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = quote.symbol,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = String.format(Locale.US, "$%,.2f", quote.price),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(
                                                if (isPositive) EmeraldLive.copy(alpha = 0.15f)
                                                else CoralWarning.copy(alpha = 0.15f)
                                            )
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = String.format(Locale.US, "%s%.2f%%", if (isPositive) "+" else "", quote.changePercent),
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isPositive) EmeraldLive else CoralWarning
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Loading real-time crypto prices...",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun NepalBullionCard(
    bullion: GoldSilverRates?,
    onNavigateToCalculator: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("nepal_bullion_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.MonetizationOn,
                        contentDescription = null,
                        tint = AmberGoldPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Nepal Gold & Silver Rates",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Official FENEGOSIDA Bullion Rates",
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                FreshnessBadge(
                    status = bullion?.freshnessStatus ?: FreshnessStatus.UNAVAILABLE,
                    sourceName = "FENEGOSIDA"
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (bullion != null && bullion.fineGoldTola > 0) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Fine Gold (Chhapawal, 24K)
                    Surface(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        border = CardDefaults.outlinedCardBorder()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "Fine Gold (24K)",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "NPR ${String.format(Locale.ENGLISH, "%,.0f", bullion.fineGoldTola)}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "per Tola",
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            PriceChangeBadge(
                                change = bullion.changeGoldTola,
                                changePercent = bullion.changeGoldTolaPercent
                            )
                        }
                    }

                    // Silver
                    Surface(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        border = CardDefaults.outlinedCardBorder()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "Silver (Tejabi/Pure)",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.secondary,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "NPR ${String.format(Locale.ENGLISH, "%,.0f", bullion.silverTola)}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "per Tola",
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            PriceChangeBadge(
                                change = bullion.changeSilverTola,
                                changePercent = bullion.changeSilverTolaPercent
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Tejabi & 10g reference
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "10 Grams Fine Gold: NPR ${String.format(Locale.ENGLISH, "%,.0f", bullion.fineGold10g)}",
                        style = MaterialTheme.typography.bodySmall,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Published: ${bullion.publishedDate}",
                        style = MaterialTheme.typography.bodySmall,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                Text(
                    text = "Awaiting official rate publication from FENEGOSIDA...",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(8.dp))

            // Action: Calculator
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToCalculator() },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Open Gold & Silver Value Calculator (24K, 22K, 18K)",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
fun ForexOverviewCard(
    forexList: List<ForexRateItem>,
    favoriteCodes: List<String>,
    onToggleFavorite: (String) -> Unit,
    onNavigateToConverter: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("forex_overview_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CurrencyExchange,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Nepal Rastra Bank Forex",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Official Central Bank Rates (Base: NPR • ⭐ Favorite to pin)",
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                FreshnessBadge(
                    status = if (forexList.isNotEmpty()) FreshnessStatus.LIVE else FreshnessStatus.UNAVAILABLE,
                    sourceName = "NRB"
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            val displayList = forexList.filter { favoriteCodes.contains(it.currencyCode) }
                .ifEmpty { forexList.take(6) }

            if (displayList.isNotEmpty()) {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(displayList, key = { it.currencyCode }) { item ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            border = CardDefaults.outlinedCardBorder()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(text = item.flagEmoji, fontSize = 16.sp)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "${item.unit} ${item.currencyCode}",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    IconButton(
                                        onClick = { onToggleFavorite(item.currencyCode) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (item.isFavorite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                                            contentDescription = "Toggle favorite",
                                            tint = if (item.isFavorite) AmberGoldPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Buy: NPR ${item.buyRate}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Sell: NPR ${item.sellRate}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            } else {
                Text(
                    text = "Awaiting official exchange rate data from Nepal Rastra Bank...",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToConverter() },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Open Full Currency Converter (Official Rates)",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
fun WeatherCard(
    weather: WeatherInfo?,
    tempUnit: TemperatureUnit,
    onViewFullForecast: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("weather_snapshot_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.WbSunny,
                        contentDescription = null,
                        tint = AmberGoldLight,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "${weather?.cityName ?: "Nepal"} Weather",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = weather?.conditionDescription ?: "Live Observation",
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                FreshnessBadge(
                    status = weather?.freshnessStatus ?: FreshnessStatus.UNAVAILABLE,
                    sourceName = "Open-Meteo"
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (weather != null) {
                val temp = if (tempUnit == TemperatureUnit.FAHRENHEIT) {
                    (weather.currentTempC * 9 / 5 + 32).toInt()
                } else {
                    weather.currentTempC.toInt()
                }
                val symbol = if (tempUnit == TemperatureUnit.FAHRENHEIT) "°F" else "°C"

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "$temp$symbol",
                            style = MaterialTheme.typography.headlineLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Feels like ${if (tempUnit == TemperatureUnit.FAHRENHEIT) (weather.feelsLikeC * 9 / 5 + 32).toInt() else weather.feelsLikeC.toInt()}$symbol",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "Humidity: ${weather.humidityPercent}%",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Wind: ${weather.windSpeedKmh.toInt()} km/h ${weather.windDirection}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "AQI: ${weather.aqi} (${weather.aqiStatus})",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold,
                            color = if (weather.aqi <= 100) EmeraldLive else AmberGoldPrimary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Hourly timeline preview
                if (weather.hourlyForecast.isNotEmpty()) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(weather.hourlyForecast.take(6)) { hour ->
                            val hTemp = if (tempUnit == TemperatureUnit.FAHRENHEIT) {
                                (hour.tempC * 9 / 5 + 32).toInt()
                            } else {
                                hour.tempC.toInt()
                            }
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                border = CardDefaults.outlinedCardBorder()
                            ) {
                                Column(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = hour.timeLabel,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = "$hTemp$symbol",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${hour.rainProb}% rain",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontSize = 9.sp,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onViewFullForecast() },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "View 7-Day Forecast & City Switcher",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
fun MarketsOverviewCard(
    markets: List<MarketQuote>,
    onToggleFavorite: (String) -> Unit,
    onViewAllMarkets: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("markets_overview_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ShowChart,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "International Markets",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Commodities, Crypto & Global Indices (⭐ Favorite to pin)",
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                FreshnessBadge(
                    status = if (markets.isNotEmpty()) FreshnessStatus.LIVE else FreshnessStatus.UNAVAILABLE,
                    sourceName = "Exchanges"
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (markets.isNotEmpty()) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(markets.take(6), key = { it.symbol }) { quote ->
                        val isPositive = quote.changePercent >= 0
                        Surface(
                            modifier = Modifier.width(148.dp),
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            border = CardDefaults.outlinedCardBorder()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = quote.name,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    IconButton(
                                        onClick = { onToggleFavorite(quote.symbol) },
                                        modifier = Modifier.size(22.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (quote.isFavorite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                                            contentDescription = "Toggle Favorite",
                                            tint = if (quote.isFavorite) AmberGoldPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(15.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "${quote.currencySymbol}${String.format(Locale.ENGLISH, "%,.2f", quote.price)}",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "${if (isPositive) "+" else ""}${String.format(Locale.ENGLISH, "%.2f", quote.changePercent)}%",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (isPositive) EmeraldLive else CoralWarning
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                MiniSparkline(
                                    points = quote.historyPoints,
                                    isPositive = isPositive,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(24.dp)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onViewAllMarkets() },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "View Full Market Watch & Trends",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
fun HomeDisasterTopBanner(
    alerts: List<DisasterAlert>,
    onViewAlertDetails: () -> Unit,
    onDismiss: () -> Unit
) {
    val topAlert = alerts.firstOrNull() ?: return
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("home_disaster_top_banner"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = CoralWarning.copy(alpha = 0.16f)
        ),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(CoralWarning.copy(alpha = 0.65f))
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Disaster Alert",
                        tint = CoralWarning,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "🚨 ${topAlert.severity} DISASTER ALERT",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = CoralWarning
                    )
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Dismiss Alert",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = topAlert.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Text(
                text = topAlert.description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Authority: ${topAlert.issuingAuthority}",
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Text(
                    text = "View Details →",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = CoralWarning,
                    modifier = Modifier.clickable { onViewAlertDetails() }
                )
            }
        }
    }
}

@Composable
fun DisasterAlertsCard(
    alerts: List<DisasterAlert>,
    onViewAllAlerts: () -> Unit
) {
    val topAlert = alerts.firstOrNull() ?: return
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("disaster_alert_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = CoralWarning.copy(alpha = 0.12f)
        ),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(CoralWarning.copy(alpha = 0.4f))
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = CoralWarning,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Official Hazard Notice (${topAlert.severity})",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = CoralWarning
                    )
                }

                Text(
                    text = topAlert.pubDateFormatted,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = topAlert.title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = topAlert.description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Authority: ${topAlert.issuingAuthority}",
                style = MaterialTheme.typography.labelSmall,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
            )
        }
    }
}

@Composable
fun NewsArticleCard(
    article: NewsArticle,
    onToggleBookmark: () -> Unit,
    onOpenUrl: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("news_article_card_${article.id}")
            .clickable { onOpenUrl() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Source & Freshness Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = article.sourceName,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    val isLocal = article.category.equals("Nepal News", ignoreCase = true) ||
                        article.sourceName.contains("OnlineKhabar", ignoreCase = true) ||
                        article.sourceName.contains("Kathmandu", ignoreCase = true) ||
                        article.sourceName.contains("Nepali Times", ignoreCase = true) ||
                        article.sourceName.contains("Setopati", ignoreCase = true) ||
                        article.sourceName.contains("Ratopati", ignoreCase = true) ||
                        article.sourceName.contains("Himalayan", ignoreCase = true)
                    if (isLocal) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                        ) {
                            Text(
                                text = "🇳🇵 Local",
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "• ${article.freshnessLabel}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                IconButton(
                    onClick = onToggleBookmark,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = if (article.isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                        contentDescription = "Bookmark",
                        tint = if (article.isBookmarked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = article.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = article.summary,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
                lineHeight = 18.sp
            )

            if (!article.aiSummary.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        .padding(8.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Grounded AI Briefing",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 10.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = article.aiSummary,
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = article.category,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary,
                    fontWeight = FontWeight.SemiBold
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Original Article",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun PriceChangeBadge(change: Double, changePercent: Double) {
    val isPositive = change >= 0
    val color = if (isPositive) EmeraldLive else CoralWarning
    val sign = if (isPositive) "+" else ""

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(color.copy(alpha = 0.12f))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = "$sign${String.format(Locale.ENGLISH, "%,.0f", change)} ($sign${String.format(Locale.ENGLISH, "%.2f", changePercent)}%)",
            color = color,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun DailyBibleVerseCard(
    verse: BibleVerse,
    onShare: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("daily_bible_verse_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.35f)
        ),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.secondary.copy(alpha = 0.3f))
        )
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.MenuBook,
                            contentDescription = "Bible Verse",
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Daily Scripture Reflection",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${verse.theme} • ${verse.dateFormatted}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                IconButton(
                    onClick = onShare,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "Share Verse",
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "\"${verse.text}\"",
                style = MaterialTheme.typography.bodyLarge,
                fontStyle = FontStyle.Italic,
                color = MaterialTheme.colorScheme.onSurface,
                lineHeight = 24.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Text(
                    text = "— ${verse.reference} (${verse.translation})",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        }
    }
}

