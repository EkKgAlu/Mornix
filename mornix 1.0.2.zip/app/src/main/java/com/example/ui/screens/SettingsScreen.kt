package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Warning
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.material.icons.filled.DragHandle
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.IconButton
import android.view.HapticFeedbackConstants
import androidx.compose.ui.draw.clip
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.calendar.NepaliDateConverter
import com.example.data.calendar.NepaliFestivalData
import com.example.data.model.GoldWeightUnit
import com.example.data.model.TemperatureUnit
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Settings
import com.example.service.MornixNotificationHelper
import com.example.service.OemNotificationCompatibility
import com.example.service.OemOsFamily
import com.example.ui.components.SectionHeader
import com.example.ui.viewmodel.MornixViewModel

@Composable
fun SettingsScreen(
    viewModel: MornixViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val view = LocalView.current
    val triggerSwitchHaptic = {
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
    }
    val prefs by viewModel.userPreferences.collectAsState()
    val weather by viewModel.weather.collectAsState()
    val speechRate by viewModel.speechRate.collectAsState()

    val notifPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.refreshLiveStatusNotification()
        }
    }

    val allCategories = listOf(
        "Nepal News", "World News", "Politics", "Business and Economy",
        "Technology and AI", "Science", "Cryptocurrency", "Gold and Precious Metals",
        "Weather and Climate", "Sports", "Entertainment", "Health and Science"
    )

    val allWidgetsMap = mapOf(
        "briefing" to "Morning Briefing Card",
        "calendar" to "Nepali & English Calendar",
        "gold_silver" to "Nepal Gold & Silver Rates",
        "forex" to "Foreign Exchange (NRB)",
        "weather" to "Weather Snapshot",
        "crypto" to "Crypto Prices",
        "markets" to "International Markets & Commodities",
        "breaking_news" to "Today's Verified News",
        "alerts" to "Disaster & Emergency Notices"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("settings_screen")
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. ABOUT SECTION (Prominently displays "Made with AI by Resham")
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                ),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("about_mornix_card")
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.mornix_logo),
                            contentDescription = "Mornix App Logo",
                            modifier = Modifier
                                .size(56.dp)
                                .clip(RoundedCornerShape(14.dp))
                        )
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Text(
                                text = "Mornix",
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Daily Intelligence & Live Briefing • v1.0.2",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // "Made with AI by Resham" Badge
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Made with AI by Resham",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "Created as an intelligent, trustworthy morning companion with zero simulated data.",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Mornix brings together verified publisher RSS news, official FENEGOSIDA gold and silver rates, Nepal Rastra Bank forex fixations, Open-Meteo atmospheric forecasts, international commodities, and disaster hazard telemetry.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        // 2. Preferred Region & Units
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    SectionHeader(
                        title = "Regional & Unit Preferences",
                        subtitle = "Default: Current Location (GPS) • Base currency: NPR",
                        icon = Icons.Default.LocationOn
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(text = "Default Weather Location", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.MyLocation,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (prefs.preferredCity.equals("Current Location", ignoreCase = true)) "Current Location (Active GPS Default)" else prefs.preferredCity,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(text = "Temperature Unit", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = (prefs.temperatureUnit == TemperatureUnit.CELSIUS),
                            onClick = {
                                triggerSwitchHaptic()
                                viewModel.setTemperatureUnit(TemperatureUnit.CELSIUS)
                            },
                            label = { Text("Celsius (°C)") }
                        )
                        FilterChip(
                            selected = (prefs.temperatureUnit == TemperatureUnit.FAHRENHEIT),
                            onClick = {
                                triggerSwitchHaptic()
                                viewModel.setTemperatureUnit(TemperatureUnit.FAHRENHEIT)
                            },
                            label = { Text("Fahrenheit (°F)") }
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(text = "Gold & Bullion Unit", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(
                            Pair("Tola", GoldWeightUnit.TOLA),
                            Pair("10 Grams", GoldWeightUnit.TEN_GRAM),
                            Pair("Gram", GoldWeightUnit.GRAM),
                            Pair("Troy Oz", GoldWeightUnit.TROY_OUNCE)
                        ).forEach { (label, unit) ->
                            FilterChip(
                                selected = (prefs.goldWeightUnit == unit),
                                onClick = {
                                    triggerSwitchHaptic()
                                    viewModel.setGoldWeightUnit(unit)
                                },
                                label = { Text(label) }
                            )
                        }
                    }
                }
            }
        }

        // 3. Persistent Live Status Notification (Nepali Date & Weather)
        item {
            val liveStatusPreview = remember(
                prefs.nepaliDateNotificationEnabled,
                prefs.weatherNotificationEnabled,
                weather,
                prefs.temperatureUnit,
                prefs.preferredCity
            ) {
                MornixNotificationHelper.buildLiveStatusContent(
                    nepaliDateEnabled = prefs.nepaliDateNotificationEnabled,
                    weatherEnabled = prefs.weatherNotificationEnabled,
                    weather = weather,
                    tempUnit = prefs.temperatureUnit,
                    fallbackCity = prefs.preferredCity
                )
            }

            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("live_status_notification_settings_card")
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    SectionHeader(
                        title = "Live Status Notification",
                        subtitle = "Persistent daily status in the Android notification panel",
                        icon = Icons.Default.NotificationsActive
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Switch 1: Nepali Date Notification
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Nepali Date Notification",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Show today's Bikram Sambat date in the notification bar.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = prefs.nepaliDateNotificationEnabled,
                            onCheckedChange = { enabled ->
                                triggerSwitchHaptic()
                                if (enabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    notifPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                                }
                                viewModel.toggleNepaliDateNotification(enabled)
                            },
                            modifier = Modifier.testTag("nepali_date_notification_switch")
                        )
                    }

                    HorizontalDivider(
                        modifier = Modifier.padding(vertical = 12.dp),
                        color = MaterialTheme.colorScheme.outlineVariant
                    )

                    // Switch 2: Weather Notification
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Weather Notification",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Show current temperature and feels-like temperature in the notification bar.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = prefs.weatherNotificationEnabled,
                            onCheckedChange = { enabled ->
                                triggerSwitchHaptic()
                                if (enabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    notifPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                                }
                                viewModel.toggleWeatherNotification(enabled)
                            },
                            modifier = Modifier.testTag("weather_notification_switch")
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Live Notification Preview Box
                    if (liveStatusPreview != null) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f))
                                .border(
                                    1.dp,
                                    MaterialTheme.colorScheme.primary.copy(alpha = 0.3f),
                                    RoundedCornerShape(12.dp)
                                )
                                .padding(12.dp)
                                .testTag("live_status_notification_preview")
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Image(
                                            painter = painterResource(id = R.drawable.mornix_logo),
                                            contentDescription = null,
                                            modifier = Modifier
                                                .size(16.dp)
                                                .clip(RoundedCornerShape(4.dp))
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = liveStatusPreview.title,
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    Text(
                                        text = "ONGOING",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }

                                liveStatusPreview.dateLine?.let { dateLine ->
                                    Text(
                                        text = dateLine,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }

                                liveStatusPreview.weatherLine?.let { weatherLine ->
                                    Text(
                                        text = weatherLine,
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }

                                liveStatusPreview.locationLine?.let { locationLine ->
                                    Text(
                                        text = locationLine,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedButton(
                            onClick = {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    notifPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                                }
                                viewModel.refreshAll()
                                viewModel.refreshLiveStatusNotification()
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("refresh_live_status_notif_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Update Live Status Notification Now", fontSize = 12.sp)
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                .padding(12.dp)
                                .testTag("live_status_notification_disabled_banner")
                        ) {
                            Text(
                                text = "Both switches are OFF. The ongoing notification is removed and background updates are stopped.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // 4. Morning Briefing & Disaster Notifications
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier.fillMaxWidth().testTag("notifications_settings_card")
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    SectionHeader(
                        title = "Morning Briefing & Disaster Alerts",
                        subtitle = "Scheduled briefings with direct audio listening in notification",
                        icon = Icons.Default.NotificationsActive
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Daily Morning Briefing Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Daily Morning Briefing",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Receive morning summary with a direct 'Listen' button in the notification",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = prefs.morningBriefingNotificationEnabled,
                            onCheckedChange = { enabled ->
                                triggerSwitchHaptic()
                                if (enabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    notifPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                                }
                                viewModel.toggleMorningNotification(enabled)
                            },
                            modifier = Modifier.testTag("morning_notification_switch")
                        )
                    }

                    if (prefs.morningBriefingNotificationEnabled) {
                        Spacer(modifier = Modifier.height(14.dp))

                        val formattedTime = remember(prefs.morningBriefingHour, prefs.morningBriefingMinute) {
                            val h = prefs.morningBriefingHour
                            val m = prefs.morningBriefingMinute
                            val amPm = if (h < 12) "AM" else "PM"
                            val displayHour = if (h == 0) 12 else if (h > 12) h - 12 else h
                            String.format(java.util.Locale.ENGLISH, "%02d:%02d %s", displayHour, m, amPm)
                        }

                        // Free Time Selector Card
                        Card(
                            onClick = {
                                android.app.TimePickerDialog(
                                    context,
                                    { _, hourOfDay, minute ->
                                        viewModel.setMorningNotificationTime(hourOfDay, minute)
                                    },
                                    prefs.morningBriefingHour,
                                    prefs.morningBriefingMinute,
                                    false
                                ).show()
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("free_select_briefing_time_btn"),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Alarm,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = "Briefing Delivery Time",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = formattedTime,
                                            style = MaterialTheme.typography.titleLarge,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }

                                OutlinedButton(
                                    onClick = {
                                        android.app.TimePickerDialog(
                                            context,
                                            { _, hourOfDay, minute ->
                                                viewModel.setMorningNotificationTime(hourOfDay, minute)
                                            },
                                            prefs.morningBriefingHour,
                                            prefs.morningBriefingMinute,
                                            false
                                        ).show()
                                    }
                                ) {
                                    Text("Pick Any Time", fontSize = 12.sp)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f))
                                .padding(10.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "When the notification arrives, tap '▶ Listen to Briefing' to hear the live audio brief without unlocking the phone.",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.outlineVariant)

                    // Show Upcoming Calendar Events in Morning Briefing Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Upcoming Calendar Events in Briefing",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Show or hide upcoming Nepali festivals and public holidays inside the Morning Briefing card",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = prefs.showUpcomingEventsInBriefing,
                            onCheckedChange = { enabled ->
                                triggerSwitchHaptic()
                                viewModel.toggleShowUpcomingEventsInBriefing(enabled)
                            },
                            modifier = Modifier.testTag("settings_briefing_upcoming_events_switch")
                        )
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.outlineVariant)

                    // Calendar Event Reminders (1 Day Before Upcoming Calendar Event)
                    val nextVerifiedEventGroup = remember {
                        NepaliFestivalData.getNextUpcomingVerifiedEventGroup()
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Calendar Event Reminders",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Notify me one day before an upcoming festival, public holiday, or calendar event (Asia/Kathmandu time)",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = prefs.calendarEventReminderEnabled,
                            onCheckedChange = { enabled ->
                                triggerSwitchHaptic()
                                if (enabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    notifPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                                }
                                viewModel.toggleCalendarEventReminder(enabled)
                            },
                            modifier = Modifier.testTag("calendar_event_reminder_switch")
                        )
                    }

                    if (prefs.calendarEventReminderEnabled && nextVerifiedEventGroup != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        val (nextBsDate, nextEvents, daysUntil) = nextVerifiedEventGroup
                        val eventNames = nextEvents.joinToString(", ") { it.nameEn }
                        val bsFormatted = nextBsDate.formattedEn
                        val adFormatted = NepaliDateConverter.bsToAd(nextBsDate).formatted
                        val daysText = if (daysUntil == 1L) {
                            "Happening Tomorrow (1 day away)"
                        } else {
                            "In $daysUntil days • Reminder set for 1 day before"
                        }
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f))
                                .padding(10.dp)
                                .testTag("calendar_event_reminder_status_box")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.CalendarMonth,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "Next Verified Event: $eventNames",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = "$bsFormatted ($adFormatted) • $daysText",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.outlineVariant)

                    // Natural Disaster Push Alerts Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Natural Disaster & Seismic Alerts",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "High-priority alerts for earthquakes, flash floods, and active meteorological warnings",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = prefs.disasterAlertsNotificationEnabled,
                            onCheckedChange = { enabled ->
                                triggerSwitchHaptic()
                                if (enabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    notifPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                                }
                                viewModel.toggleDisasterNotification(enabled)
                            },
                            modifier = Modifier.testTag("disaster_notification_switch")
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Test Buttons Row
                    Text(
                        text = "Instant Notification Preview",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    notifPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                                }
                                viewModel.sendTestMorningBriefingNotification()
                            },
                            modifier = Modifier.weight(1f).testTag("test_morning_briefing_btn")
                        ) {
                            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Test Briefing", fontSize = 11.sp)
                        }

                        OutlinedButton(
                            onClick = {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    notifPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                                }
                                viewModel.sendTestDisasterAlertNotification()
                            },
                            modifier = Modifier.weight(1f).testTag("test_disaster_alert_btn")
                        ) {
                            Icon(imageVector = Icons.Default.Warning, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Test Disaster", fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // 4B. Chinese Android OS & OEM Live Notification Compatibility Setup Guide
        item {
            OemNotificationCompatibilityCard(context = context)
        }

        // 5. Daily Bible Verse & Spiritual Reflection
        item {
            val todayVerse = viewModel.getTodayBibleVerse()
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier.fillMaxWidth().testTag("bible_verse_settings_card")
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    SectionHeader(
                        title = "Daily Bible Verse",
                        subtitle = "",
                        icon = Icons.AutoMirrored.Filled.MenuBook
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Daily Bible Verse",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Include an authentic scripture passage in your daily morning briefing and spoken audio",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = prefs.dailyBibleVerseEnabled,
                            onCheckedChange = { enabled ->
                                triggerSwitchHaptic()
                                viewModel.toggleDailyBibleVerse(enabled)
                            },
                            modifier = Modifier.testTag("bible_verse_switch")
                        )
                    }

                    if (prefs.dailyBibleVerseEnabled) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.35f))
                                .border(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                                .padding(14.dp)
                        ) {
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "Today's Scripture: ${todayVerse.reference}",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                    Text(
                                        text = todayVerse.translation,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "\"${todayVerse.text}\"",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontStyle = FontStyle.Italic,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    lineHeight = 18.sp
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Theme: ${todayVerse.theme} • Appears in your Morning Briefing card and audio narration",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }
                    }
                }
            }
        }

        // 5. Text-To-Speech (TTS) Settings
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    SectionHeader(
                        title = "Audio Briefing (Text-To-Speech)",
                        subtitle = "Adjust audio narration playback speed",
                        icon = Icons.Default.RecordVoiceOver
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "Speech Rate", style = MaterialTheme.typography.bodyMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(0.75f, 1.0f, 1.25f, 1.5f).forEach { speed ->
                                FilterChip(
                                    selected = (speechRate == speed),
                                    onClick = { viewModel.setTtsSpeed(speed) },
                                    label = { Text("${speed}x") }
                                )
                            }
                        }
                    }
                }
            }
        }

        // 4. Dashboard Widget Customization
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    SectionHeader(
                        title = "Home Dashboard Widgets",
                        subtitle = "Enable, disable, and rearrange your home feed widgets",
                        icon = Icons.Default.Tune
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    val currentOrder = prefs.widgetOrder
                    currentOrder.forEachIndexed { index, widgetId ->
                        val label = allWidgetsMap[widgetId] ?: widgetId
                        val isEnabled = prefs.enabledWidgets.contains(widgetId)
                        val isFirst = (index == 0)
                        val isLast = (index == currentOrder.size - 1)

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = { viewModel.moveWidgetUp(widgetId) },
                                        enabled = !isFirst,
                                        modifier = Modifier.size(32.dp).testTag("widget_up_$widgetId")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.KeyboardArrowUp,
                                            contentDescription = "Move Up",
                                            tint = if (!isFirst) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    IconButton(
                                        onClick = { viewModel.moveWidgetDown(widgetId) },
                                        enabled = !isLast,
                                        modifier = Modifier.size(32.dp).testTag("widget_down_$widgetId")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.KeyboardArrowDown,
                                            contentDescription = "Move Down",
                                            tint = if (!isLast) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = if (isEnabled) FontWeight.SemiBold else FontWeight.Normal,
                                        color = if (isEnabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Switch(
                                checked = isEnabled,
                                onCheckedChange = {
                                    triggerSwitchHaptic()
                                    viewModel.toggleWidget(widgetId)
                                },
                                modifier = Modifier.testTag("widget_switch_$widgetId")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedButton(
                        onClick = { viewModel.resetWidgetOrder() },
                        modifier = Modifier.fillMaxWidth().testTag("reset_widget_order_btn")
                    ) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Reset Widget Order", fontSize = 12.sp)
                    }
                }
            }
        }

        // 5. News Interests Personalization
        item {
            val allNewsSelected = prefs.selectedNewsCategories.containsAll(allCategories)
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    SectionHeader(
                        title = "Personalized News Interests",
                        subtitle = "Selected topics appear in your priority feed and daily briefing",
                        icon = Icons.Default.VerifiedUser,
                        actionLabel = if (allNewsSelected) "Reset Default" else "Select All",
                        onActionClick = {
                            if (allNewsSelected) {
                                viewModel.setSelectedNewsCategories(
                                    listOf(
                                        "Nepal News", "World News", "Politics", "Business and Economy",
                                        "Technology and AI", "Gold and Precious Metals", "Weather and Climate"
                                    )
                                )
                            } else {
                                viewModel.setSelectedNewsCategories(allCategories)
                            }
                        }
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    allCategories.chunked(2).forEach { row ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            row.forEach { cat ->
                                val isSelected = prefs.selectedNewsCategories.contains(cat)
                                FilterChip(
                                    selected = isSelected,
                                    onClick = {
                                        triggerSwitchHaptic()
                                        viewModel.toggleNewsInterest(cat)
                                    },
                                    label = { Text(cat, fontSize = 11.sp) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            if (row.size == 1) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                    }
                }
            }
        }

        // 6. Transparency, Data Sources & Verifiable Citations
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    SectionHeader(
                        title = "Data Sources & Transparency",
                        subtitle = "100% verified live providers • Zero synthetic or simulated data",
                        icon = Icons.Default.Info
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    DataSourceRow(
                        name = "Nepal Bullion (Gold & Silver)",
                        provider = "Federation of Nepal Gold & Silver Dealers' Association (FENEGOSIDA)",
                        url = "https://fenegosida.org",
                        context = context
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.outlineVariant)

                    DataSourceRow(
                        name = "Foreign Exchange (Forex)",
                        provider = "Nepal Rastra Bank (NRB Central Bank API)",
                        url = "https://www.nrb.org.np",
                        context = context
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.outlineVariant)

                    DataSourceRow(
                        name = "Weather & Forecasts",
                        provider = "Open-Meteo High-Resolution Atmospheric Model",
                        url = "https://open-meteo.com",
                        context = context
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.outlineVariant)

                    DataSourceRow(
                        name = "Seismic & Disaster Hazards",
                        provider = "USGS Earthquake Hazards Program / National Seismological Monitoring",
                        url = "https://earthquake.usgs.gov",
                        context = context
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.outlineVariant)

                    DataSourceRow(
                        name = "News Feeds",
                        provider = "OnlineKhabar, Nepali Times, BBC World, TechCrunch, CoinDesk RSS",
                        url = "https://english.onlinekhabar.com",
                        context = context
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Mornix Principle: Correctness over completeness. When an external service is offline or unverified, Mornix displays OLD DATA or DATA UNAVAILABLE rather than fabricating information.",
                        style = MaterialTheme.typography.bodySmall,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
fun DataSourceRow(
    name: String,
    provider: String,
    url: String,
    context: android.content.Context
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable {
                if (url.isNotBlank()) {
                    try {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                        context.startActivity(intent)
                    } catch (_: Exception) {}
                }
            },
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text(text = provider, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(
            imageVector = Icons.AutoMirrored.Filled.OpenInNew,
            contentDescription = "Open Source Link",
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(16.dp)
        )
    }
}

@Composable
fun OemNotificationCompatibilityCard(
    context: android.content.Context
) {
    var diagnosticsRefreshTick by remember { mutableStateOf(0) }
    val diagnostics = remember(diagnosticsRefreshTick) {
        OemNotificationCompatibility.inspectDeviceDiagnostics(context)
    }
    var selectedOsFamily by remember(diagnostics.detectedOsFamily) {
        mutableStateOf(diagnostics.detectedOsFamily)
    }
    var isGuideExpanded by remember { mutableStateOf(false) }
    val currentGuide = remember(selectedOsFamily) {
        OemNotificationCompatibility.getSetupGuideForOs(selectedOsFamily)
    }

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("oem_notification_compatibility_card")
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            SectionHeader(
                title = "Device & Chinese OS Notification Compatibility",
                subtitle = "Live Status, Dynamic Island, Floating Banners & Lock Screen support",
                icon = Icons.Default.PhoneAndroid,
                actionLabel = if (isGuideExpanded) "Hide Guide" else "Setup Guide",
                onActionClick = { isGuideExpanded = !isGuideExpanded }
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Detected Device & OS Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f))
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.primary.copy(alpha = 0.3f),
                        RoundedCornerShape(12.dp)
                    )
                    .padding(12.dp)
                    .testTag("oem_detected_device_banner")
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Detected: ${diagnostics.detectedOsFamily.manufacturerDisplay} (${diagnostics.detectedOsFamily.osDisplay})",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Android ${diagnostics.androidRelease}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        text = "Supported Live Display: ${diagnostics.detectedOsFamily.liveIslandTerm}",
                        style = MaterialTheme.typography.bodySmall,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Live Diagnostic Status Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OemStatusBadge(
                    label = "Notifications",
                    value = if (diagnostics.notificationsEnabled) "Allowed" else "Blocked",
                    isOk = diagnostics.notificationsEnabled,
                    modifier = Modifier.weight(1f)
                )
                OemStatusBadge(
                    label = "Live Status & Chip",
                    value = if (diagnostics.liveStatusChannelEnabled) "Active" else "Muted",
                    isOk = diagnostics.liveStatusChannelEnabled,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val floatingOk = diagnostics.calendarReminderChannelHighImportance && diagnostics.morningBriefingChannelHighImportance
                OemStatusBadge(
                    label = "Floating Reminders",
                    value = if (floatingOk) "High Priority" else "Restricted",
                    isOk = floatingOk,
                    modifier = Modifier.weight(1f)
                )
                OemStatusBadge(
                    label = "Background Battery",
                    value = if (diagnostics.ignoringBatteryOptimizations) "Unrestricted" else "Optimized",
                    isOk = diagnostics.ignoringBatteryOptimizations,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Quick System Settings Deep-Link Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        OemNotificationCompatibility.openAppNotificationSettings(context)
                        diagnosticsRefreshTick++
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("oem_open_notif_settings_btn")
                ) {
                    Icon(Icons.Default.NotificationsActive, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Notification Settings", fontSize = 11.sp)
                }

                OutlinedButton(
                    onClick = {
                        OemNotificationCompatibility.openOemAutostartOrAppSettings(context, selectedOsFamily)
                        diagnosticsRefreshTick++
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("oem_open_autostart_settings_btn")
                ) {
                    Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Autostart & App Info", fontSize = 11.sp)
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        OemNotificationCompatibility.openChannelNotificationSettings(
                            context,
                            MornixNotificationHelper.CHANNEL_LIVE_STATUS_ID
                        )
                        diagnosticsRefreshTick++
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("oem_open_live_channel_btn")
                ) {
                    Text("Live Status Channel", fontSize = 11.sp)
                }

                OutlinedButton(
                    onClick = {
                        OemNotificationCompatibility.openBatteryOptimizationSettings(context)
                        diagnosticsRefreshTick++
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("oem_open_battery_settings_btn")
                ) {
                    Icon(Icons.Default.BatteryChargingFull, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Battery Settings", fontSize = 11.sp)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Expand/Collapse Manufacturer Setup Guide button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    .clickable { isGuideExpanded = !isGuideExpanded }
                    .padding(horizontal = 12.dp, vertical = 10.dp)
                    .testTag("oem_toggle_setup_guide_btn"),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Manufacturer Setup Guide (${selectedOsFamily.osDisplay})",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "How to enable Floating Banners, Dynamic Island, Lock Screen & Autostart",
                        style = MaterialTheme.typography.bodySmall,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Icon(
                    imageVector = if (isGuideExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                    contentDescription = if (isGuideExpanded) "Collapse Guide" else "Expand Guide",
                    tint = MaterialTheme.colorScheme.primary
                )
            }

            if (isGuideExpanded) {
                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Select Manufacturer / OS Guide:",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("oem_os_selector_row")
                ) {
                    items(OemOsFamily.entries) { family ->
                        FilterChip(
                            selected = (selectedOsFamily == family),
                            onClick = { selectedOsFamily = family },
                            label = { Text(family.osDisplay, fontSize = 11.sp) },
                            modifier = Modifier.testTag("oem_chip_${family.id}")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = currentGuide.summaryNote,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 17.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                currentGuide.steps.forEach { step ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                            .padding(12.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(
                                text = "${step.stepNumber}. ${step.title}",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = step.instruction,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Path: ${step.settingsPath}",
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Note: Mornix respects Android security and never modifies system settings automatically. Depending on your manufacturer ROM version, menu names may vary slightly.",
                    style = MaterialTheme.typography.bodySmall,
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun OemStatusBadge(
    label: String,
    value: String,
    isOk: Boolean,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(
                if (isOk) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.35f)
            )
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = if (isOk) Icons.Default.CheckCircle else Icons.Default.Warning,
            contentDescription = null,
            tint = if (isOk) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Column {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = value,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

