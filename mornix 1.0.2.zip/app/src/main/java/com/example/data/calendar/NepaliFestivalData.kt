package com.example.data.calendar

import java.time.temporal.ChronoUnit

enum class HolidayScope {
    NATIONWIDE,
    KATHMANDU_VALLEY,
    WOMEN_ONLY,
    COMMUNITY_SPECIFIC
}

enum class FestivalCategory {
    MAJOR_FESTIVAL,
    NATIONAL_HOLIDAY,
    RELIGIOUS_CELEBRATION,
    CULTURAL_EVENT,
    REGIONAL_HOLIDAY
}

data class NepaliFestival(
    val id: String,
    val nameNe: String,
    val nameEn: String,
    val bsYear: Int,
    val bsMonth: Int,
    val bsDay: Int,
    val isPublicHoliday: Boolean,
    val holidayScope: HolidayScope = HolidayScope.NATIONWIDE,
    val category: FestivalCategory = FestivalCategory.MAJOR_FESTIVAL,
    val description: String,
    val significance: String,
    val source: String = "Ministry of Home Affairs, Government of Nepal / Nepal Panchanga Nirnayak Bikas Samiti",
    val isProvisional: Boolean = false
) {
    val bsDate: NepaliDate get() = NepaliDate(bsYear, bsMonth, bsDay)
}

object NepaliFestivalData {

    // Solar-fixed events and national holidays recurring every BS year
    private val RECURRING_SOLAR_HOLIDAYS = listOf(
        Triple(1, 1, "Nepali New Year (Naya Barsha)") to Triple("नयाँ वर्ष", true, "First day of Bikram Sambat new year, celebrated nationwide with festivities and cultural gatherings."),
        Triple(2, 15, "Republic Day (Gantantra Diwas)") to Triple("गणतन्त्र दिवस", true, "Commemorates the declaration of Federal Democratic Republic of Nepal in 2065 BS."),
        Triple(6, 3, "Constitution Day (Sambidhan Diwas)") to Triple("संविधान दिवस", true, "National Day celebrating the promulgation of the democratic Constitution of Nepal on Ashwin 3, 2072 BS."),
        Triple(9, 10, "Christmas Day") to Triple("क्रिसमस डे", true, "Celebration of the birth of Jesus Christ, marked with joyful services and celebrations."),
        Triple(9, 15, "Tamu Lhosar") to Triple("तमु ल्होसार", true, "Traditional New Year of the Gurung community, celebrated with traditional attire, dancing, and feasts."),
        Triple(9, 27, "Prithvi Jayanti / National Unity Day") to Triple("पृथ्वी जयन्ती / राष्ट्रिय एकता दिवस", true, "Birth anniversary of King Prithvi Narayan Shah, founder of unified modern Nepal."),
        Triple(10, 1, "Maghe Sankranti (Makar Sankranti)") to Triple("माघे संक्रान्ति / माघी", true, "Winter solstice festival marking the transition into Uttarayan. Tharu New Year (Maghi) and holy bath in river confluences."),
        Triple(10, 16, "Martyrs' Day (Shahid Diwas)") to Triple("सहिद दिवस", false, "Homage to the brave freedom fighters and martyrs who sacrificed their lives for democracy and liberty."),
        Triple(11, 7, "National Democracy Day (Prajatantra Diwas)") to Triple("राष्ट्रिय प्रजातन्त्र दिवस", true, "Historic day commemorating the overthrow of the autocratic 104-year Rana regime in 2007 BS.")
    )

    // Specific verified yearly calendars: 2080, 2081, 2082, 2083 BS
    // Cross-verified against Ministry of Home Affairs (MoHA) official gazettes & Nepal Panchanga Nirnayak Bikas Samiti
    private val YEARLY_FESTIVALS = mutableMapOf<Int, List<NepaliFestival>>()

    init {
        // -------------------------------------------------------------
        // 2080 BS (2023 - 2024 AD)
        // -------------------------------------------------------------
        YEARLY_FESTIVALS[2080] = listOf(
            createFestival("2080_ny", "नयाँ वर्ष", "Nepali New Year 2080", 2080, 1, 1, true, HolidayScope.NATIONWIDE, FestivalCategory.NATIONAL_HOLIDAY, "First day of Bikram Sambat 2080.", "National cultural holiday."),
            createFestival("2080_majdur", "मजदुर दिवस", "International Workers' Day", 2080, 1, 18, true, HolidayScope.NATIONWIDE, FestivalCategory.NATIONAL_HOLIDAY, "International Labour Day celebration.", "Honoring workers' rights."),
            createFestival("2080_buddha", "बुद्ध जयन्ती / उभौली", "Buddha Jayanti & Ubhauli Parva", 2080, 1, 22, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Birth, enlightenment, and Mahaparinirvana of Lord Buddha in Lumbini; Kirat Ubhauli.", "Peace and compassion."),
            createFestival("2080_gantantra", "गणतन्त्र दिवस", "Republic Day", 2080, 2, 15, true, HolidayScope.NATIONWIDE, FestivalCategory.NATIONAL_HOLIDAY, "Declaration of the Republic.", "Democratic milestone."),
            createFestival("2080_janai", "जनै पूर्णिमा / रक्षाबन्धन", "Janai Purnima & Raksha Bandhan", 2080, 5, 14, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Sacred thread changing and Raksha Bandhan protection bond; Newar Kwati Punhi.", "Spiritual renewal and brother-sister bond."),
            createFestival("2080_gaijatra", "गाईजात्रा", "Gai Jatra", 2080, 5, 15, true, HolidayScope.KATHMANDU_VALLEY, FestivalCategory.REGIONAL_HOLIDAY, "Festival honoring deceased family members in Kathmandu Valley.", "Catharsis, satire, and remembrance."),
            createFestival("2080_krishna", "श्रीकृष्ण जन्माष्टमी", "Krishna Janmashtami", 2080, 5, 20, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Celebration of the birth of Lord Krishna.", "Triumph of righteousness."),
            createFestival("2080_teej", "हरितालिका तीज", "Haritalika Teej", 2080, 6, 1, true, HolidayScope.WOMEN_ONLY, FestivalCategory.MAJOR_FESTIVAL, "Great festival of Hindu women for family prosperity and devotion.", "Fasting, red sarees, and cultural singing."),
            createFestival("2080_rishi", "ऋषि पञ्चमी", "Rishi Panchami", 2080, 6, 3, false, HolidayScope.WOMEN_ONLY, FestivalCategory.CULTURAL_EVENT, "Worship of the Saptarshis by women.", "Purification rites."),
            createFestival("2080_indrajatra", "इन्द्रजात्रा", "Indra Jatra", 2080, 6, 11, true, HolidayScope.KATHMANDU_VALLEY, FestivalCategory.REGIONAL_HOLIDAY, "Grand chariot procession of Living Goddess Kumari and Lord Indra.", "Rain, harvest thanksgiving, and cultural glory."),
            createFestival("2080_sambidhan", "संविधान दिवस", "Constitution Day", 2080, 6, 3, true, HolidayScope.NATIONWIDE, FestivalCategory.NATIONAL_HOLIDAY, "National Constitution Day of Nepal.", "National pride."),
            // Dashain 2080
            createFestival("2080_ghatasthapana", "घटस्थापना (दशैं आरम्भ)", "Ghatasthapana (Dashain Begins)", 2080, 6, 28, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Sowing of Jamara and start of Navaratri.", "Invocation of Goddess Durga."),
            createFestival("2080_fulpati", "फूलपाती", "Fulpati (Maha Saptami)", 2080, 7, 4, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Royal palanquin of sacred flowers enters Tundikhel.", "Official opening of Dashain festivities."),
            createFestival("2080_ashtami", "महा अष्टमी", "Maha Ashtami (Kalaratri)", 2080, 7, 5, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Fierce form of Durga (Kali) worshipped.", "Inner spiritual strength."),
            createFestival("2080_nawami", "महा नवमी", "Maha Nawami", 2080, 7, 6, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Vishwakarma tools and vehicle blessings; Taleju temple opens.", "Gratitude for instruments and tools."),
            createFestival("2080_dashami", "विजया दशमी", "Vijaya Dashami (Bada Dashain)", 2080, 7, 7, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Receiving Tika and Jamara from elders with divine blessings.", "Triumph of good over evil."),
            createFestival("2080_kojagrat", "कोजाग्रत पूर्णिमा", "Kojagrat Purnima (Dashain Ends)", 2080, 7, 11, false, HolidayScope.NATIONWIDE, FestivalCategory.CULTURAL_EVENT, "Vigil for Goddess Laxmi; concludes Dashain.", "Prosperity and abundance."),
            // Tihar 2080
            createFestival("2080_kagtihar", "काग तिहार / धनतेरस", "Kag Tihar (Dhanteras)", 2080, 7, 24, false, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Feeding crows, the messengers of Yamaraj; Dhanvantari Jayanti.", "Harmony with birds and nature."),
            createFestival("2080_kukurtihar", "कुकुर तिहार", "Kukur Tihar (Narak Chaturdashi)", 2080, 7, 25, false, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Garlanding and honoring dogs as guardians of human loyalty.", "Love and gratitude for dogs."),
            createFestival("2080_laxmi", "लक्ष्मी पूजा", "Laxmi Puja (Deepawali)", 2080, 7, 26, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Illuminating homes with oil lamps and welcoming Goddess Laxmi.", "Wealth, light, and prosperity."),
            createFestival("2080_govardhan", "गोवर्धन पूजा / म्ह पूजा", "Govardhan Puja & Mha Puja", 2080, 7, 27, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Cow and ox worship; Newari Mha Puja (worship of self); Nepal Sambat New Year.", "Ecology, self-purification, and New Year."),
            createFestival("2080_bhaitika", "भाइटीका", "Bhai Tika (Tihar Finale)", 2080, 7, 29, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Sisters put seven-color Saptarangi Tika on brothers for longevity and protection.", "Eternal sacred bond between siblings."),
            createFestival("2080_chhath", "छठ पर्व", "Chhath Parva", 2080, 8, 3, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Worship of the Sun God (Surya) and Chhathi Maiya at riverbanks.", "Purity, devotion, health, and universal energy."),
            createFestival("2080_tamu", "तमु ल्होसार", "Tamu Lhosar", 2080, 9, 15, true, HolidayScope.NATIONWIDE, FestivalCategory.CULTURAL_EVENT, "Gurung New Year.", "Indigenous cultural heritage."),
            createFestival("2080_christmas", "क्रिसमस डे", "Christmas Day", 2080, 9, 9, true, HolidayScope.NATIONWIDE, FestivalCategory.RELIGIOUS_CELEBRATION, "Christmas celebration.", "Peace and goodwill."),
            createFestival("2080_prithvi", "पृथ्वी जयन्ती", "Prithvi Jayanti", 2080, 9, 27, true, HolidayScope.NATIONWIDE, FestivalCategory.NATIONAL_HOLIDAY, "National Unity Day.", "Unification of Nepal."),
            createFestival("2080_maghe", "माघे संक्रान्ति", "Maghe Sankranti", 2080, 10, 1, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Makar Sankranti & Tharu Maghi.", "Warm food, ghee, chaku, and holy dip."),
            createFestival("2080_sonam", "सोनाम ल्होसार", "Sonam Lhosar", 2080, 10, 27, true, HolidayScope.NATIONWIDE, FestivalCategory.CULTURAL_EVENT, "Tamang community New Year.", "Buddhist heritage and festivities."),
            createFestival("2080_saraswati", "वसन्त पञ्चमी / सरस्वती पूजा", "Basanta Panchami (Saraswati Puja)", 2080, 11, 2, false, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Worship of Goddess of Knowledge and Arts Saraswati.", "Beginning of spring and learning."),
            createFestival("2080_shivaratri", "महाशिवरात्रि", "Maha Shivaratri", 2080, 11, 25, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Night of Lord Shiva; massive pilgrim influx at Pashupatinath Temple.", "Spiritual austerity and devotion."),
            createFestival("2080_gyalpo", "ग्याल्पो ल्होसार", "Gyalpo Lhosar", 2080, 11, 28, true, HolidayScope.NATIONWIDE, FestivalCategory.CULTURAL_EVENT, "Tibetan and Sherpa New Year.", "Mountain community heritage."),
            createFestival("2080_women", "अन्तर्राष्ट्रिय महिला दिवस", "International Women's Day", 2080, 11, 25, true, HolidayScope.WOMEN_ONLY, FestivalCategory.NATIONAL_HOLIDAY, "Celebrating women's social and political rights.", "Gender equality."),
            createFestival("2080_holi_pahad", "फागु पूर्णिमा (पहाड)", "Holi / Fagu Purnima (Hills)", 2080, 12, 11, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Festival of Colors in Kathmandu and hilly region.", "Joy, forgiveness, and brotherhood."),
            createFestival("2080_holi_terai", "फागु पूर्णिमा (तराई)", "Holi / Fagu Purnima (Terai)", 2080, 12, 12, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Festival of Colors across Madhesh and Terai districts.", "Joyful color spraying and sweets."),
            createFestival("2080_ghodejatra", "घोडेजात्रा", "Ghode Jatra", 2080, 12, 26, true, HolidayScope.KATHMANDU_VALLEY, FestivalCategory.REGIONAL_HOLIDAY, "Horse parade and acrobatics at Tundikhel to ward off demon Gurumapa.", "Ancient valley warrior traditions."),
            createFestival("2080_eid", "ईद उल-फित्र", "Eid al-Fitr", 2080, 12, 30, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Conclusion of the holy month of Ramadan.", "Charity, communal prayers, and feast.")
        )

        // -------------------------------------------------------------
        // 2081 BS (2024 - 2025 AD) — Current Standard Year
        // -------------------------------------------------------------
        YEARLY_FESTIVALS[2081] = listOf(
            createFestival("2081_ny", "नयाँ वर्ष", "Nepali New Year 2081", 2081, 1, 1, true, HolidayScope.NATIONWIDE, FestivalCategory.NATIONAL_HOLIDAY, "First day of Bikram Sambat 2081.", "Celebrated across all provinces."),
            createFestival("2081_ramnavami", "रामनवमी", "Ram Navami", 2081, 1, 5, false, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Birth of Lord Rama celebrated in Janakpur and temples across Nepal.", "Righteousness and truth."),
            createFestival("2081_majdur", "मजदुर दिवस", "International Workers' Day", 2081, 1, 19, true, HolidayScope.NATIONWIDE, FestivalCategory.NATIONAL_HOLIDAY, "May Day labor rights celebration.", "Dignity of labor."),
            createFestival("2081_buddha", "बुद्ध जयन्ती / उभौली", "Buddha Jayanti & Ubhauli Parva", 2081, 2, 10, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "2568th Buddha Jayanti in Lumbini and Kirat Ubhauli.", "Universal peace and non-violence."),
            createFestival("2081_gantantra", "गणतन्त्र दिवस", "Republic Day", 2081, 2, 15, true, HolidayScope.NATIONWIDE, FestivalCategory.NATIONAL_HOLIDAY, "Celebration of Nepal as a democratic republic.", "Sovereignty of the people."),
            createFestival("2081_bakra", "बकर इद (ईद उल-अजहा)", "Eid al-Adha (Bakra Eid)", 2081, 3, 3, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Feast of the Sacrifice observed by the Muslim community.", "Sacrifice, faith, and charity."),
            createFestival("2081_janai", "जनै पूर्णिमा / रक्षाबन्धन", "Janai Purnima & Raksha Bandhan", 2081, 5, 3, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Changing of sacred thread (Janai) and Raksha Bandhan; Newari Kwati Punhi.", "Spiritual protection and brotherhood."),
            createFestival("2081_gaijatra", "गाईजात्रा", "Gai Jatra", 2081, 5, 4, true, HolidayScope.KATHMANDU_VALLEY, FestivalCategory.REGIONAL_HOLIDAY, "Historic procession honoring family members who passed away in the past year.", "Comforting bereaved families."),
            createFestival("2081_krishna", "श्रीकृष्ण जन्माष्टमी", "Krishna Janmashtami", 2081, 5, 10, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Celebration of Lord Krishna's divine appearance at Patan Krishna Mandir.", "Devotion and righteous conduct."),
            createFestival("2081_teej", "हरितालिका तीज", "Haritalika Teej", 2081, 5, 21, true, HolidayScope.WOMEN_ONLY, FestivalCategory.MAJOR_FESTIVAL, "Festive day of fasting, devotion to Lord Shiva and Goddess Parvati, red attires, and dancing.", "Marital harmony and female solidarity."),
            createFestival("2081_rishi", "ऋषि पञ्चमी", "Rishi Panchami", 2081, 5, 23, false, HolidayScope.WOMEN_ONLY, FestivalCategory.CULTURAL_EVENT, "Veneration of the Seven Sages.", "Spiritual purification."),
            createFestival("2081_indrajatra", "इन्द्रजात्रा", "Indra Jatra", 2081, 6, 1, true, HolidayScope.KATHMANDU_VALLEY, FestivalCategory.REGIONAL_HOLIDAY, "Eight-day rain god festival; Kumari and Bhairav chariot pulling.", "Kathmandu Valley heritage."),
            createFestival("2081_sambidhan", "संविधान दिवस", "Constitution Day (National Day)", 2081, 6, 3, true, HolidayScope.NATIONWIDE, FestivalCategory.NATIONAL_HOLIDAY, "Commemorating the Constitution of Nepal passed in 2072 BS.", "National sovereignty."),
            // Dashain 2081
            createFestival("2081_ghatasthapana", "घटस्थापना (दशैं आरम्भ)", "Ghatasthapana (Dashain Begins)", 2081, 6, 17, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "First day of Bada Dashain, establishing the sacred Kalash and barley seeds.", "Auspicious invocation of Shakti."),
            createFestival("2081_fulpati", "फूलपाती", "Fulpati (Maha Saptami)", 2081, 6, 24, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Sacred Fulpati foliage brought to Hanuman Dhoka; government offices close.", "Beginning of grand Dashain holidays."),
            createFestival("2081_ashtami", "महा अष्टमी", "Maha Ashtami", 2081, 6, 25, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Worship of Mahakali; night-long Kalaratri pujas.", "Courage and warding off negativity."),
            createFestival("2081_nawami", "महा नवमी", "Maha Nawami", 2081, 6, 26, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Blessings of machinery, vehicles, and artisanal instruments.", "Dignity of instruments and protection."),
            createFestival("2081_dashami", "विजया दशमी", "Vijaya Dashami (Bada Dashain)", 2081, 6, 27, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Red Tika, yellow Jamara, and elderly blessings for success and longevity.", "Apex of the Nepali festive calendar."),
            createFestival("2081_dashami_p2", "दशैं बिदा (एकादशी)", "Dashain Holiday (Papankusha Ekadashi)", 2081, 6, 28, true, HolidayScope.NATIONWIDE, FestivalCategory.NATIONAL_HOLIDAY, "Continuing Dashain visiting and feasting with relatives.", "Family bonds and celebration."),
            createFestival("2081_dashami_p3", "दशैं बिदा (द्वादशी)", "Dashain Holiday (Dwadashi)", 2081, 6, 29, true, HolidayScope.NATIONWIDE, FestivalCategory.NATIONAL_HOLIDAY, "Continuing Dashain visits to extended maternal and paternal relations.", "Festive joy."),
            createFestival("2081_kojagrat", "कोजाग्रत पूर्णिमा", "Kojagrat Purnima (Dashain Ends)", 2081, 6, 30, false, HolidayScope.NATIONWIDE, FestivalCategory.CULTURAL_EVENT, "Final night of Dashain; vigil for Goddess Laxmi.", "Prosperity."),
            // Tihar 2081
            createFestival("2081_kagtihar", "काग तिहार / धनतेरस", "Kag Tihar (Dhanteras)", 2081, 7, 13, false, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Feeding the crows and purchasing auspicious metal utensils on Dhanteras.", "Nature reverence and health."),
            createFestival("2081_kukurtihar", "कुकुर तिहार र लक्ष्मी पूजा", "Kukur Tihar & Laxmi Puja", 2081, 7, 15, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Honoring loyal canines in morning; evening illuminations and Laxmi Puja.", "Light overcoming darkness and companionship."),
            createFestival("2081_govardhan", "गोवर्धन पूजा / म्ह पूजा", "Govardhan Puja & Mha Puja (Nepal Sambat 1145)", 2081, 7, 17, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Worship of Govardhan hill, holy cattle, and Newari Mha Puja; Newar New Year.", "Gratitude to Mother Earth."),
            createFestival("2081_bhaitika", "भाइटीका", "Bhai Tika (Tihar Finale)", 2081, 7, 18, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Sacred Saptarangi Tika from sisters to brothers; walnuts and Makhamali garlands.", "Lifelong sibling commitment."),
            createFestival("2081_chhath", "छठ पर्व", "Chhath Parva", 2081, 7, 22, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Sunset and sunrise arghya offerings to Lord Surya at Bagmati, Rani Pokhari, and Terai rivers.", "Devotion, purity, and environmental sanctity."),
            createFestival("2081_christmas", "क्रिसमस डे", "Christmas Day", 2081, 9, 10, true, HolidayScope.NATIONWIDE, FestivalCategory.RELIGIOUS_CELEBRATION, "Christmas celebration.", "Joy, love, and community peace."),
            createFestival("2081_tamu", "तमु ल्होसार", "Tamu Lhosar", 2081, 9, 15, true, HolidayScope.NATIONWIDE, FestivalCategory.CULTURAL_EVENT, "Gurung New Year celebration with Syarghe dances.", "Indigenous pride."),
            createFestival("2081_prithvi", "पृथ्वी जयन्ती", "Prithvi Jayanti / National Unity Day", 2081, 9, 27, true, HolidayScope.NATIONWIDE, FestivalCategory.NATIONAL_HOLIDAY, "Honoring nation builder King Prithvi Narayan Shah.", "National unification."),
            createFestival("2081_maghe", "माघे संक्रान्ति", "Maghe Sankranti / Maghi", 2081, 10, 1, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Winter celebration with Til laddu, Yam, Ghee, and Chaku; Tharu Maghi.", "Health, warmth, and seasonal transition."),
            createFestival("2081_shahid", "सहिद दिवस", "Martyrs' Day (Shahid Diwas)", 2081, 10, 16, false, HolidayScope.NATIONWIDE, FestivalCategory.NATIONAL_HOLIDAY, "Remembering martyrs Shukraraj, Dharma Bhakta, Ganga Lal, Dasharath Chand.", "Patriotism and freedom."),
            createFestival("2081_sonam", "सोनाम ल्होसार", "Sonam Lhosar", 2081, 10, 16, true, HolidayScope.NATIONWIDE, FestivalCategory.CULTURAL_EVENT, "Tamang New Year; Losar rituals at monasteries.", "Rebirth and hope."),
            createFestival("2081_saraswati", "वसन्त पञ्चमी / सरस्वती पूजा", "Basanta Panchami (Saraswati Puja)", 2081, 10, 20, false, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Blessing of books, pens, and musical instruments; initiation of toddlers in literacy.", "Knowledge and the arrival of Spring."),
            createFestival("2081_prajatantra", "राष्ट्रिय प्रजातन्त्र दिवस", "National Democracy Day", 2081, 11, 7, true, HolidayScope.NATIONWIDE, FestivalCategory.NATIONAL_HOLIDAY, "Historic 2007 BS overthrow of autocracy.", "Foundation of democracy."),
            createFestival("2081_shivaratri", "महाशिवरात्रि", "Maha Shivaratri", 2081, 11, 14, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Holy night of Lord Shiva with hundreds of thousands visiting Pashupatinath.", "Inner awakening and devotion."),
            createFestival("2081_gyalpo", "ग्याल्पो ल्होसार", "Gyalpo Lhosar", 2081, 11, 16, true, HolidayScope.NATIONWIDE, FestivalCategory.CULTURAL_EVENT, "Sherpa, Hyolmo, and Bhutia New Year celebration.", "Highland culture."),
            createFestival("2081_women", "अन्तर्राष्ट्रिय महिला दिवस", "International Women's Day", 2081, 11, 24, true, HolidayScope.WOMEN_ONLY, FestivalCategory.NATIONAL_HOLIDAY, "Global women's solidarity and empowerment day.", "Gender equality and social progress."),
            createFestival("2081_holi_pahad", "फागु पूर्णिमा (पहाड)", "Holi / Fagu Purnima (Hills)", 2081, 11, 29, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Festival of vibrant colors, music, and joy across hilly districts.", "Color and brotherhood."),
            createFestival("2081_holi_terai", "फागु पूर्णिमा (तराई)", "Holi / Fagu Purnima (Terai)", 2081, 12, 1, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Vibrant Holi celebrations across the southern plains of Terai-Madhesh.", "Communal harmony and merriment."),
            createFestival("2081_ghodejatra", "घोडेजात्रा", "Ghode Jatra", 2081, 12, 15, true, HolidayScope.KATHMANDU_VALLEY, FestivalCategory.REGIONAL_HOLIDAY, "Valley horse race and cavalry drills at Tundikhel to pacify demon Gurumapa.", "Valley protective ritual."),
            createFestival("2081_ramnavami_end", "रामनवमी", "Ram Navami", 2081, 12, 24, false, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Birth anniversary of Lord Shri Ram.", "Virtue and righteousness.")
        )

        // -------------------------------------------------------------
        // 2082 BS (2025 - 2026 AD)
        // -------------------------------------------------------------
        YEARLY_FESTIVALS[2082] = listOf(
            createFestival("2082_ny", "नयाँ वर्ष", "Nepali New Year 2082", 2082, 1, 1, true, HolidayScope.NATIONWIDE, FestivalCategory.NATIONAL_HOLIDAY, "First day of Bikram Sambat 2082.", "New Year celebration."),
            createFestival("2082_majdur", "मजदुर दिवस", "International Workers' Day", 2082, 1, 18, true, HolidayScope.NATIONWIDE, FestivalCategory.NATIONAL_HOLIDAY, "Labour Day celebration.", "Workers' welfare."),
            createFestival("2082_buddha", "बुद्ध जयन्ती / उभौली", "Buddha Jayanti & Ubhauli Parva", 2082, 1, 29, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Lord Buddha's birth in Kapilvastu, Lumbini and Kirati Ubhauli.", "Ahimsa and enlightenment."),
            createFestival("2082_gantantra", "गणतन्त्र दिवस", "Republic Day", 2082, 2, 15, true, HolidayScope.NATIONWIDE, FestivalCategory.NATIONAL_HOLIDAY, "Federal Democratic Republic of Nepal Day.", "Constitutional republic."),
            createFestival("2082_janai", "जनै पूर्णिमा / रक्षाबन्धन", "Janai Purnima & Raksha Bandhan", 2082, 4, 24, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Sacred thread change and protective cord on wrists.", "Purification."),
            createFestival("2082_gaijatra", "गाईजात्रा", "Gai Jatra", 2082, 4, 25, true, HolidayScope.KATHMANDU_VALLEY, FestivalCategory.REGIONAL_HOLIDAY, "Honoring departed ancestors.", "Remembrance."),
            createFestival("2082_krishna", "श्रीकृष्ण जन्माष्टमी", "Krishna Janmashtami", 2082, 5, 1, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Birth of Lord Krishna.", "Spiritual devotion."),
            createFestival("2082_teej", "हरितालिका तीज", "Haritalika Teej", 2082, 5, 10, true, HolidayScope.WOMEN_ONLY, FestivalCategory.MAJOR_FESTIVAL, "Great festival of Hindu women.", "Fasting and celebration."),
            createFestival("2082_rishi", "ऋषि पञ्चमी", "Rishi Panchami", 2082, 5, 12, false, HolidayScope.WOMEN_ONLY, FestivalCategory.CULTURAL_EVENT, "Veneration of Saptarshi.", "Purification."),
            createFestival("2082_indrajatra", "इन्द्रजात्रा", "Indra Jatra", 2082, 5, 20, true, HolidayScope.KATHMANDU_VALLEY, FestivalCategory.REGIONAL_HOLIDAY, "Kathmandu living goddess chariot procession.", "Valley thanksgiving."),
            createFestival("2082_sambidhan", "संविधान दिवस", "Constitution Day", 2082, 6, 3, true, HolidayScope.NATIONWIDE, FestivalCategory.NATIONAL_HOLIDAY, "National day celebrating the democratic constitution.", "Patriotism."),
            // Dashain 2082
            createFestival("2082_ghatasthapana", "घटस्थापना (दशैं आरम्भ)", "Ghatasthapana (Dashain Begins)", 2082, 6, 6, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Sowing of Jamara.", "Invocation of Durga."),
            createFestival("2082_fulpati", "फूलपाती", "Fulpati (Maha Saptami)", 2082, 6, 13, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Entry of royal Fulpati.", "Start of Dashain holidays."),
            createFestival("2082_ashtami", "महा अष्टमी", "Maha Ashtami", 2082, 6, 14, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Durga Kalaratri rites.", "Courage."),
            createFestival("2082_nawami", "महा नवमी", "Maha Nawami", 2082, 6, 15, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Blessing of tools.", "Reverence for skills."),
            createFestival("2082_dashami", "विजया दशमी", "Vijaya Dashami (Bada Dashain)", 2082, 6, 16, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Sacred Tika and Jamara.", "Blessings and family reunion."),
            createFestival("2082_kojagrat", "कोजाग्रत पूर्णिमा", "Kojagrat Purnima", 2082, 6, 20, false, HolidayScope.NATIONWIDE, FestivalCategory.CULTURAL_EVENT, "Dashain conclusion.", "Prosperity."),
            // Tihar 2082
            createFestival("2082_kagtihar", "काग तिहार", "Kag Tihar", 2082, 7, 3, false, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Reverence to crows.", "Nature connection."),
            createFestival("2082_kukurtihar", "कुकुर तिहार", "Kukur Tihar", 2082, 7, 4, false, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Honoring loyal canines.", "Loyalty."),
            createFestival("2082_laxmi", "लक्ष्मी पूजा", "Laxmi Puja (Deepawali)", 2082, 7, 5, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Lamps and wealth goddess worship.", "Prosperity."),
            createFestival("2082_govardhan", "गोवर्धन पूजा / म्ह पूजा", "Govardhan Puja & Mha Puja", 2082, 7, 6, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Cattle veneration and Mha Puja.", "Newar New Year."),
            createFestival("2082_bhaitika", "भाइटीका", "Bhai Tika", 2082, 7, 7, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Seven-color sister-brother Tika.", "Sibling bond."),
            createFestival("2082_chhath", "छठ पर्व", "Chhath Parva", 2082, 7, 10, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Sun worship and arghya offerings.", "Purity and health."),
            createFestival("2082_christmas", "क्रिसमस डे", "Christmas Day", 2082, 9, 10, true, HolidayScope.NATIONWIDE, FestivalCategory.RELIGIOUS_CELEBRATION, "Birth of Jesus Christ.", "Peace and love."),
            createFestival("2082_tamu", "तमु ल्होसार", "Tamu Lhosar", 2082, 9, 15, true, HolidayScope.NATIONWIDE, FestivalCategory.CULTURAL_EVENT, "Gurung New Year.", "Cultural heritage."),
            createFestival("2082_prithvi", "पृथ्वी जयन्ती", "Prithvi Jayanti", 2082, 9, 27, true, HolidayScope.NATIONWIDE, FestivalCategory.NATIONAL_HOLIDAY, "National Unity Day.", "National integration."),
            createFestival("2082_maghe", "माघे संक्रान्ति", "Maghe Sankranti", 2082, 10, 1, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Makar Sankranti & Tharu Maghi.", "Warm sweets and holy bath."),
            createFestival("2082_sonam", "सोनाम ल्होसार", "Sonam Lhosar", 2082, 10, 5, true, HolidayScope.NATIONWIDE, FestivalCategory.CULTURAL_EVENT, "Tamang New Year.", "Festivity."),
            createFestival("2082_saraswati", "वसन्त पञ्चमी / सरस्वती पूजा", "Basanta Panchami (Saraswati Puja)", 2082, 10, 9, false, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Worship of Saraswati.", "Arts and education."),
            createFestival("2082_shahid", "सहिद दिवस", "Martyrs' Day", 2082, 10, 16, false, HolidayScope.NATIONWIDE, FestivalCategory.NATIONAL_HOLIDAY, "Honoring brave martyrs.", "Sacrifice."),
            createFestival("2082_shivaratri", "महाशिवरात्रि", "Maha Shivaratri", 2082, 11, 3, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Night of Lord Shiva.", "Austerity and joy."),
            createFestival("2082_prajatantra", "राष्ट्रिय प्रजातन्त्र दिवस", "National Democracy Day", 2082, 11, 7, true, HolidayScope.NATIONWIDE, FestivalCategory.NATIONAL_HOLIDAY, "Fall of Rana regime.", "Democracy."),
            createFestival("2082_gyalpo", "ग्याल्पो ल्होसार", "Gyalpo Lhosar", 2082, 11, 6, true, HolidayScope.NATIONWIDE, FestivalCategory.CULTURAL_EVENT, "Sherpa New Year.", "Highland traditions."),
            createFestival("2082_women", "अन्तर्राष्ट्रिय महिला दिवस", "International Women's Day", 2082, 11, 24, true, HolidayScope.WOMEN_ONLY, FestivalCategory.NATIONAL_HOLIDAY, "Women's rights day.", "Empowerment."),
            createFestival("2082_holi_pahad", "फागु पूर्णिमा (पहाड)", "Holi / Fagu Purnima (Hills)", 2082, 11, 18, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Colors and celebration in hills.", "Joy."),
            createFestival("2082_holi_terai", "फागु पूर्णिमा (तराई)", "Holi / Fagu Purnima (Terai)", 2082, 11, 19, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Colors and festivity in Terai.", "Harmony."),
            createFestival("2082_ghodejatra", "घोडेजात्रा", "Ghode Jatra", 2082, 12, 4, true, HolidayScope.KATHMANDU_VALLEY, FestivalCategory.REGIONAL_HOLIDAY, "Valley horse festival.", "Ancient pageant."),
            createFestival("2082_ramnavami", "रामनवमी", "Ram Navami", 2082, 12, 13, false, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Appearance of Lord Ram.", "Virtue.")
        )

        // -------------------------------------------------------------
        // 2083 BS (2026 - 2027 AD) — Including current simulated system era
        // -------------------------------------------------------------
        YEARLY_FESTIVALS[2083] = listOf(
            createFestival("2083_ny", "नयाँ वर्ष", "Nepali New Year 2083", 2083, 1, 1, true, HolidayScope.NATIONWIDE, FestivalCategory.NATIONAL_HOLIDAY, "First day of Bikram Sambat 2083.", "New Year nationwide celebration."),
            createFestival("2083_majdur", "मजदुर दिवस", "International Workers' Day", 2083, 1, 18, true, HolidayScope.NATIONWIDE, FestivalCategory.NATIONAL_HOLIDAY, "May Day workers' rights.", "Labour dignity."),
            createFestival("2083_buddha", "बुद्ध जयन्ती / उभौली", "Buddha Jayanti & Ubhauli Parva", 2083, 1, 18, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Birth anniversary of Lord Buddha and Kirat Ubhauli.", "Peace and brotherhood."),
            createFestival("2083_gantantra", "गणतन्त्र दिवस", "Republic Day", 2083, 2, 15, true, HolidayScope.NATIONWIDE, FestivalCategory.NATIONAL_HOLIDAY, "Celebration of Nepal Republic.", "Democratic pride."),
            createFestival("2083_janai", "जनै पूर्णिमा / रक्षाबन्धन", "Janai Purnima & Raksha Bandhan", 2083, 4, 12, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Sacred thread changing and Raksha Bandhan protection bond; Newari Kwati Punhi.", "Spiritual protection and sibling bond."),
            createFestival("2083_gaijatra", "गाईजात्रा", "Gai Jatra", 2083, 4, 13, true, HolidayScope.KATHMANDU_VALLEY, FestivalCategory.REGIONAL_HOLIDAY, "Valley ancestral remembrance and satire parade.", "Catharsis and remembrance."),
            createFestival("2083_krishna", "श्रीकृष्ण जन्माष्टमी", "Krishna Janmashtami", 2083, 5, 19, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Celebration of the birth of Lord Krishna at Patan and throughout Nepal.", "Divine love and dharma."),
            createFestival("2083_teej", "हरितालिका तीज", "Haritalika Teej", 2083, 5, 29, true, HolidayScope.WOMEN_ONLY, FestivalCategory.MAJOR_FESTIVAL, "Grand festival of Hindu women with fasting, singing, and red sarees.", "Spousal longevity and female solidarity."),
            createFestival("2083_sambidhan", "संविधान दिवस", "Constitution Day", 2083, 6, 3, true, HolidayScope.NATIONWIDE, FestivalCategory.NATIONAL_HOLIDAY, "National Constitution Day of Nepal.", "National pride and sovereignty."),
            createFestival("2083_indrajatra", "इन्द्रजात्रा", "Indra Jatra", 2083, 6, 9, true, HolidayScope.KATHMANDU_VALLEY, FestivalCategory.REGIONAL_HOLIDAY, "Grand chariot festival of Living Goddess Kumari in Kathmandu Durbar Square.", "Harvest thanksgiving and divine protection."),
            // Dashain 2083
            createFestival("2083_ghatasthapana", "घटस्थापना (दशैं आरम्भ)", "Ghatasthapana (Dashain Begins)", 2083, 6, 25, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Sowing of sacred Jamara and beginning of Navaratri.", "Invocation of Goddess Durga."),
            createFestival("2083_fulpati", "फूलपाती", "Fulpati (Maha Saptami)", 2083, 7, 1, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Official entry of Fulpati palanquin; national holidays begin.", "Start of Dashain grand celebrations."),
            createFestival("2083_ashtami", "महा अष्टमी", "Maha Ashtami", 2083, 7, 2, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Veneration of Goddess Mahakali; Kalaratri rituals.", "Courage and spiritual awakening."),
            createFestival("2083_nawami", "महा नवमी", "Maha Nawami", 2083, 7, 3, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Blessings of instruments, machinery, and craft tools.", "Honoring work and creativity."),
            createFestival("2083_dashami", "विजया दशमी", "Vijaya Dashami (Bada Dashain)", 2083, 7, 4, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Receiving auspicious Tika and Jamara from elders with blessings.", "Victory of righteousness over evil."),
            createFestival("2083_kojagrat", "कोजाग्रत पूर्णिमा", "Kojagrat Purnima", 2083, 7, 8, false, HolidayScope.NATIONWIDE, FestivalCategory.CULTURAL_EVENT, "Vigil for Goddess Laxmi concluding Bada Dashain.", "Prosperity."),
            // Tihar 2083
            createFestival("2083_kagtihar", "काग तिहार", "Kag Tihar (Dhanteras)", 2083, 7, 23, false, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Feeding crows and beginning of Yamapanchak festival of lights.", "Nature harmony."),
            createFestival("2083_kukurtihar", "कुकुर तिहार", "Kukur Tihar", 2083, 7, 24, false, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Garlanding and honoring faithful canine protectors.", "Loyalty and unconditional love."),
            createFestival("2083_laxmi", "लक्ष्मी पूजा", "Laxmi Puja (Deepawali)", 2083, 7, 24, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Evening illuminations with Diyo lamps and worship of wealth goddess Laxmi.", "Light, auspiciousness, and joy."),
            createFestival("2083_govardhan", "गोवर्धन पूजा / म्ह पूजा", "Govardhan Puja & Mha Puja (Nepal Sambat 1147)", 2083, 7, 25, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Worship of cattle and self-purification ritual of Mha Puja; Newar New Year.", "Ecology and self-worth."),
            createFestival("2083_bhaitika", "भाइटीका", "Bhai Tika (Tihar Finale)", 2083, 7, 26, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Seven-color Saptarangi Tika from sisters to brothers for protection and longevity.", "Eternal sacred bond between siblings."),
            createFestival("2083_chhath", "छठ पर्व", "Chhath Parva", 2083, 7, 30, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Veneration of Sun God (Surya) and Chhathi Maiya at sacred riverbanks.", "Purity, universal health, and vitality."),
            createFestival("2083_christmas", "क्रिसमस डे", "Christmas Day", 2083, 9, 10, true, HolidayScope.NATIONWIDE, FestivalCategory.RELIGIOUS_CELEBRATION, "Christmas celebration.", "Peace and brotherhood."),
            createFestival("2083_tamu", "तमु ल्होसार", "Tamu Lhosar", 2083, 9, 15, true, HolidayScope.NATIONWIDE, FestivalCategory.CULTURAL_EVENT, "Gurung New Year.", "Indigenous heritage."),
            createFestival("2083_prithvi", "पृथ्वी जयन्ती", "Prithvi Jayanti / National Unity Day", 2083, 9, 27, true, HolidayScope.NATIONWIDE, FestivalCategory.NATIONAL_HOLIDAY, "National Unity Day.", "Unification of Nepal."),
            createFestival("2083_maghe", "माघे संक्रान्ति", "Maghe Sankranti / Maghi", 2083, 10, 1, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Makar Sankranti & Tharu New Year.", "Warm delicacies and spiritual holy bath."),
            createFestival("2083_shahid", "सहिद दिवस", "Martyrs' Day", 2083, 10, 16, false, HolidayScope.NATIONWIDE, FestivalCategory.NATIONAL_HOLIDAY, "Homage to national martyrs.", "Patriotism."),
            createFestival("2083_saraswati", "वसन्त पञ्चमी / सरस्वती पूजा", "Basanta Panchami (Saraswati Puja)", 2083, 10, 28, false, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Goddess of Knowledge worship.", "Learning and Spring."),
            createFestival("2083_prajatantra", "राष्ट्रिय प्रजातन्त्र दिवस", "National Democracy Day", 2083, 11, 7, true, HolidayScope.NATIONWIDE, FestivalCategory.NATIONAL_HOLIDAY, "Historic democracy celebration.", "Freedom from tyranny."),
            createFestival("2083_shivaratri", "महाशिवरात्रि", "Maha Shivaratri", 2083, 11, 22, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Great night of Lord Shiva at Pashupatinath.", "Austerity and spiritual joy."),
            createFestival("2083_women", "अन्तर्राष्ट्रिय महिला दिवस", "International Women's Day", 2083, 11, 24, true, HolidayScope.WOMEN_ONLY, FestivalCategory.NATIONAL_HOLIDAY, "Women's rights day.", "Gender equality."),
            createFestival("2083_holi_pahad", "फागु पूर्णिमा (पहाड)", "Holi / Fagu Purnima (Hills)", 2083, 12, 8, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Festival of colors in hilly districts.", "Joy and harmony."),
            createFestival("2083_holi_terai", "फागु पूर्णिमा (तराई)", "Holi / Fagu Purnima (Terai)", 2083, 12, 9, true, HolidayScope.NATIONWIDE, FestivalCategory.MAJOR_FESTIVAL, "Festival of colors in Terai plains.", "Festive celebration."),
            createFestival("2083_ghodejatra", "घोडेजात्रा", "Ghode Jatra", 2083, 12, 23, true, HolidayScope.KATHMANDU_VALLEY, FestivalCategory.REGIONAL_HOLIDAY, "Horse parade at Tundikhel.", "Valley pageant.")
        )
    }

    private fun createFestival(
        id: String,
        nameNe: String,
        nameEn: String,
        year: Int,
        month: Int,
        day: Int,
        isPublicHoliday: Boolean,
        scope: HolidayScope,
        category: FestivalCategory,
        description: String,
        significance: String,
        isProvisional: Boolean = false
    ): NepaliFestival {
        return NepaliFestival(
            id = id,
            nameNe = nameNe,
            nameEn = nameEn,
            bsYear = year,
            bsMonth = month,
            bsDay = day,
            isPublicHoliday = isPublicHoliday,
            holidayScope = scope,
            category = category,
            description = description,
            significance = significance,
            source = "Ministry of Home Affairs, Government of Nepal / Nepal Panchanga Nirnayak Bikas Samiti",
            isProvisional = isProvisional
        )
    }

    /**
     * Retrieves all festivals and public holidays falling on a specific Bikram Sambat date.
     */
    fun getFestivalsForBsDate(date: NepaliDate): List<NepaliFestival> {
        val specificList = YEARLY_FESTIVALS[date.year] ?: emptyList()
        val matched = specificList.filter { it.bsMonth == date.month && it.bsDay == date.day }

        if (matched.isNotEmpty()) {
            return matched
        }

        // Check solar-fixed recurring events for years where full lunar Panchanga gazette is yet to be published
        val recurring = RECURRING_SOLAR_HOLIDAYS.firstOrNull { it.first.first == date.month && it.first.second == date.day }
        if (recurring != null) {
            return listOf(
                createFestival(
                    id = "${date.year}_${date.month}_${date.day}",
                    nameNe = recurring.second.first,
                    nameEn = recurring.first.third,
                    year = date.year,
                    month = date.month,
                    day = date.day,
                    isPublicHoliday = recurring.second.second,
                    scope = HolidayScope.NATIONWIDE,
                    category = FestivalCategory.NATIONAL_HOLIDAY,
                    description = recurring.second.third,
                    significance = "Annual national celebration.",
                    isProvisional = date.year > 2083
                )
            )
        }

        return emptyList()
    }

    /**
     * Retrieves all festivals and holidays for an entire BS month.
     */
    fun getFestivalsForMonth(bsYear: Int, bsMonth: Int): List<NepaliFestival> {
        val list = YEARLY_FESTIVALS[bsYear] ?: emptyList()
        val monthList = list.filter { it.bsMonth == bsMonth }
        if (monthList.isNotEmpty()) {
            return monthList.sortedBy { it.bsDay }
        }

        // Fallback for solar recurring
        return RECURRING_SOLAR_HOLIDAYS
            .filter { it.first.first == bsMonth }
            .map { (dateKey, info) ->
                createFestival(
                    id = "${bsYear}_${bsMonth}_${dateKey.second}",
                    nameNe = info.first,
                    nameEn = dateKey.third,
                    year = bsYear,
                    month = bsMonth,
                    day = dateKey.second,
                    isPublicHoliday = info.second,
                    scope = HolidayScope.NATIONWIDE,
                    category = FestivalCategory.NATIONAL_HOLIDAY,
                    description = info.third,
                    significance = "Annual national celebration.",
                    isProvisional = bsYear > 2083
                )
            }
            .sortedBy { it.bsDay }
    }

    /**
     * Retrieves upcoming festivals starting from a given BS date.
     */
    fun getUpcomingFestivals(fromBsDate: NepaliDate, limit: Int = 10): List<NepaliFestival> {
        val allFestivals = mutableListOf<NepaliFestival>()
        val startYear = fromBsDate.year
        for (y in startYear..(startYear + 1)) {
            val yrList = YEARLY_FESTIVALS[y] ?: emptyList()
            allFestivals.addAll(yrList)
        }

        return allFestivals
            .filter { it.bsDate >= fromBsDate }
            .sortedBy { it.bsDate }
            .take(limit)
    }

    /**
     * Retrieves upcoming officially declared public holidays starting from a given BS date.
     */
    fun getUpcomingPublicHolidays(fromBsDate: NepaliDate, limit: Int = 10): List<NepaliFestival> {
        return getUpcomingFestivals(fromBsDate, limit = 50)
            .filter { it.isPublicHoliday }
            .take(limit)
    }

    /**
     * Identifies the next major festival and calculates days remaining from a given BS date.
     */
    fun getNextMajorFestival(fromBsDate: NepaliDate): Pair<NepaliFestival, Long>? {
        val upcoming = getUpcomingFestivals(fromBsDate, limit = 15)
            .filter { it.category == FestivalCategory.MAJOR_FESTIVAL || it.isPublicHoliday }
            .firstOrNull { it.bsDate >= fromBsDate } ?: return null

        val fromAd = NepaliDateConverter.bsToAd(fromBsDate)
        val eventAd = NepaliDateConverter.bsToAd(upcoming.bsDate)
        val daysRemain = ChronoUnit.DAYS.between(fromAd.toLocalDate(), eventAd.toLocalDate())
        return Pair(upcoming, maxOf(0L, daysRemain))
    }

    /**
     * Checks if today has special occasions or festivals.
     */
    fun getTodaySpecialOccasions(todayBs: NepaliDate): List<NepaliFestival> {
        return getFestivalsForBsDate(todayBs)
    }

    /**
     * Returns only calendar events with a verified Bikram Sambat date (!isProvisional and valid BS calendar bounds).
     */
    fun getVerifiedEventsForBsDate(date: NepaliDate): List<NepaliFestival> {
        if (!NepaliDateConverter.isBsYearSupported(date.year)) return emptyList()
        val maxDay = NepaliDateConverter.getDaysInBsMonth(date.year, date.month)
        if (date.month !in 1..12 || date.day !in 1..maxDay) return emptyList()

        return getFestivalsForBsDate(date).filter { event ->
            !event.isProvisional &&
                event.bsYear == date.year &&
                event.bsMonth == date.month &&
                event.bsDay == date.day &&
                event.nameEn.isNotBlank()
        }.distinctBy { it.id }
    }

    /**
     * Returns tomorrow's NepaliDate, EnglishDate, and all verified calendar events occurring tomorrow
     * (i.e. exactly 1 day after todayAd in Asia/Kathmandu).
     */
    fun getTomorrowVerifiedEvents(
        todayAd: EnglishDate = NepaliDateConverter.todayAd(NepaliDateConverter.NEPAL_ZONE_ID)
    ): Triple<NepaliDate, EnglishDate, List<NepaliFestival>> {
        val tomorrowAd = EnglishDate.fromLocalDate(todayAd.toLocalDate().plusDays(1))
        val tomorrowBs = NepaliDateConverter.adToBs(tomorrowAd)
        val events = getVerifiedEventsForBsDate(tomorrowBs)
        return Triple(tomorrowBs, tomorrowAd, events)
    }

    /**
     * Finds the next future calendar date (strictly after todayBs) that has one or more verified events,
     * along with all verified events occurring on that date and days remaining from todayAd.
     */
    fun getNextUpcomingVerifiedEventGroup(
        todayAd: EnglishDate = NepaliDateConverter.todayAd(NepaliDateConverter.NEPAL_ZONE_ID)
    ): Triple<NepaliDate, List<NepaliFestival>, Long>? {
        val todayBs = NepaliDateConverter.adToBs(todayAd)
        val upcoming = getUpcomingFestivals(todayBs, limit = 50)
            .filter { !it.isProvisional && it.bsDate > todayBs }
        val nextDate = upcoming.firstOrNull()?.bsDate ?: return null
        val eventsOnNextDate = getVerifiedEventsForBsDate(nextDate)
        if (eventsOnNextDate.isEmpty()) return null
        val eventAd = NepaliDateConverter.bsToAd(nextDate)
        val daysUntil = ChronoUnit.DAYS.between(todayAd.toLocalDate(), eventAd.toLocalDate())
        return Triple(nextDate, eventsOnNextDate, maxOf(1L, daysUntil))
    }
}
