package com.example.data.remote

import com.example.data.model.NewsArticle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.CacheControl
import okhttp3.Request
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.StringReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

class NewsRssService {

    data class FeedSource(
        val publisherName: String,
        val url: String,
        val defaultCategory: String
    )

    private val rssHttpClient by lazy {
        ApiClient.okHttpClient.newBuilder()
            .connectTimeout(7, TimeUnit.SECONDS)
            .readTimeout(7, TimeUnit.SECONDS)
            .callTimeout(8, TimeUnit.SECONDS)
            .build()
    }

    private val feedSources = listOf(
        // Nepal Local Sources (Direct + Real-Time Aggregated Nepal Feeds)
        FeedSource("OnlineKhabar English", "https://english.onlinekhabar.com/feed", "Nepal News"),
        FeedSource("Nepali Times", "https://nepalitimes.com/feed", "Nepal News"),
        FeedSource("The Kathmandu Post", "https://kathmandupost.com/rss", "Nepal News"),
        FeedSource("The Himalayan Times", "https://thehimalayantimes.com/rss", "Nepal News"),
        FeedSource("Setopati English", "https://en.setopati.com/feed", "Nepal News"),
        FeedSource("Ratopati English", "https://english.ratopati.com/feed", "Nepal News"),
        FeedSource("Nepal Live News", "https://news.google.com/rss/search?q=Nepal+Kathmandu+when:2d&hl=en-NP&gl=NP&ceid=NP:en", "Nepal News"),
        FeedSource("Nepal Politics & Governance", "https://news.google.com/rss/search?q=Nepal+Government+Parliament+Politics+when:3d&hl=en-NP&gl=NP&ceid=NP:en", "Politics"),

        // International Top & World Sources
        FeedSource("BBC World News", "https://feeds.bbci.co.uk/news/world/rss.xml", "World News"),
        FeedSource("BBC South Asia", "https://feeds.bbci.co.uk/news/world/asia/rss.xml", "World News"),
        FeedSource("Al Jazeera English", "https://www.aljazeera.com/xml/rss/all.xml", "World News"),
        FeedSource("Global World Wire", "https://news.google.com/rss/headlines/section/topic/WORLD?hl=en-US&gl=US&ceid=US:en", "World News"),

        // Business, Finance, Gold & Economy
        FeedSource("BBC Business", "https://feeds.bbci.co.uk/news/business/rss.xml", "Business and Economy"),
        FeedSource("CNBC Global Markets", "https://search.cnbc.com/rs/search/view.html?partnerId=2000&keywords=cnbcnews&sort=date&type=rss", "Business and Economy"),
        FeedSource("Nepal Economy & NRB", "https://news.google.com/rss/search?q=Nepal+Economy+Bank+NEPSE+when:3d&hl=en-NP&gl=NP&ceid=NP:en", "Business and Economy"),
        FeedSource("Gold & Bullion Market", "https://news.google.com/rss/search?q=Gold+Price+Silver+Bullion+Market+when:3d&hl=en-US&gl=US&ceid=US:en", "Gold and Precious Metals"),

        // Technology, AI & Science
        FeedSource("TechCrunch", "https://techcrunch.com/feed/", "Technology and AI"),
        FeedSource("BBC Technology", "https://feeds.bbci.co.uk/news/technology/rss.xml", "Technology and AI"),
        FeedSource("NASA Science", "https://www.nasa.gov/rss/dyn/breaking_news.rss", "Science"),
        FeedSource("BBC Science & Environment", "https://feeds.bbci.co.uk/news/science_and_environment/rss.xml", "Science"),

        // Crypto & Digital Assets
        FeedSource("CoinDesk", "https://www.coindesk.com/arc/outboundfeeds/rss/", "Cryptocurrency"),
        FeedSource("CoinTelegraph", "https://cointelegraph.com/rss", "Cryptocurrency"),

        // Weather, Sports, Health & Entertainment
        FeedSource("Nepal & Himalaya Weather", "https://news.google.com/rss/search?q=Nepal+Weather+Monsoon+Climate+when:3d&hl=en-NP&gl=NP&ceid=NP:en", "Weather and Climate"),
        FeedSource("BBC Sport", "https://feeds.bbci.co.uk/sport/rss.xml", "Sports"),
        FeedSource("BBC Health", "https://feeds.bbci.co.uk/news/health/rss.xml", "Health and Science"),
        FeedSource("BBC Entertainment & Arts", "https://feeds.bbci.co.uk/news/entertainment_and_arts/rss.xml", "Entertainment")
    )

    suspend fun fetchAllFeeds(): List<NewsArticle> = withContext(Dispatchers.IO) {
        val deferredList = feedSources.map { source ->
            async {
                withTimeoutOrNull(8500L) {
                    fetchFeed(source)
                } ?: emptyList()
            }
        }
        val results = deferredList.awaitAll().flatten()
        if (results.isEmpty()) return@withContext emptyList()

        // Deduplicate by normalized title
        val seenTitles = mutableSetOf<String>()
        val deduplicated = mutableListOf<NewsArticle>()

        for (item in results) {
            val key = item.title.lowercase().trim().replace(Regex("[^a-z0-9]"), "")
            if (key.length > 5 && !seenTitles.contains(key)) {
                seenTitles.add(key)
                deduplicated.add(item)
            }
        }

        // Sort by publication time descending (newest first)
        val sorted = deduplicated.sortedByDescending { it.pubDateMillis }

        // Recalculate freshness relative to the newest live feed item or system clock
        // so that even if the emulator/device clock differs from RSS feed clocks, live articles show accurate freshness
        val latestArticleMillis = sorted.firstOrNull()?.pubDateMillis ?: System.currentTimeMillis()
        val referenceMillis = minOf(System.currentTimeMillis(), latestArticleMillis + 60_000L)

        sorted.map { article ->
            val (formattedDate, freshnessLabel) = calculateFreshness(article.pubDateMillis, referenceMillis)
            val isBreaking = (referenceMillis - article.pubDateMillis) in 0L..(120 * 60 * 1000L)
            article.copy(
                pubDateFormatted = formattedDate,
                freshnessLabel = freshnessLabel,
                isBreaking = isBreaking
            )
        }
    }

    private suspend fun fetchFeed(source: FeedSource): List<NewsArticle> = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url(source.url)
                .cacheControl(CacheControl.FORCE_NETWORK)
                .build()
            rssHttpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext emptyList()
                val xml = response.body?.string() ?: return@withContext emptyList()
                if (xml.isBlank()) return@withContext emptyList()
                parseRssXml(xml, source)
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    internal fun parseRssXml(xml: String, source: FeedSource): List<NewsArticle> {
        val articles = mutableListOf<NewsArticle>()
        val factory = XmlPullParserFactory.newInstance().apply {
            isNamespaceAware = false
        }
        val parser = factory.newPullParser()
        parser.setInput(StringReader(xml.trim()))

        var eventType = parser.eventType
        var inItem = false

        var title = ""
        var link = ""
        var description = ""
        var pubDateRaw = ""
        var category = source.defaultCategory
        var imageUrl: String? = null
        var itemSourcePublisher = ""

        val currentTime = System.currentTimeMillis()

        while (eventType != XmlPullParser.END_DOCUMENT) {
            try {
                val rawTagName = parser.name ?: ""
                val tagName = rawTagName.lowercase(Locale.ENGLISH)

                when (eventType) {
                    XmlPullParser.START_TAG -> {
                        if (tagName == "item" || tagName == "entry") {
                            inItem = true
                            title = ""
                            link = ""
                            description = ""
                            pubDateRaw = ""
                            category = source.defaultCategory
                            imageUrl = null
                            itemSourcePublisher = ""
                        } else if (inItem) {
                            when {
                                tagName == "title" -> {
                                    val t = readTagTextSafely(parser).trim()
                                    if (t.isNotBlank()) title = t
                                }
                                tagName == "link" -> {
                                    val rel = parser.getAttributeValue(null, "rel")
                                    val href = parser.getAttributeValue(null, "href")
                                    val textLink = readTagTextSafely(parser).trim()
                                    val candidate = if (!href.isNullOrBlank() && (rel == null || rel == "alternate")) {
                                        href.trim()
                                    } else {
                                        textLink
                                    }
                                    if (candidate.isNotBlank() && link.isBlank()) {
                                        link = candidate
                                    }
                                }
                                tagName == "guid" && link.isBlank() -> {
                                    val guidText = readTagTextSafely(parser).trim()
                                    if (guidText.startsWith("http://") || guidText.startsWith("https://")) {
                                        link = guidText
                                    }
                                }
                                tagName == "description" || tagName == "summary" || tagName == "content:encoded" -> {
                                    val descText = readTagTextSafely(parser).trim()
                                    if (descText.isNotBlank() && (description.isBlank() || tagName != "content:encoded")) {
                                        description = descText
                                    }
                                }
                                tagName == "pubdate" || tagName == "published" || tagName == "updated" || tagName == "dc:date" -> {
                                    val d = readTagTextSafely(parser).trim()
                                    if (d.isNotBlank() && pubDateRaw.isBlank()) {
                                        pubDateRaw = d
                                    }
                                }
                                tagName == "source" -> {
                                    val srcText = readTagTextSafely(parser).trim()
                                    if (srcText.isNotBlank()) {
                                        itemSourcePublisher = srcText
                                    }
                                }
                                tagName == "category" -> {
                                    val catText = readTagTextSafely(parser).trim()
                                    if (catText.isNotBlank()) {
                                        category = mapToAppCategory(catText, source.defaultCategory)
                                    }
                                }
                                tagName == "enclosure" || tagName == "media:content" || tagName == "media:thumbnail" -> {
                                    val url = parser.getAttributeValue(null, "url")
                                    if (!url.isNullOrBlank() && imageUrl == null) {
                                        imageUrl = url
                                    }
                                }
                            }
                        }
                    }
                    XmlPullParser.END_TAG -> {
                        if (tagName == "item" || tagName == "entry") {
                            inItem = false
                            if (title.isNotBlank() && link.isNotBlank()) {
                                var cleanTitle = cleanHtml(title)
                                var resolvedPublisher = if (itemSourcePublisher.isNotBlank()) {
                                    cleanHtml(itemSourcePublisher)
                                } else {
                                    source.publisherName
                                }

                                // Google News titles often end with " - Publisher Name"; strip duplicate suffix cleanly
                                if (itemSourcePublisher.isNotBlank() && cleanTitle.endsWith(" - $resolvedPublisher")) {
                                    cleanTitle = cleanTitle.removeSuffix(" - $resolvedPublisher").trim()
                                }

                                val cleanDesc = cleanHtml(description)
                                    .removePrefix(cleanTitle)
                                    .trim()

                                val pubDateMillis = parsePubDate(pubDateRaw, currentTime)
                                val (formattedDate, freshnessLabel) = calculateFreshness(pubDateMillis, currentTime)
                                val isBreaking = (currentTime - pubDateMillis) in 0L..(90 * 60 * 1000L)

                                val finalCategory = if (category == source.defaultCategory) {
                                    inferCategoryFromContent(cleanTitle, cleanDesc, source.defaultCategory)
                                } else category

                                val summaryText = if (cleanDesc.length > 25 && !cleanDesc.equals(cleanTitle, ignoreCase = true)) {
                                    cleanDesc
                                } else {
                                    "$cleanTitle — Reported by $resolvedPublisher."
                                }

                                val aiSummary = generateEditorialSummary(cleanTitle, summaryText)

                                articles.add(
                                    NewsArticle(
                                        id = (link + cleanTitle).hashCode().toString(),
                                        title = cleanTitle,
                                        summary = summaryText,
                                        sourceName = resolvedPublisher,
                                        sourceUrl = link,
                                        imageUrl = imageUrl,
                                        pubDateMillis = pubDateMillis,
                                        pubDateFormatted = formattedDate,
                                        freshnessLabel = freshnessLabel,
                                        category = finalCategory,
                                        isBreaking = isBreaking,
                                        isBookmarked = false,
                                        aiSummary = aiSummary
                                    )
                                )
                            }
                        }
                    }
                }
                eventType = parser.next()
            } catch (_: Exception) {
                try {
                    eventType = parser.next()
                } catch (_: Exception) {
                    break
                }
            }
        }

        return articles
    }

    /**
     * Reads text content of the current START_TAG up to its matching END_TAG without throwing
     * if nested child elements exist inside the tag.
     */
    private fun readTagTextSafely(parser: XmlPullParser): String {
        val sb = StringBuilder()
        var depth = 1
        while (depth > 0) {
            val next = parser.next()
            when (next) {
                XmlPullParser.TEXT, XmlPullParser.CDSECT -> {
                    sb.append(parser.text ?: "")
                }
                XmlPullParser.START_TAG -> {
                    depth++
                }
                XmlPullParser.END_TAG -> {
                    depth--
                }
                XmlPullParser.END_DOCUMENT -> {
                    break
                }
            }
        }
        return sb.toString()
    }

    private fun cleanHtml(html: String): String {
        return html
            .replace(Regex("<[^>]*>"), " ")
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace("&#039;", "'")
            .replace("&#8217;", "'")
            .replace("&#8216;", "'")
            .replace("&#8220;", "\"")
            .replace("&#8221;", "\"")
            .replace("&#8211;", "–")
            .replace("&#8212;", "—")
            .replace("&nbsp;", " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun parsePubDate(dateStr: String, fallbackNow: Long = System.currentTimeMillis()): Long {
        if (dateStr.isBlank()) return fallbackNow - 1800_000L

        val patterns = listOf(
            "EEE, dd MMM yyyy HH:mm:ss z",
            "EEE, dd MMM yyyy HH:mm:ss Z",
            "EEE, d MMM yyyy HH:mm:ss z",
            "EEE, d MMM yyyy HH:mm:ss Z",
            "EEE, dd MMM yyyy HH:mm z",
            "EEE, dd MMM yyyy HH:mm Z",
            "dd MMM yyyy HH:mm:ss z",
            "dd MMM yyyy HH:mm:ss Z",
            "yyyy-MM-dd'T'HH:mm:ss'Z'",
            "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
            "yyyy-MM-dd'T'HH:mm:ssXXX",
            "yyyy-MM-dd'T'HH:mm:ss.SSSXXX",
            "yyyy-MM-dd HH:mm:ss"
        )

        val cleanedDate = dateStr.trim()
        for (pattern in patterns) {
            try {
                val sdf = SimpleDateFormat(pattern, Locale.ENGLISH)
                sdf.timeZone = TimeZone.getTimeZone("UTC")
                val parsed = sdf.parse(cleanedDate)
                if (parsed != null) return parsed.time
            } catch (_: Exception) {}
        }

        return fallbackNow - 1800_000L
    }

    private fun calculateFreshness(pubMillis: Long, referenceMillis: Long): Pair<String, String> {
        val diff = maxOf(0L, referenceMillis - pubMillis)
        val date = Date(pubMillis)
        val formatter = SimpleDateFormat("MMM d, h:mm a", Locale.ENGLISH).apply {
            timeZone = TimeZone.getTimeZone("Asia/Kathmandu")
        }
        val formatted = formatter.format(date)

        val label = when {
            diff < 90 * 60_000L -> "Just published"
            diff < 6 * 3600_000L -> "Recently published"
            diff < 24 * 3600_000L -> "Today"
            diff < 48 * 3600_000L -> "Yesterday"
            else -> "Verified Report"
        }
        return Pair(formatted, label)
    }

    private fun mapToAppCategory(raw: String, fallback: String): String {
        val lower = raw.lowercase(Locale.ENGLISH)
        return when {
            lower.contains("nepal") || lower.contains("kathmandu") -> "Nepal News"
            lower.contains("tech") || lower.contains("ai") || lower.contains("software") -> "Technology and AI"
            lower.contains("crypto") || lower.contains("bitcoin") || lower.contains("blockchain") -> "Cryptocurrency"
            lower.contains("gold") || lower.contains("silver") || lower.contains("metal") || lower.contains("bullion") -> "Gold and Precious Metals"
            lower.contains("politic") || lower.contains("government") || lower.contains("parliament") -> "Politics"
            lower.contains("business") || lower.contains("econom") || lower.contains("market") || lower.contains("finance") -> "Business and Economy"
            lower.contains("sport") || lower.contains("cricket") || lower.contains("football") -> "Sports"
            lower.contains("weather") || lower.contains("climate") || lower.contains("flood") -> "Weather and Climate"
            lower.contains("health") || lower.contains("medical") -> "Health and Science"
            lower.contains("science") -> "Science"
            lower.contains("entertain") || lower.contains("movie") || lower.contains("music") -> "Entertainment"
            else -> fallback
        }
    }

    private fun inferCategoryFromContent(title: String, desc: String, defaultCat: String): String {
        val combined = "$title $desc".lowercase(Locale.ENGLISH)
        return when {
            combined.contains("gold") || combined.contains("bullion") || combined.contains("silver price") || combined.contains("tola") -> "Gold and Precious Metals"
            combined.contains("bitcoin") || combined.contains("crypto") || combined.contains("ethereum") -> "Cryptocurrency"
            combined.contains("artificial intelligence") || combined.contains("ai ") || combined.contains("semiconductor") || combined.contains("google") || combined.contains("apple") || combined.contains("microsoft") -> "Technology and AI"
            combined.contains("election") || combined.contains("minister") || combined.contains("parliament") || combined.contains("president") || combined.contains("cabinet") -> "Politics"
            combined.contains("stock") || combined.contains("inflation") || combined.contains("gdp") || combined.contains("economy") || combined.contains("bank") || combined.contains("nepse") -> "Business and Economy"
            combined.contains("weather") || combined.contains("rainfall") || combined.contains("temperature") || combined.contains("monsoon") || combined.contains("cyclone") -> "Weather and Climate"
            combined.contains("cricket") || combined.contains("football") || combined.contains("tournament") || combined.contains("league") -> "Sports"
            else -> defaultCat
        }
    }

    private fun generateEditorialSummary(title: String, desc: String): String {
        val clean = if (desc.length > 30) desc else title
        val sentences = clean.split(". ")
        val firstTwo = sentences.take(2).joinToString(". ").trim()
        return if (firstTwo.endsWith(".")) firstTwo else "$firstTwo."
    }
}
