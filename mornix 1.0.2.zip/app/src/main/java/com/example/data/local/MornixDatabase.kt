package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [BriefingEntity::class],
    version = 1,
    exportSchema = false
)
abstract class MornixDatabase : RoomDatabase() {

    abstract fun briefingDao(): BriefingDao

    companion object {
        @Volatile
        private var INSTANCE: MornixDatabase? = null

        fun getInstance(context: Context): MornixDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    MornixDatabase::class.java,
                    "mornix_offline_cache.db"
                )
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
