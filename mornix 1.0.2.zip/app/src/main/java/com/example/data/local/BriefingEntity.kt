package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.BibleVerse
import com.example.data.model.MorningBriefing

private const val HIGHLIGHT_DELIMITER = "\n||MORNIX_HL||\n"

@Entity(tableName = "daily_briefings")
data class BriefingEntity(
    @PrimaryKey
    val dateKey: String,
    val generatedAtMillis: Long,
    val formattedDate: String,
    val greeting: String,
    val executiveSummary: String,
    val newsHighlightsJson: String,
    val goldForexSnippet: String,
    val weatherSnippet: String,
    val alertsSnippet: String,
    val spokenScript: String,
    val isAiGenerated: Boolean,
    val bibleVerseRef: String? = null,
    val bibleVerseText: String? = null,
    val bibleVerseTranslation: String? = null,
    val bibleVerseTheme: String? = null,
    val bibleVerseDate: String? = null
) {
    fun toDomainModel(isOfflineCached: Boolean = false): MorningBriefing {
        val highlights = if (newsHighlightsJson.isBlank()) {
            emptyList()
        } else {
            newsHighlightsJson
                .split(HIGHLIGHT_DELIMITER)
                .map { it.trim() }
                .filter { it.isNotEmpty() }
        }

        val verse = if (!bibleVerseRef.isNullOrBlank() && !bibleVerseText.isNullOrBlank()) {
            BibleVerse(
                reference = bibleVerseRef,
                text = bibleVerseText,
                translation = bibleVerseTranslation ?: "NIV",
                theme = bibleVerseTheme ?: "Wisdom & Peace",
                dateFormatted = bibleVerseDate ?: formattedDate
            )
        } else {
            null
        }

        return MorningBriefing(
            generatedAtMillis = generatedAtMillis,
            formattedDate = formattedDate,
            greeting = greeting,
            executiveSummary = executiveSummary,
            newsHighlights = highlights,
            goldForexSnippet = goldForexSnippet,
            weatherSnippet = weatherSnippet,
            alertsSnippet = alertsSnippet,
            spokenScript = spokenScript,
            isAiGenerated = isAiGenerated,
            bibleVerse = verse,
            isOfflineCached = isOfflineCached
        )
    }
}

fun MorningBriefing.toEntity(): BriefingEntity {
    val serializedHighlights = newsHighlights
        .map { it.trim() }
        .filter { it.isNotEmpty() }
        .joinToString(HIGHLIGHT_DELIMITER)

    val key = formattedDate.ifBlank { "latest_briefing" }

    return BriefingEntity(
        dateKey = key,
        generatedAtMillis = generatedAtMillis,
        formattedDate = formattedDate,
        greeting = greeting,
        executiveSummary = executiveSummary,
        newsHighlightsJson = serializedHighlights,
        goldForexSnippet = goldForexSnippet,
        weatherSnippet = weatherSnippet,
        alertsSnippet = alertsSnippet,
        spokenScript = spokenScript,
        isAiGenerated = isAiGenerated,
        bibleVerseRef = bibleVerse?.reference,
        bibleVerseText = bibleVerse?.text,
        bibleVerseTranslation = bibleVerse?.translation,
        bibleVerseTheme = bibleVerse?.theme,
        bibleVerseDate = bibleVerse?.dateFormatted
    )
}
