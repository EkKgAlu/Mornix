package com.example.data.repository

import android.content.Context
import com.example.data.model.DisasterAlert
import com.example.data.model.ForexRateItem
import com.example.data.model.FreshnessStatus
import com.example.data.model.GoldSilverRates
import com.example.data.model.GoldWeightUnit
import com.example.data.model.MarketQuote
import com.example.data.model.MorningBriefing
import com.example.data.model.NewsArticle
import com.example.data.model.TemperatureUnit
import com.example.data.model.UserPreferences
import com.example.data.model.WeatherInfo
import com.example.data.remote.AlertsService
import com.example.data.remote.LocationHelper
import com.example.data.remote.MarketsService
import com.example.data.remote.NepalBullionService
import com.example.data.remote.NepalForexService
import com.example.data.calendar.SavedBirthDate
import com.example.data.remote.NewsRssService
import com.example.data.remote.WeatherService
import com.example.data.service.BibleVerseService
import com.example.data.service.BriefingSynthesizer
import com.example.data.service.ChatMessage
import com.example.data.service.MornixChatService
import com.example.data.local.BriefingDao
import com.example.data.local.MornixDatabase
import com.example.data.local.toEntity
import com.example.service.MornixNotificationHelper
import com.example.service.MornixSyncWorker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

data class BackgroundSyncSummary(
    val syncedAtMillis: Long,
    val syncReason: String,
    val newsSuccess: Boolean,
    val weatherSuccess: Boolean,
    val forexSuccess: Boolean,
    val bullionSuccess: Boolean,
    val marketsSuccess: Boolean,
    val newsCount: Int,
    val forexCount: Int
) {
    val hasAnySuccess: Boolean
        get() = newsSuccess || weatherSuccess || forexSuccess || bullionSuccess || marketsSuccess
}

class MornixRepository(
    private val context: Context,
    private val bullionService: NepalBullionService = NepalBullionService(),
    private val forexService: NepalForexService = NepalForexService(),
    private val weatherService: WeatherService = WeatherService(),
    private val newsService: NewsRssService = NewsRssService(),
    private val marketsService: MarketsService = MarketsService(),
    private val alertsService: AlertsService = AlertsService(),
    private val synthesizer: BriefingSynthesizer = BriefingSynthesizer(),
    private val chatService: MornixChatService = MornixChatService(),
    private val bibleVerseService: BibleVerseService = BibleVerseService(),
    private val briefingDao: BriefingDao = MornixDatabase.getInstance(context).briefingDao()
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val prefs = context.getSharedPreferences("mornix_secure_prefs", Context.MODE_PRIVATE)

    private val _bullionRates = MutableStateFlow<GoldSilverRates?>(null)
    val bullionRates: StateFlow<GoldSilverRates?> = _bullionRates.asStateFlow()

    private val _forexRates = MutableStateFlow<List<ForexRateItem>>(emptyList())
    val forexRates: StateFlow<List<ForexRateItem>> = _forexRates.asStateFlow()

    private val _weather = MutableStateFlow<WeatherInfo?>(null)
    val weather: StateFlow<WeatherInfo?> = _weather.asStateFlow()

    private val _news = MutableStateFlow<List<NewsArticle>>(emptyList())
    val news: StateFlow<List<NewsArticle>> = _news.asStateFlow()

    private val _markets = MutableStateFlow<List<MarketQuote>>(marketsService.getDefaultMarkets())
    val markets: StateFlow<List<MarketQuote>> = _markets.asStateFlow()

    private val _alerts = MutableStateFlow<List<DisasterAlert>>(emptyList())
    val alerts: StateFlow<List<DisasterAlert>> = _alerts.asStateFlow()

    private val _briefing = MutableStateFlow<MorningBriefing?>(null)
    val briefing: StateFlow<MorningBriefing?> = _briefing.asStateFlow()

    val cachedBriefingsHistory: Flow<List<MorningBriefing>> = briefingDao.getAllBriefingsFlow()
        .map { entities -> entities.map { it.toDomainModel(isOfflineCached = true) } }

    private val _userPreferences = MutableStateFlow(loadPreferences())
    val userPreferences: StateFlow<UserPreferences> = _userPreferences.asStateFlow()

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(chatService.history)
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isChatLoading = MutableStateFlow(false)
    val isChatLoading: StateFlow<Boolean> = _isChatLoading.asStateFlow()

    private val _savedBirthDate = MutableStateFlow<SavedBirthDate?>(null)
    val savedBirthDate: StateFlow<SavedBirthDate?> = _savedBirthDate.asStateFlow()

    private val _lastSyncTimestampMillis = MutableStateFlow(prefs.getLong("last_background_sync_millis", 0L))
    val lastSyncTimestampMillis: StateFlow<Long> = _lastSyncTimestampMillis.asStateFlow()

    private val bookmarkedIds = mutableSetOf<String>()

    init {
        loadBookmarkedIds()
        loadCachedData()
        observeRoomBriefingCache()
        loadSavedBirthDate()
        MornixNotificationHelper.createNotificationChannels(context)
        if (_userPreferences.value.morningBriefingNotificationEnabled) {
            MornixNotificationHelper.scheduleDailyBriefingAlarm(
                context,
                _userPreferences.value.morningBriefingHour,
                _userPreferences.value.morningBriefingMinute
            )
        }
        syncLiveStatusNotification()
        syncCalendarEventReminders()
        schedulePeriodicBackgroundSync(replaceExisting = false)
        refreshAllData()
    }

    fun schedulePeriodicBackgroundSync(replaceExisting: Boolean = false) {
        val intervalMinutes = _userPreferences.value.autoRefreshMinutes
            .toLong()
            .coerceAtLeast(MornixSyncWorker.MIN_WORK_INTERVAL_MINUTES)
        MornixSyncWorker.schedulePeriodicSync(
            context = context,
            intervalMinutes = intervalMinutes,
            replaceExisting = replaceExisting
        )
    }

    fun syncLiveStatusNotification() {
        val p = _userPreferences.value
        MornixNotificationHelper.updateOrCancelLiveStatusNotification(
            context = context,
            nepaliDateEnabled = p.nepaliDateNotificationEnabled,
            weatherEnabled = p.weatherNotificationEnabled,
            weather = _weather.value,
            tempUnit = p.temperatureUnit,
            fallbackCity = p.preferredCity
        )
    }

    fun syncCalendarEventReminders() {
        val p = _userPreferences.value
        MornixNotificationHelper.syncCalendarEventReminders(
            context = context,
            enabled = p.calendarEventReminderEnabled
        )
    }

    private fun observeRoomBriefingCache() {
        scope.launch {
            try {
                // Immediately restore latest offline report from Room DB before network completes
                val latestCached = briefingDao.getLatestBriefing()
                if (latestCached != null && _briefing.value == null) {
                    _briefing.value = latestCached.toDomainModel(isOfflineCached = true)
                }
                briefingDao.getLatestBriefingFlow().collect { entity ->
                    if (entity != null && _briefing.value == null) {
                        _briefing.value = entity.toDomainModel(isOfflineCached = true)
                    }
                }
            } catch (_: Exception) {}
        }
    }

    fun refreshNews() {
        scope.launch {
            _isRefreshing.value = true
            try {
                val newsArticles = newsService.fetchAllFeeds()
                if (newsArticles.isNotEmpty()) {
                    val withBookmarks = newsArticles.map { it.copy(isBookmarked = bookmarkedIds.contains(it.id)) }
                    _news.value = withBookmarks
                    saveCachedNews(withBookmarks)
                }
            } catch (_: Exception) {
            } finally {
                _isRefreshing.value = false
            }
        }
    }

    fun refreshAllData() {
        scope.launch {
            performBackgroundSync(syncReason = "manual_or_foreground_refresh")
        }
    }

    /**
     * Executes a full concurrent network synchronization for news, weather, exchange rates (NRB forex),
     * bullion rates, international markets, and disaster alerts.
     * Used both by the WorkManager periodic background worker ([MornixSyncWorker]) and foreground refreshes.
     */
    suspend fun performBackgroundSync(
        syncReason: String = MornixSyncWorker.REASON_PERIODIC
    ): BackgroundSyncSummary {
        _isRefreshing.value = true
        var newsSuccess = false
        var weatherSuccess = false
        var forexSuccess = false
        var bullionSuccess = false
        var marketsSuccess = false
        var fetchedNewsCount = 0
        var fetchedForexCount = 0

        try {
            coroutineScope {
                // 1. Fetch News concurrently so News tab updates immediately without waiting on other endpoints
                val newsDeferred = async {
                    try {
                        val newsArticles = newsService.fetchAllFeeds()
                        if (newsArticles.isNotEmpty()) {
                            val withBookmarks = newsArticles.map { it.copy(isBookmarked = bookmarkedIds.contains(it.id)) }
                            _news.value = withBookmarks
                            saveCachedNews(withBookmarks)
                            newsSuccess = true
                            fetchedNewsCount = withBookmarks.size
                        }
                        newsArticles
                    } catch (_: Exception) {
                        emptyList()
                    }
                }

                // 2. Fetch Bullion Rates concurrently
                val bullionDeferred = async {
                    val bullionResult = try {
                        bullionService.fetchOfficialBullionRates()
                    } catch (e: Exception) {
                        Result.failure(e)
                    }
                    if (bullionResult.isSuccess) {
                        val rates = bullionResult.getOrNull()
                        _bullionRates.value = rates
                        rates?.let {
                            saveCachedBullion(it)
                            bullionSuccess = true
                        }
                    } else if (_bullionRates.value != null) {
                        _bullionRates.value = _bullionRates.value?.copy(freshnessStatus = FreshnessStatus.STALE)
                    }
                    bullionResult
                }

                // 3. Fetch Forex Exchange Rates concurrently
                val forexDeferred = async {
                    val forexResult = try {
                        forexService.fetchOfficialForexRates()
                    } catch (e: Exception) {
                        Result.failure(e)
                    }
                    if (forexResult.isSuccess) {
                        val rawList = forexResult.getOrNull() ?: emptyList()
                        val favCurrencies = _userPreferences.value.favoriteCurrencies
                        val mapped = rawList.map { it.copy(isFavorite = favCurrencies.contains(it.currencyCode)) }
                            .sortedByDescending { it.isFavorite }
                        _forexRates.value = mapped
                        saveCachedForex(mapped)
                        forexSuccess = mapped.isNotEmpty()
                        fetchedForexCount = mapped.size
                    } else if (_forexRates.value.isNotEmpty()) {
                        _forexRates.value = _forexRates.value.map { it.copy(freshnessStatus = FreshnessStatus.STALE) }
                    }
                    forexResult
                }

                // 4. Fetch Weather concurrently
                val weatherDeferred = async {
                    val city = _userPreferences.value.preferredCity
                    val weatherResult = try {
                        if (city.equals("Current Location", ignoreCase = true)) {
                            val loc = LocationHelper.getDeviceLocation(context)
                            val displayCity = if (loc.cityName.isNotBlank() && loc.cityName != "Current Location") loc.cityName else "Current Location"
                            weatherService.fetchWeather(displayCity, loc.latitude, loc.longitude)
                        } else {
                            val coords = weatherService.popularCities.find { it.name.equals(city, ignoreCase = true) }
                                ?: weatherService.popularCities.first()
                            weatherService.fetchWeather(coords.name, coords.lat, coords.lon)
                        }
                    } catch (e: Exception) {
                        Result.failure(e)
                    }

                    if (weatherResult.isSuccess) {
                        val w = weatherResult.getOrNull()
                        _weather.value = w
                        w?.let {
                            saveCachedWeather(it)
                            weatherSuccess = true
                        }
                    } else if (_weather.value != null) {
                        _weather.value = _weather.value?.copy(freshnessStatus = FreshnessStatus.STALE)
                    }
                    syncLiveStatusNotification()
                    weatherResult
                }

                // 5. Fetch International Markets concurrently
                val marketsDeferred = async {
                    try {
                        val quotes = marketsService.fetchAllMarkets()
                        if (quotes.isNotEmpty()) {
                            val favMarkets = _userPreferences.value.favoriteMarkets
                            val mapped = quotes.map { it.copy(isFavorite = favMarkets.contains(it.symbol)) }
                                .sortedByDescending { it.isFavorite }
                            _markets.value = mapped
                            marketsSuccess = true
                        }
                        quotes
                    } catch (_: Exception) {
                        emptyList()
                    }
                }

                // 6. Fetch Disaster, Seismic, Weather & Cultural Festival Alerts concurrently
                val alertsDeferred = async {
                    val alertList = try {
                        alertsService.fetchVerifiedAlerts().toMutableList()
                    } catch (_: Exception) {
                        mutableListOf()
                    }

                    try {
                        val todayBs = com.example.data.calendar.NepaliDateConverter.todayBs()
                        val todayEvents = com.example.data.calendar.NepaliFestivalData.getTodaySpecialOccasions(todayBs)
                        val nextMajor = com.example.data.calendar.NepaliFestivalData.getNextMajorFestival(todayBs)

                        for (ev in todayEvents) {
                            val isHoliday = ev.isPublicHoliday
                            alertList.add(
                                0,
                                DisasterAlert(
                                    id = "fest_today_${ev.id}",
                                    title = if (isHoliday) "🏛️ Official Public Holiday Today: ${ev.nameNe} (${ev.nameEn})" else "✨ Today's Festival: ${ev.nameNe} (${ev.nameEn})",
                                    description = "${ev.description} • ${ev.significance} [Source: ${ev.source}]",
                                    affectedLocation = if (ev.holidayScope == com.example.data.calendar.HolidayScope.KATHMANDU_VALLEY) "Kathmandu Valley" else "Nationwide (Nepal)",
                                    severity = if (isHoliday) "CRITICAL" else "WARNING",
                                    issuingAuthority = ev.source,
                                    pubDateFormatted = todayBs.formattedEn,
                                    sourceUrl = "https://moha.gov.np",
                                    timestampMillis = System.currentTimeMillis()
                                )
                            )
                        }

                        if (nextMajor != null && nextMajor.second in 1L..3L) {
                            val ev = nextMajor.first
                            alertList.add(
                                if (todayEvents.isEmpty()) 0 else 1,
                                DisasterAlert(
                                    id = "fest_upcoming_${ev.id}",
                                    title = if (ev.isPublicHoliday) "📢 Upcoming Public Holiday in ${nextMajor.second} day(s): ${ev.nameNe} (${ev.nameEn})" else "🎉 Upcoming Festival in ${nextMajor.second} day(s): ${ev.nameNe}",
                                    description = "${ev.nameEn} will be observed on ${ev.bsDate.formattedEn}. ${if (ev.isPublicHoliday) "Government offices and public institutions will remain closed." else ""}",
                                    affectedLocation = if (ev.holidayScope == com.example.data.calendar.HolidayScope.KATHMANDU_VALLEY) "Kathmandu Valley" else "Nationwide (Nepal)",
                                    severity = if (ev.isPublicHoliday) "WARNING" else "ADVISORY",
                                    issuingAuthority = ev.source,
                                    pubDateFormatted = todayBs.formattedEn,
                                    sourceUrl = "https://moha.gov.np",
                                    timestampMillis = System.currentTimeMillis() - 500
                                )
                            )
                        }
                    } catch (_: Exception) {}

                    _alerts.value = alertList

                    if (_userPreferences.value.disasterAlertsNotificationEnabled && alertList.isNotEmpty()) {
                        val topAlert = alertList.firstOrNull { it.severity == "CRITICAL" || it.severity == "WARNING" }
                        topAlert?.let {
                            val lastNotifiedId = prefs.getString("last_notified_alert_id", "")
                            if (lastNotifiedId != it.id) {
                                MornixNotificationHelper.showDisasterNotification(context, it)
                                prefs.edit().putString("last_notified_alert_id", it.id).apply()
                            }
                        }
                    }
                    alertList
                }

                val newsArticles = newsDeferred.await()
                val bullionResult = bullionDeferred.await()
                val forexResult = forexDeferred.await()
                val weatherResult = weatherDeferred.await()
                marketsDeferred.await()
                alertsDeferred.await()

                // Keep Calendar Event Reminders in sync with latest date
                syncCalendarEventReminders()

                // 7. Synthesize Morning Briefing and Cache in Room DB for Offline Viewing & Morning Notification
                val hasLiveNetworkData = bullionResult.isSuccess || forexResult.isSuccess || weatherResult.isSuccess || newsArticles.isNotEmpty()
                val cachedRoomEntity = try { briefingDao.getLatestBriefing() } catch (_: Exception) { null }

                if (!hasLiveNetworkData && cachedRoomEntity != null) {
                    _briefing.value = cachedRoomEntity.toDomainModel(isOfflineCached = true)
                } else {
                    val newBriefing = synthesizer.generateBriefing(
                        goldSilver = _bullionRates.value,
                        forexList = _forexRates.value,
                        weather = _weather.value,
                        articles = _news.value,
                        alerts = _alerts.value,
                        prefs = _userPreferences.value
                    ).copy(isOfflineCached = !hasLiveNetworkData)
                    _briefing.value = newBriefing
                    saveCachedBriefing(newBriefing)
                }
            }
        } catch (_: Exception) {
            val cachedRoomEntity = try { briefingDao.getLatestBriefing() } catch (_: Exception) { null }
            if (cachedRoomEntity != null && _briefing.value == null) {
                _briefing.value = cachedRoomEntity.toDomainModel(isOfflineCached = true)
            }
        } finally {
            _isRefreshing.value = false
        }

        val now = System.currentTimeMillis()
        if (newsSuccess || weatherSuccess || forexSuccess || bullionSuccess || marketsSuccess) {
            _lastSyncTimestampMillis.value = now
            prefs.edit()
                .putLong("last_background_sync_millis", now)
                .putString("last_background_sync_reason", syncReason)
                .apply()
        }

        return BackgroundSyncSummary(
            syncedAtMillis = now,
            syncReason = syncReason,
            newsSuccess = newsSuccess,
            weatherSuccess = weatherSuccess,
            forexSuccess = forexSuccess,
            bullionSuccess = bullionSuccess,
            marketsSuccess = marketsSuccess,
            newsCount = fetchedNewsCount,
            forexCount = fetchedForexCount
        )
    }

    fun refreshDeviceLocation() {
        scope.launch {
            val loc = LocationHelper.getDeviceLocation(context)
            val displayCity = if (loc.cityName.isNotBlank() && loc.cityName != "Current Location") loc.cityName else "Current Location"
            val weatherResult = weatherService.fetchWeather(displayCity, loc.latitude, loc.longitude)
            if (weatherResult.isSuccess) {
                val w = weatherResult.getOrNull()
                _weather.value = w
                w?.let { saveCachedWeather(it) }
                syncLiveStatusNotification()
            }
        }
    }

    fun toggleFavoriteCurrency(currencyCode: String) {
        val current = _userPreferences.value
        val list = current.favoriteCurrencies.toMutableList()
        if (list.contains(currencyCode)) {
            list.remove(currencyCode)
        } else {
            list.add(0, currencyCode) // Pin to start
        }
        val updated = current.copy(favoriteCurrencies = list)
        updatePreferences(updated)

        // Re-sort current forex list
        _forexRates.value = _forexRates.value.map {
            it.copy(isFavorite = list.contains(it.currencyCode))
        }.sortedByDescending { it.isFavorite }
    }

    fun toggleFavoriteMarket(symbol: String) {
        val current = _userPreferences.value
        val list = current.favoriteMarkets.toMutableList()
        if (list.contains(symbol)) {
            list.remove(symbol)
        } else {
            list.add(0, symbol) // Pin to start
        }
        val updated = current.copy(favoriteMarkets = list)
        updatePreferences(updated)

        // Re-sort current markets list
        _markets.value = _markets.value.map {
            it.copy(isFavorite = list.contains(it.symbol))
        }.sortedByDescending { it.isFavorite }
    }

    fun toggleDailyBibleVerse(enabled: Boolean) {
        val updated = _userPreferences.value.copy(dailyBibleVerseEnabled = enabled)
        updatePreferences(updated)
    }

    fun toggleShowUpcomingEventsInBriefing(enabled: Boolean) {
        val updated = _userPreferences.value.copy(showUpcomingEventsInBriefing = enabled)
        _userPreferences.value = updated
        savePreferences(updated)
    }

    fun toggleNepaliDateNotification(enabled: Boolean) {
        val updated = _userPreferences.value.copy(nepaliDateNotificationEnabled = enabled)
        _userPreferences.value = updated
        savePreferences(updated)
        syncLiveStatusNotification()
    }

    fun toggleWeatherNotification(enabled: Boolean) {
        val updated = _userPreferences.value.copy(weatherNotificationEnabled = enabled)
        _userPreferences.value = updated
        savePreferences(updated)
        syncLiveStatusNotification()
    }

    fun toggleCalendarEventReminder(enabled: Boolean) {
        val updated = _userPreferences.value.copy(calendarEventReminderEnabled = enabled)
        _userPreferences.value = updated
        savePreferences(updated)
        syncCalendarEventReminders()
    }

    fun completeOnboardingSetup(
        liveStatusEnabled: Boolean,
        bibleVerseEnabled: Boolean,
        selectedCategories: List<String>,
        calendarEventReminderEnabled: Boolean = _userPreferences.value.calendarEventReminderEnabled
    ) {
        val cleanCategories = if (selectedCategories.isNotEmpty()) {
            selectedCategories.distinct()
        } else {
            _userPreferences.value.selectedNewsCategories
        }
        val updated = _userPreferences.value.copy(
            nepaliDateNotificationEnabled = liveStatusEnabled,
            weatherNotificationEnabled = liveStatusEnabled,
            dailyBibleVerseEnabled = bibleVerseEnabled,
            calendarEventReminderEnabled = calendarEventReminderEnabled,
            selectedNewsCategories = cleanCategories,
            hasCompletedOnboarding = true
        )
        updatePreferences(updated)
    }

    fun skipOnboardingSetup() {
        val updated = _userPreferences.value.copy(hasCompletedOnboarding = true)
        _userPreferences.value = updated
        savePreferences(updated)
        syncLiveStatusNotification()
        syncCalendarEventReminders()
    }

    fun reopenOnboardingSetup() {
        val updated = _userPreferences.value.copy(hasCompletedOnboarding = false)
        _userPreferences.value = updated
        savePreferences(updated)
    }

    fun getTodayBibleVerse() = bibleVerseService.getDailyVerse()

    fun loadSavedBirthDate() {
        val type = prefs.getString("pref_dob_calendar_type", null)
        val y = prefs.getInt("pref_dob_year", 0)
        val m = prefs.getInt("pref_dob_month", 0)
        val d = prefs.getInt("pref_dob_day", 0)
        if (type != null && y > 0 && m > 0 && d > 0) {
            _savedBirthDate.value = SavedBirthDate(type, y, m, d)
        } else {
            _savedBirthDate.value = null
        }
    }

    fun saveBirthDate(calendarType: String, year: Int, month: Int, day: Int) {
        prefs.edit()
            .putString("pref_dob_calendar_type", calendarType)
            .putInt("pref_dob_year", year)
            .putInt("pref_dob_month", month)
            .putInt("pref_dob_day", day)
            .apply()
        _savedBirthDate.value = SavedBirthDate(calendarType, year, month, day)
        syncCalendarEventReminders()
    }

    fun clearBirthDate() {
        prefs.edit()
            .remove("pref_dob_calendar_type")
            .remove("pref_dob_year")
            .remove("pref_dob_month")
            .remove("pref_dob_day")
            .apply()
        _savedBirthDate.value = null
        syncCalendarEventReminders()
    }

    fun sendTestMorningBriefingNotification() {
        val currentBriefing = _briefing.value ?: run {
            MorningBriefing(
                generatedAtMillis = System.currentTimeMillis(),
                formattedDate = "Today",
                greeting = "Good Morning",
                executiveSummary = "Test notification: Mornix daily briefing is active with live bullion, forex, and news.",
                newsHighlights = emptyList(),
                goldForexSnippet = "Gold: 24K Live • USD/NPR verified.",
                weatherSnippet = "Current temperature available.",
                alertsSnippet = "No active hazards.",
                spokenScript = "Good morning! This is Mornix with your morning briefing. Tapping listen directly in this notification plays your spoken daily audio brief.",
                isAiGenerated = true
            )
        }
        MornixNotificationHelper.showMorningBriefingNotification(context, currentBriefing)
    }

    fun sendTestDisasterAlertNotification() {
        val alert = _alerts.value.firstOrNull() ?: DisasterAlert(
            id = "test_disaster_001",
            title = "Earthquake M4.8 - Central Region, Nepal",
            description = "Seismic tremor recorded. Monitored by National Seismological Centre / USGS. Exercise safety precautions.",
            affectedLocation = "Central Nepal / Himalayan Belt",
            severity = "WARNING",
            issuingAuthority = "National Seismological Centre / USGS",
            pubDateFormatted = "Just now",
            sourceUrl = "https://earthquake.usgs.gov",
            timestampMillis = System.currentTimeMillis()
        )
        MornixNotificationHelper.showDisasterNotification(context, alert)
    }

    fun sendChatMessage(text: String) {
        if (text.isBlank()) return
        scope.launch {
            _isChatLoading.value = true
            _chatMessages.value = chatService.history + ChatMessage(
                sender = com.example.data.service.MessageSender.USER,
                text = text
            )
            chatService.sendMessage(
                userMessage = text,
                currentWeather = _weather.value,
                currentBullion = _bullionRates.value,
                currentForex = _forexRates.value,
                currentNews = _news.value
            )
            _chatMessages.value = chatService.history
            _isChatLoading.value = false
        }
    }

    fun clearChat() {
        chatService.clearHistory()
        _chatMessages.value = chatService.history
    }

    fun toggleBookmark(articleId: String) {
        if (bookmarkedIds.contains(articleId)) {
            bookmarkedIds.remove(articleId)
        } else {
            bookmarkedIds.add(articleId)
        }
        saveBookmarkedIds()
        _news.value = _news.value.map {
            if (it.id == articleId) it.copy(isBookmarked = bookmarkedIds.contains(articleId)) else it
        }
    }

    fun updatePreferences(newPrefs: UserPreferences) {
        val oldPrefs = _userPreferences.value
        _userPreferences.value = newPrefs
        savePreferences(newPrefs)

        // Immediately sync Live Status Notification when switches, city, or temperature unit change
        syncLiveStatusNotification()
        if (oldPrefs.calendarEventReminderEnabled != newPrefs.calendarEventReminderEnabled) {
            syncCalendarEventReminders()
        }
        if (oldPrefs.autoRefreshMinutes != newPrefs.autoRefreshMinutes) {
            schedulePeriodicBackgroundSync(replaceExisting = true)
        }

        // Reschedule alarm if notification time or enabled status changed
        if (oldPrefs.morningBriefingNotificationEnabled != newPrefs.morningBriefingNotificationEnabled ||
            oldPrefs.morningBriefingHour != newPrefs.morningBriefingHour ||
            oldPrefs.morningBriefingMinute != newPrefs.morningBriefingMinute
        ) {
            if (newPrefs.morningBriefingNotificationEnabled) {
                MornixNotificationHelper.scheduleDailyBriefingAlarm(
                    context,
                    newPrefs.morningBriefingHour,
                    newPrefs.morningBriefingMinute
                )
            } else {
                MornixNotificationHelper.cancelDailyBriefingAlarm(context)
            }
        }

        // If city changed, refresh weather
        scope.launch {
            val weatherResult = if (newPrefs.preferredCity.equals("Current Location", ignoreCase = true)) {
                val loc = LocationHelper.getDeviceLocation(context)
                val displayCity = if (loc.cityName.isNotBlank() && loc.cityName != "Current Location") loc.cityName else "Current Location"
                weatherService.fetchWeather(displayCity, loc.latitude, loc.longitude)
            } else {
                val coords = weatherService.popularCities.find { it.name.equals(newPrefs.preferredCity, ignoreCase = true) }
                    ?: weatherService.popularCities.first()
                weatherService.fetchWeather(coords.name, coords.lat, coords.lon)
            }

            if (weatherResult.isSuccess) {
                val w = weatherResult.getOrNull()
                _weather.value = w
                w?.let { saveCachedWeather(it) }
                syncLiveStatusNotification()
            }
            // Re-generate briefing with updated preferences
            val newBriefing = synthesizer.generateBriefing(
                goldSilver = _bullionRates.value,
                forexList = _forexRates.value,
                weather = _weather.value,
                articles = _news.value,
                alerts = _alerts.value,
                prefs = newPrefs
            )
            _briefing.value = newBriefing
            saveCachedBriefing(newBriefing)
        }
    }

    private fun loadPreferences(): UserPreferences {
        val city = prefs.getString("pref_city", "Current Location") ?: "Current Location"
        val country = prefs.getString("pref_country", "Nepal") ?: "Nepal"
        val tempUnit = if (prefs.getString("pref_temp", "C") == "F") TemperatureUnit.FAHRENHEIT else TemperatureUnit.CELSIUS
        val goldUnitStr = prefs.getString("pref_gold_unit", "TOLA")
        val goldUnit = try { GoldWeightUnit.valueOf(goldUnitStr ?: "TOLA") } catch (_: Exception) { GoldWeightUnit.TOLA }
        val speed = prefs.getFloat("pref_tts_speed", 1.0f)

        val favCurrenciesSet = prefs.getStringSet("pref_fav_currencies", null)
        val favCurrencies = favCurrenciesSet?.toList() ?: listOf("USD", "INR", "EUR", "AED", "GBP", "AUD")

        val favMarketsSet = prefs.getStringSet("pref_fav_markets", null)
        val favMarkets = favMarketsSet?.toList() ?: listOf("BTC", "ETH", "SOL", "BNB", "GC=F", "SI=F", "CL=F", "^GSPC", "^NDX")

        val defaultNewsCategories = listOf(
            "Nepal News", "World News", "Politics", "Business and Economy",
            "Technology and AI", "Gold and Precious Metals", "Weather and Climate"
        )
        val newsCatsStr = prefs.getString("pref_news_categories", null)
        val selectedNewsCategories = if (!newsCatsStr.isNullOrBlank()) {
            newsCatsStr.split("|").map { it.trim() }.filter { it.isNotEmpty() }
        } else {
            defaultNewsCategories
        }

        val defaultEnabled = listOf("briefing", "weather", "alerts", "gold_silver", "breaking_news", "markets")
        val defaultOrder = listOf("briefing", "weather", "calendar", "alerts", "gold_silver", "forex", "breaking_news", "crypto", "markets", "verse")

        val enabledWidgetsStr = prefs.getString("pref_enabled_widgets", null)
        val enabledWidgets = if (!enabledWidgetsStr.isNullOrBlank()) {
            enabledWidgetsStr.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        } else {
            defaultEnabled
        }

        val widgetOrderStr = prefs.getString("pref_widget_order", null)
        val loadedOrder = if (!widgetOrderStr.isNullOrBlank()) {
            widgetOrderStr.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        } else {
            defaultOrder
        }
        val completeWidgetOrder = (loadedOrder + defaultOrder).distinct()

        val morningNotifEnabled = prefs.getBoolean("pref_morning_notification_enabled", true)
        val morningHour = prefs.getInt("pref_morning_hour", 7)
        val morningMinute = prefs.getInt("pref_morning_minute", 0)
        val autoRefreshMinutes = prefs.getInt("pref_auto_refresh_minutes", 15).coerceAtLeast(15)
        val disasterNotifEnabled = prefs.getBoolean("pref_disaster_notification_enabled", true)
        val dailyVerseEnabled = prefs.getBoolean("pref_daily_bible_verse_enabled", false)
        val showUpcomingInBriefing = prefs.getBoolean("pref_show_upcoming_events_in_briefing", true)
        val nepaliDateNotifEnabled = prefs.getBoolean("pref_nepali_date_notif_enabled", true)
        val weatherNotifEnabled = prefs.getBoolean("pref_weather_notif_enabled", true)
        val calendarReminderEnabled = prefs.getBoolean("pref_calendar_event_reminder_enabled", true)
        val hasCompletedOnboarding = prefs.getBoolean("pref_has_completed_onboarding", false)

        return UserPreferences(
            preferredCity = city,
            preferredCountry = country,
            temperatureUnit = tempUnit,
            goldWeightUnit = goldUnit,
            favoriteCurrencies = favCurrencies,
            favoriteMarkets = favMarkets,
            selectedNewsCategories = selectedNewsCategories,
            enabledWidgets = enabledWidgets,
            widgetOrder = completeWidgetOrder,
            ttsSpeed = speed,
            autoRefreshMinutes = autoRefreshMinutes,
            morningBriefingNotificationEnabled = morningNotifEnabled,
            morningBriefingHour = morningHour,
            morningBriefingMinute = morningMinute,
            disasterAlertsNotificationEnabled = disasterNotifEnabled,
            dailyBibleVerseEnabled = dailyVerseEnabled,
            showUpcomingEventsInBriefing = showUpcomingInBriefing,
            nepaliDateNotificationEnabled = nepaliDateNotifEnabled,
            weatherNotificationEnabled = weatherNotifEnabled,
            calendarEventReminderEnabled = calendarReminderEnabled,
            hasCompletedOnboarding = hasCompletedOnboarding
        )
    }

    private fun savePreferences(p: UserPreferences) {
        prefs.edit()
            .putString("pref_city", p.preferredCity)
            .putString("pref_country", p.preferredCountry)
            .putString("pref_temp", if (p.temperatureUnit == TemperatureUnit.FAHRENHEIT) "F" else "C")
            .putString("pref_gold_unit", p.goldWeightUnit.name)
            .putFloat("pref_tts_speed", p.ttsSpeed)
            .putInt("pref_auto_refresh_minutes", p.autoRefreshMinutes)
            .putStringSet("pref_fav_currencies", p.favoriteCurrencies.toSet())
            .putStringSet("pref_fav_markets", p.favoriteMarkets.toSet())
            .putString("pref_news_categories", p.selectedNewsCategories.joinToString("|"))
            .putString("pref_enabled_widgets", p.enabledWidgets.joinToString(","))
            .putString("pref_widget_order", p.widgetOrder.joinToString(","))
            .putBoolean("pref_morning_notification_enabled", p.morningBriefingNotificationEnabled)
            .putInt("pref_morning_hour", p.morningBriefingHour)
            .putInt("pref_morning_minute", p.morningBriefingMinute)
            .putBoolean("pref_disaster_notification_enabled", p.disasterAlertsNotificationEnabled)
            .putBoolean("pref_daily_bible_verse_enabled", p.dailyBibleVerseEnabled)
            .putBoolean("pref_show_upcoming_events_in_briefing", p.showUpcomingEventsInBriefing)
            .putBoolean("pref_nepali_date_notif_enabled", p.nepaliDateNotificationEnabled)
            .putBoolean("pref_weather_notif_enabled", p.weatherNotificationEnabled)
            .putBoolean("pref_calendar_event_reminder_enabled", p.calendarEventReminderEnabled)
            .putBoolean("pref_has_completed_onboarding", p.hasCompletedOnboarding)
            .apply()
    }

    private fun loadBookmarkedIds() {
        val set = prefs.getStringSet("bookmarked_ids", emptySet()) ?: emptySet()
        bookmarkedIds.addAll(set)
    }

    private fun saveBookmarkedIds() {
        prefs.edit().putStringSet("bookmarked_ids", bookmarkedIds).apply()
    }

    private fun saveCachedBriefing(b: MorningBriefing) {
        scope.launch {
            try {
                briefingDao.insertBriefing(b.toEntity())
            } catch (_: Exception) {}
        }
        try {
            val json = JSONObject().apply {
                put("generatedAtMillis", b.generatedAtMillis)
                put("formattedDate", b.formattedDate)
                put("greeting", b.greeting)
                put("executiveSummary", b.executiveSummary)
                put("goldForexSnippet", b.goldForexSnippet)
                put("weatherSnippet", b.weatherSnippet)
                put("alertsSnippet", b.alertsSnippet)
                put("spokenScript", b.spokenScript)
                b.bibleVerse?.let { v ->
                    val vObj = JSONObject().apply {
                        put("reference", v.reference)
                        put("text", v.text)
                        put("translation", v.translation)
                        put("theme", v.theme)
                        put("dateFormatted", v.dateFormatted)
                    }
                    put("bibleVerse", vObj)
                }
            }
            prefs.edit().putString("cached_briefing_json", json.toString()).apply()
        } catch (_: Exception) {}
    }

    private fun saveCachedBullion(rates: GoldSilverRates) {
        try {
            val json = JSONObject().apply {
                put("fineGold10g", rates.fineGold10g)
                put("fineGoldTola", rates.fineGoldTola)
                put("tejabiGold10g", rates.tejabiGold10g)
                put("tejabiGoldTola", rates.tejabiGoldTola)
                put("silver10g", rates.silver10g)
                put("silverTola", rates.silverTola)
                put("publishedDate", rates.publishedDate)
                put("publishedTime", rates.publishedTime)
                put("yesterdayFineGoldTola", rates.yesterdayFineGoldTola)
                put("yesterdaySilverTola", rates.yesterdaySilverTola)
                put("changeGoldTola", rates.changeGoldTola)
                put("changeGoldTolaPercent", rates.changeGoldTolaPercent)
                put("changeSilverTola", rates.changeSilverTola)
                put("changeSilverTolaPercent", rates.changeSilverTolaPercent)
                put("retrievedAtMillis", rates.retrievedAtMillis)
            }
            prefs.edit().putString("cached_bullion_json", json.toString()).apply()
        } catch (_: Exception) {}
    }

    private fun saveCachedForex(list: List<ForexRateItem>) {
        try {
            val arr = JSONArray()
            for (item in list) {
                arr.put(JSONObject().apply {
                    put("code", item.currencyCode)
                    put("name", item.currencyName)
                    put("flag", item.flagEmoji)
                    put("unit", item.unit)
                    put("buy", item.buyRate)
                    put("sell", item.sellRate)
                    put("date", item.date)
                    put("pub", item.publishedOn)
                    put("isFav", item.isFavorite)
                })
            }
            prefs.edit().putString("cached_forex_json", arr.toString()).apply()
        } catch (_: Exception) {}
    }

    private fun saveCachedWeather(w: WeatherInfo) {
        try {
            val json = JSONObject().apply {
                put("cityName", w.cityName)
                put("country", w.country)
                put("latitude", w.latitude)
                put("longitude", w.longitude)
                put("currentTempC", w.currentTempC)
                put("feelsLikeC", w.feelsLikeC)
                put("humidityPercent", w.humidityPercent)
                put("windSpeedKmh", w.windSpeedKmh)
                put("windDirection", w.windDirection)
                put("precipitationMm", w.precipitationMm)
                put("rainProbability", w.rainProbability)
                put("uvIndex", w.uvIndex)
                put("aqi", w.aqi)
                put("aqiStatus", w.aqiStatus)
                put("weatherCode", w.weatherCode)
                put("conditionDescription", w.conditionDescription)
                put("sunriseTime", w.sunriseTime)
                put("sunsetTime", w.sunsetTime)
                put("retrievedAtMillis", w.retrievedAtMillis)
            }
            prefs.edit().putString("cached_weather_json", json.toString()).apply()
        } catch (_: Exception) {}
    }

    private fun saveCachedNews(list: List<NewsArticle>) {
        try {
            val arr = JSONArray()
            for (item in list.take(60)) {
                arr.put(JSONObject().apply {
                    put("id", item.id)
                    put("title", item.title)
                    put("summary", item.summary)
                    put("sourceName", item.sourceName)
                    put("sourceUrl", item.sourceUrl)
                    put("imageUrl", item.imageUrl ?: "")
                    put("pubDateMillis", item.pubDateMillis)
                    put("pubDateFormatted", item.pubDateFormatted)
                    put("freshnessLabel", item.freshnessLabel)
                    put("category", item.category)
                    put("isBreaking", item.isBreaking)
                    put("aiSummary", item.aiSummary ?: "")
                })
            }
            prefs.edit().putString("cached_news_json", arr.toString()).apply()
        } catch (_: Exception) {}
    }

    private fun loadCachedData() {
        try {
            val bullionStr = prefs.getString("cached_bullion_json", null)
            if (bullionStr != null) {
                val j = JSONObject(bullionStr)
                _bullionRates.value = GoldSilverRates(
                    fineGold10g = j.optDouble("fineGold10g"),
                    fineGoldTola = j.optDouble("fineGoldTola"),
                    tejabiGold10g = j.optDouble("tejabiGold10g"),
                    tejabiGoldTola = j.optDouble("tejabiGoldTola"),
                    silver10g = j.optDouble("silver10g"),
                    silverTola = j.optDouble("silverTola"),
                    publishedDate = j.optString("publishedDate"),
                    publishedTime = j.optString("publishedTime"),
                    yesterdayFineGoldTola = j.optDouble("yesterdayFineGoldTola"),
                    yesterdaySilverTola = j.optDouble("yesterdaySilverTola"),
                    changeGoldTola = j.optDouble("changeGoldTola"),
                    changeGoldTolaPercent = j.optDouble("changeGoldTolaPercent"),
                    changeSilverTola = j.optDouble("changeSilverTola"),
                    changeSilverTolaPercent = j.optDouble("changeSilverTolaPercent"),
                    freshnessStatus = FreshnessStatus.STALE,
                    retrievedAtMillis = j.optLong("retrievedAtMillis")
                )
            }
        } catch (_: Exception) {}

        try {
            val weatherStr = prefs.getString("cached_weather_json", null)
            if (weatherStr != null) {
                val j = JSONObject(weatherStr)
                _weather.value = WeatherInfo(
                    cityName = j.optString("cityName", "Kathmandu"),
                    country = j.optString("country", "Nepal"),
                    latitude = j.optDouble("latitude", 27.7172),
                    longitude = j.optDouble("longitude", 85.3240),
                    currentTempC = j.optDouble("currentTempC", 24.0),
                    feelsLikeC = j.optDouble("feelsLikeC", 25.0),
                    humidityPercent = j.optInt("humidityPercent", 60),
                    windSpeedKmh = j.optDouble("windSpeedKmh", 8.0),
                    windDirection = j.optString("windDirection", "W"),
                    precipitationMm = j.optDouble("precipitationMm", 0.0),
                    rainProbability = j.optInt("rainProbability", 10),
                    uvIndex = j.optDouble("uvIndex", 5.0),
                    aqi = j.optInt("aqi", 45),
                    aqiStatus = j.optString("aqiStatus", "Good"),
                    weatherCode = j.optInt("weatherCode", 1),
                    conditionDescription = j.optString("conditionDescription", "Partly Cloudy"),
                    sunriseTime = j.optString("sunriseTime", "06:00 AM"),
                    sunsetTime = j.optString("sunsetTime", "05:45 PM"),
                    hourlyForecast = emptyList(),
                    dailyForecast = emptyList(),
                    freshnessStatus = FreshnessStatus.STALE,
                    retrievedAtMillis = j.optLong("retrievedAtMillis", System.currentTimeMillis())
                )
            }
        } catch (_: Exception) {}

        try {
            val newsStr = prefs.getString("cached_news_json", null)
            if (newsStr != null) {
                val arr = JSONArray(newsStr)
                val cachedList = mutableListOf<NewsArticle>()
                for (i in 0 until arr.length()) {
                    val j = arr.getJSONObject(i)
                    val id = j.optString("id")
                    val img = j.optString("imageUrl", "").takeIf { it.isNotBlank() }
                    val aiSum = j.optString("aiSummary", "").takeIf { it.isNotBlank() }
                    cachedList.add(
                        NewsArticle(
                            id = id,
                            title = j.optString("title"),
                            summary = j.optString("summary"),
                            sourceName = j.optString("sourceName"),
                            sourceUrl = j.optString("sourceUrl"),
                            imageUrl = img,
                            pubDateMillis = j.optLong("pubDateMillis"),
                            pubDateFormatted = j.optString("pubDateFormatted"),
                            freshnessLabel = j.optString("freshnessLabel", "Cached"),
                            category = j.optString("category"),
                            isBreaking = j.optBoolean("isBreaking", false),
                            isBookmarked = bookmarkedIds.contains(id),
                            aiSummary = aiSum
                        )
                    )
                }
                if (cachedList.isNotEmpty() && _news.value.isEmpty()) {
                    _news.value = cachedList
                }
            }
        } catch (_: Exception) {}

        try {
            val forexStr = prefs.getString("cached_forex_json", null)
            if (forexStr != null) {
                val arr = JSONArray(forexStr)
                val cachedForex = mutableListOf<ForexRateItem>()
                val favCurrencies = _userPreferences.value.favoriteCurrencies
                for (i in 0 until arr.length()) {
                    val j = arr.getJSONObject(i)
                    val code = j.optString("code")
                    cachedForex.add(
                        ForexRateItem(
                            currencyCode = code,
                            currencyName = j.optString("name"),
                            flagEmoji = j.optString("flag"),
                            unit = j.optInt("unit", 1),
                            buyRate = j.optDouble("buy"),
                            sellRate = j.optDouble("sell"),
                            date = j.optString("date"),
                            publishedOn = j.optString("pub"),
                            freshnessStatus = FreshnessStatus.STALE,
                            isFavorite = favCurrencies.contains(code)
                        )
                    )
                }
                if (cachedForex.isNotEmpty() && _forexRates.value.isEmpty()) {
                    _forexRates.value = cachedForex.sortedByDescending { it.isFavorite }
                }
            }
        } catch (_: Exception) {}
    }

    companion object {
        @android.annotation.SuppressLint("StaticFieldLeak")
        @Volatile
        private var INSTANCE: MornixRepository? = null

        fun getInstance(context: Context): MornixRepository {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: MornixRepository(context.applicationContext).also { INSTANCE = it }
            }
        }

        fun setInstanceForTesting(repository: MornixRepository?) {
            synchronized(this) {
                INSTANCE = repository
            }
        }
    }
}


