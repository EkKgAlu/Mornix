package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface BriefingDao {

    @Query("SELECT * FROM daily_briefings ORDER BY generatedAtMillis DESC LIMIT 1")
    fun getLatestBriefingFlow(): Flow<BriefingEntity?>

    @Query("SELECT * FROM daily_briefings ORDER BY generatedAtMillis DESC LIMIT 1")
    suspend fun getLatestBriefing(): BriefingEntity?

    @Query("SELECT * FROM daily_briefings ORDER BY generatedAtMillis DESC")
    fun getAllBriefingsFlow(): Flow<List<BriefingEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBriefing(briefing: BriefingEntity)

    @Query("DELETE FROM daily_briefings WHERE dateKey = :dateKey")
    suspend fun deleteBriefingByDate(dateKey: String)

    @Query("DELETE FROM daily_briefings")
    suspend fun clearAllBriefings()
}
