package com.example.service

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequest
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequest
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.example.data.repository.MornixRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

/**
 * WorkManager-based background sync worker that periodically checks for and fetches updates
 * to news, weather, exchange rates (NRB forex), bullion rates, markets, and disaster alerts
 * without manual user intervention.
 */
class MornixSyncWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val syncReason = inputData.getString(KEY_SYNC_REASON) ?: REASON_PERIODIC
        return@withContext try {
            val repository = MornixRepository.getInstance(applicationContext)
            val summary = repository.performBackgroundSync(syncReason = syncReason)

            val outputData = workDataOf(
                KEY_SYNC_REASON to syncReason,
                KEY_LAST_SYNC_MILLIS to summary.syncedAtMillis,
                KEY_NEWS_UPDATED to summary.newsSuccess,
                KEY_WEATHER_UPDATED to summary.weatherSuccess,
                KEY_FOREX_UPDATED to summary.forexSuccess,
                KEY_BULLION_UPDATED to summary.bullionSuccess,
                KEY_NEWS_COUNT to summary.newsCount,
                KEY_FOREX_COUNT to summary.forexCount
            )

            if (summary.hasAnySuccess) {
                Result.success(outputData)
            } else if (runAttemptCount < MAX_RETRY_ATTEMPTS) {
                Result.retry()
            } else {
                Result.failure(outputData)
            }
        } catch (e: Exception) {
            if (runAttemptCount < MAX_RETRY_ATTEMPTS) {
                Result.retry()
            } else {
                Result.failure(
                    workDataOf(
                        KEY_SYNC_REASON to syncReason,
                        KEY_ERROR_MESSAGE to (e.message ?: "Background sync error")
                    )
                )
            }
        }
    }

    companion object {
        const val UNIQUE_PERIODIC_WORK_NAME = "mornix_periodic_background_sync"
        const val UNIQUE_ONETIME_WORK_NAME = "mornix_immediate_background_sync"

        const val TAG_PERIODIC_SYNC = "mornix_tag_periodic_sync"
        const val TAG_IMMEDIATE_SYNC = "mornix_tag_immediate_sync"

        const val KEY_SYNC_REASON = "key_sync_reason"
        const val KEY_LAST_SYNC_MILLIS = "key_last_sync_millis"
        const val KEY_NEWS_UPDATED = "key_news_updated"
        const val KEY_WEATHER_UPDATED = "key_weather_updated"
        const val KEY_FOREX_UPDATED = "key_forex_updated"
        const val KEY_BULLION_UPDATED = "key_bullion_updated"
        const val KEY_NEWS_COUNT = "key_news_count"
        const val KEY_FOREX_COUNT = "key_forex_count"
        const val KEY_ERROR_MESSAGE = "key_error_message"

        const val REASON_PERIODIC = "periodic_background_sync"
        const val REASON_IMMEDIATE = "immediate_background_sync"
        const val REASON_BOOT = "boot_completed_sync"

        const val DEFAULT_SYNC_INTERVAL_MINUTES = 15L
        const val MIN_WORK_INTERVAL_MINUTES = 15L
        const val BACKOFF_DELAY_MINUTES = 5L
        const val MAX_RETRY_ATTEMPTS = 3

        /**
         * Builds the network-constrained [Constraints] required for background data synchronization.
         */
        fun buildSyncConstraints(): Constraints {
            return Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()
        }

        /**
         * Builds a [PeriodicWorkRequest] configured with network connectivity constraints
         * and exponential backoff to keep news, weather, and exchange rates fresh.
         */
        fun buildPeriodicWorkRequest(
            intervalMinutes: Long = DEFAULT_SYNC_INTERVAL_MINUTES
        ): PeriodicWorkRequest {
            val coercedMinutes = intervalMinutes.coerceAtLeast(MIN_WORK_INTERVAL_MINUTES)
            return PeriodicWorkRequestBuilder<MornixSyncWorker>(
                coercedMinutes,
                TimeUnit.MINUTES
            )
                .setConstraints(buildSyncConstraints())
                .setInputData(workDataOf(KEY_SYNC_REASON to REASON_PERIODIC))
                .setBackoffCriteria(
                    BackoffPolicy.EXPONENTIAL,
                    BACKOFF_DELAY_MINUTES,
                    TimeUnit.MINUTES
                )
                .addTag(TAG_PERIODIC_SYNC)
                .build()
        }

        /**
         * Builds a [OneTimeWorkRequest] for immediate background synchronization once network is connected.
         */
        fun buildOneTimeWorkRequest(reason: String = REASON_IMMEDIATE): OneTimeWorkRequest {
            return OneTimeWorkRequestBuilder<MornixSyncWorker>()
                .setConstraints(buildSyncConstraints())
                .setInputData(workDataOf(KEY_SYNC_REASON to reason))
                .setBackoffCriteria(
                    BackoffPolicy.EXPONENTIAL,
                    BACKOFF_DELAY_MINUTES,
                    TimeUnit.MINUTES
                )
                .addTag(TAG_IMMEDIATE_SYNC)
                .build()
        }

        /**
         * Enqueues or updates the unique periodic background sync job in [WorkManager].
         */
        fun schedulePeriodicSync(
            context: Context,
            intervalMinutes: Long = DEFAULT_SYNC_INTERVAL_MINUTES,
            replaceExisting: Boolean = false
        ) {
            try {
                val request = buildPeriodicWorkRequest(intervalMinutes)
                val policy = if (replaceExisting) {
                    ExistingPeriodicWorkPolicy.UPDATE
                } else {
                    ExistingPeriodicWorkPolicy.KEEP
                }
                WorkManager.getInstance(context.applicationContext).enqueueUniquePeriodicWork(
                    UNIQUE_PERIODIC_WORK_NAME,
                    policy,
                    request
                )
            } catch (_: Exception) {
                // Safely ignore if WorkManager is not initialized in isolated JVM test environments
            }
        }

        /**
         * Enqueues a one-time background sync request when immediate background refresh is needed
         * (e.g., after device reboot or alarm receiver trigger).
         */
        fun triggerImmediateSync(
            context: Context,
            reason: String = REASON_IMMEDIATE
        ) {
            try {
                val request = buildOneTimeWorkRequest(reason)
                WorkManager.getInstance(context.applicationContext).enqueueUniqueWork(
                    UNIQUE_ONETIME_WORK_NAME,
                    ExistingWorkPolicy.REPLACE,
                    request
                )
            } catch (_: Exception) {
                // Safely ignore if WorkManager is not initialized in isolated JVM test environments
            }
        }

        /**
         * Cancels the periodic background sync worker.
         */
        fun cancelPeriodicSync(context: Context) {
            try {
                WorkManager.getInstance(context.applicationContext)
                    .cancelUniqueWork(UNIQUE_PERIODIC_WORK_NAME)
            } catch (_: Exception) {
            }
        }
    }
}
