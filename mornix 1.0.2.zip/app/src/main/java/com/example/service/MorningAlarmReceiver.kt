package com.example.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.model.FreshnessStatus
import com.example.data.model.MorningBriefing
import com.example.data.model.TemperatureUnit
import com.example.data.model.WeatherInfo
import com.example.data.remote.LocationHelper
import com.example.data.remote.WeatherService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MorningAlarmReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_MORNING_ALARM = "com.example.mornix.ACTION_MORNING_ALARM"
        const val ACTION_MIDNIGHT_DATE_UPDATE = "com.example.mornix.ACTION_MIDNIGHT_DATE_UPDATE"
        const val ACTION_LIVE_STATUS_REFRESH = "com.example.mornix.ACTION_LIVE_STATUS_REFRESH"
        const val ACTION_CALENDAR_EVENT_REMINDER = "com.example.mornix.ACTION_CALENDAR_EVENT_REMINDER"
    }

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: ACTION_MORNING_ALARM
        val sp = context.getSharedPreferences("mornix_secure_prefs", Context.MODE_PRIVATE)

        when (action) {
            ACTION_MORNING_ALARM -> {
                handleMorningBriefingAlarm(context, sp)
            }
            ACTION_CALENDAR_EVENT_REMINDER -> {
                val reminderEnabled = sp.getBoolean("pref_calendar_event_reminder_enabled", true)
                MornixNotificationHelper.syncCalendarEventReminders(context, reminderEnabled)
            }
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            "android.intent.action.QUICKBOOT_POWERON",
            "com.htc.intent.action.QUICKBOOT_POWERON" -> {
                // 1. Restore Morning Briefing daily alarm if enabled
                val morningEnabled = sp.getBoolean("pref_morning_notification_enabled", true)
                val hour = sp.getInt("pref_morning_hour", 7)
                val minute = sp.getInt("pref_morning_minute", 0)
                if (morningEnabled) {
                    MornixNotificationHelper.scheduleDailyBriefingAlarm(context, hour, minute)
                } else {
                    MornixNotificationHelper.cancelDailyBriefingAlarm(context)
                }
                // 2. Restore Live Status Notification if either switch is enabled
                handleLiveStatusUpdate(context, sp, refreshNetworkWeather = true)
                // 3. Restore Calendar Event Reminder alarm & check tomorrow's events independently
                val reminderEnabled = sp.getBoolean("pref_calendar_event_reminder_enabled", true)
                MornixNotificationHelper.syncCalendarEventReminders(context, reminderEnabled)
                // 4. Restore WorkManager periodic background sync for news, weather, and exchange rates
                val intervalMinutes = sp.getInt("pref_auto_refresh_minutes", 15).toLong().coerceAtLeast(15L)
                MornixSyncWorker.schedulePeriodicSync(context, intervalMinutes, replaceExisting = false)
                MornixSyncWorker.triggerImmediateSync(context, MornixSyncWorker.REASON_BOOT)
            }
            ACTION_MIDNIGHT_DATE_UPDATE,
            ACTION_LIVE_STATUS_REFRESH,
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED -> {
                val shouldFetchWeather = (action == ACTION_LIVE_STATUS_REFRESH || action == ACTION_MIDNIGHT_DATE_UPDATE)
                handleLiveStatusUpdate(context, sp, refreshNetworkWeather = shouldFetchWeather)
                if (action != ACTION_LIVE_STATUS_REFRESH) {
                    val reminderEnabled = sp.getBoolean("pref_calendar_event_reminder_enabled", true)
                    MornixNotificationHelper.syncCalendarEventReminders(context, reminderEnabled)
                }
                if (shouldFetchWeather) {
                    val intervalMinutes = sp.getInt("pref_auto_refresh_minutes", 15).toLong().coerceAtLeast(15L)
                    MornixSyncWorker.schedulePeriodicSync(context, intervalMinutes, replaceExisting = false)
                }
            }
        }
    }

    private fun handleMorningBriefingAlarm(context: Context, sp: android.content.SharedPreferences) {
        val isEnabled = sp.getBoolean("pref_morning_notification_enabled", true)
        val hour = sp.getInt("pref_morning_hour", 7)
        val minute = sp.getInt("pref_morning_minute", 0)

        if (!isEnabled) return

        // 1. Re-schedule for tomorrow to ensure uninterrupted daily cycle
        MornixNotificationHelper.scheduleDailyBriefingAlarm(context, hour, minute)

        // 2. Build or read cached morning briefing
        val briefing = loadCachedBriefing(sp) ?: createFallbackBriefing()

        // 3. Post notification with Listen action button
        MornixNotificationHelper.showMorningBriefingNotification(context, briefing)
    }

    private fun handleLiveStatusUpdate(
        context: Context,
        sp: android.content.SharedPreferences,
        refreshNetworkWeather: Boolean
    ) {
        val nepaliDateEnabled = sp.getBoolean("pref_nepali_date_notif_enabled", true)
        val weatherEnabled = sp.getBoolean("pref_weather_notif_enabled", true)
        val tempUnit = if (sp.getString("pref_temp", "C") == "F") {
            TemperatureUnit.FAHRENHEIT
        } else {
            TemperatureUnit.CELSIUS
        }
        val preferredCity = sp.getString("pref_city", "Current Location") ?: "Current Location"

        val cachedWeather = loadCachedWeather(sp)

        // First post immediately using cached weather so notification updates with zero delay
        MornixNotificationHelper.updateOrCancelLiveStatusNotification(
            context = context,
            nepaliDateEnabled = nepaliDateEnabled,
            weatherEnabled = weatherEnabled,
            weather = cachedWeather,
            tempUnit = tempUnit,
            fallbackCity = preferredCity
        )

        if (!weatherEnabled || !refreshNetworkWeather) return

        val pendingResult = try { goAsync() } catch (_: Exception) { null }
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val weatherService = WeatherService()
                val weatherResult = if (preferredCity.equals("Current Location", ignoreCase = true)) {
                    val loc = LocationHelper.getDeviceLocation(context)
                    val displayCity = if (loc.cityName.isNotBlank() && loc.cityName != "Current Location") loc.cityName else "Current Location"
                    weatherService.fetchWeather(displayCity, loc.latitude, loc.longitude)
                } else {
                    val coords = weatherService.popularCities.find { it.name.equals(preferredCity, ignoreCase = true) }
                        ?: weatherService.popularCities.first()
                    weatherService.fetchWeather(coords.name, coords.lat, coords.lon)
                }

                val freshWeather = weatherResult.getOrNull()
                if (freshWeather != null) {
                    saveCachedWeatherToPrefs(sp, freshWeather)
                    MornixNotificationHelper.updateOrCancelLiveStatusNotification(
                        context = context,
                        nepaliDateEnabled = sp.getBoolean("pref_nepali_date_notif_enabled", true),
                        weatherEnabled = sp.getBoolean("pref_weather_notif_enabled", true),
                        weather = freshWeather,
                        tempUnit = tempUnit,
                        fallbackCity = preferredCity
                    )
                }
            } catch (_: Exception) {
                // Keep cached weather notification displayed
            } finally {
                try { pendingResult?.finish() } catch (_: Exception) {}
            }
        }
    }

    private fun loadCachedWeather(sp: android.content.SharedPreferences): WeatherInfo? {
        val jsonStr = sp.getString("cached_weather_json", null) ?: return null
        return try {
            val j = JSONObject(jsonStr)
            WeatherInfo(
                cityName = j.optString("cityName", "Kathmandu"),
                country = j.optString("country", "Nepal"),
                latitude = j.optDouble("latitude", 27.7172),
                longitude = j.optDouble("longitude", 85.3240),
                currentTempC = j.optDouble("currentTempC", 24.0),
                feelsLikeC = j.optDouble("feelsLikeC", 25.0),
                humidityPercent = j.optInt("humidityPercent", 60),
                windSpeedKmh = j.optDouble("windSpeedKmh", 8.0),
                windDirection = j.optString("windDirection", "W"),
                precipitationMm = j.optDouble("precipitationMm", 0.0),
                rainProbability = j.optInt("rainProbability", 10),
                uvIndex = j.optDouble("uvIndex", 5.0),
                aqi = j.optInt("aqi", 45),
                aqiStatus = j.optString("aqiStatus", "Good"),
                weatherCode = j.optInt("weatherCode", 1),
                conditionDescription = j.optString("conditionDescription", "Partly Cloudy"),
                sunriseTime = j.optString("sunriseTime", "06:00 AM"),
                sunsetTime = j.optString("sunsetTime", "05:45 PM"),
                hourlyForecast = emptyList(),
                dailyForecast = emptyList(),
                freshnessStatus = FreshnessStatus.STALE,
                retrievedAtMillis = j.optLong("retrievedAtMillis", System.currentTimeMillis())
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun saveCachedWeatherToPrefs(sp: android.content.SharedPreferences, w: WeatherInfo) {
        try {
            val json = JSONObject().apply {
                put("cityName", w.cityName)
                put("country", w.country)
                put("latitude", w.latitude)
                put("longitude", w.longitude)
                put("currentTempC", w.currentTempC)
                put("feelsLikeC", w.feelsLikeC)
                put("humidityPercent", w.humidityPercent)
                put("windSpeedKmh", w.windSpeedKmh)
                put("windDirection", w.windDirection)
                put("precipitationMm", w.precipitationMm)
                put("rainProbability", w.rainProbability)
                put("uvIndex", w.uvIndex)
                put("aqi", w.aqi)
                put("aqiStatus", w.aqiStatus)
                put("weatherCode", w.weatherCode)
                put("conditionDescription", w.conditionDescription)
                put("sunriseTime", w.sunriseTime)
                put("sunsetTime", w.sunsetTime)
                put("retrievedAtMillis", w.retrievedAtMillis)
            }
            sp.edit().putString("cached_weather_json", json.toString()).apply()
        } catch (_: Exception) {}
    }

    private fun loadCachedBriefing(sp: android.content.SharedPreferences): MorningBriefing? {
        val jsonStr = sp.getString("cached_briefing_json", null) ?: return null
        return try {
            val json = JSONObject(jsonStr)
            val bvObj = json.optJSONObject("bibleVerse")
            val bibleVerse = if (bvObj != null) {
                com.example.data.model.BibleVerse(
                    reference = bvObj.optString("reference", ""),
                    text = bvObj.optString("text", ""),
                    translation = bvObj.optString("translation", "NIV"),
                    theme = bvObj.optString("theme", ""),
                    dateFormatted = bvObj.optString("dateFormatted", "")
                )
            } else null

            MorningBriefing(
                generatedAtMillis = json.optLong("generatedAtMillis", System.currentTimeMillis()),
                formattedDate = json.optString("formattedDate", SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.ENGLISH).format(Date())),
                greeting = json.optString("greeting", "Good Morning"),
                executiveSummary = json.optString("executiveSummary", "Your verified morning briefing is ready."),
                newsHighlights = emptyList(),
                goldForexSnippet = json.optString("goldForexSnippet", "Live verified Nepal market rates available."),
                weatherSnippet = json.optString("weatherSnippet", "Current local conditions updated."),
                alertsSnippet = json.optString("alertsSnippet", "No active natural hazards reported."),
                spokenScript = json.optString("spokenScript", "Good morning. Here is your Mornix daily update. Check the app for live rates and news."),
                isAiGenerated = true,
                bibleVerse = bibleVerse
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun createFallbackBriefing(): MorningBriefing {
        val today = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.ENGLISH).format(Date())
        return MorningBriefing(
            generatedAtMillis = System.currentTimeMillis(),
            formattedDate = today,
            greeting = "Good Morning",
            executiveSummary = "Your personalized Mornix morning briefing is ready with today's live bullion, forex, weather, and top headlines.",
            newsHighlights = emptyList(),
            goldForexSnippet = "FENEGOSIDA gold rates and Nepal Rastra Bank forex rates updated.",
            weatherSnippet = "Local forecasts available from Open-Meteo.",
            alertsSnippet = "Continuous monitoring for seismic and disaster alerts.",
            spokenScript = "Good morning. This is Mornix with your daily morning briefing for $today. Check your local gold, forex, and news feeds in the app. Have a productive day ahead.",
            isAiGenerated = true
        )
    }
}

