package com.example.service

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.util.Locale

enum class OemOsFamily(
    val id: String,
    val manufacturerDisplay: String,
    val osDisplay: String,
    val liveIslandTerm: String,
    val isChineseCustomOs: Boolean
) {
    XIAOMI_HYPEROS(
        id = "xiaomi_hyperos",
        manufacturerDisplay = "Xiaomi / Redmi / POCO",
        osDisplay = "Xiaomi HyperOS",
        liveIslandTerm = "HyperOS Focus Notification & Dynamic Pill",
        isChineseCustomOs = true
    ),
    XIAOMI_MIUI(
        id = "xiaomi_miui",
        manufacturerDisplay = "Xiaomi / Redmi / POCO",
        osDisplay = "MIUI",
        liveIslandTerm = "MIUI Floating Banner & Status Bar Indicator",
        isChineseCustomOs = true
    ),
    OPPO_COLOROS(
        id = "oppo_coloros",
        manufacturerDisplay = "OPPO / Realme",
        osDisplay = "ColorOS",
        liveIslandTerm = "ColorOS Aqua Dynamics / Fluid Cloud Capsule",
        isChineseCustomOs = true
    ),
    ONEPLUS_OXYGENOS(
        id = "oneplus_oxygenos",
        manufacturerDisplay = "OnePlus",
        osDisplay = "OxygenOS",
        liveIslandTerm = "OxygenOS Fluid Cloud & Live Status Chip",
        isChineseCustomOs = true
    ),
    VIVO_ORIGINOS(
        id = "vivo_originos",
        manufacturerDisplay = "Vivo / iQOO",
        osDisplay = "OriginOS",
        liveIslandTerm = "OriginOS Atomic Island & Status Pill",
        isChineseCustomOs = true
    ),
    VIVO_FUNTOUCHOS(
        id = "vivo_funtouchos",
        manufacturerDisplay = "Vivo / iQOO",
        osDisplay = "Funtouch OS",
        liveIslandTerm = "Funtouch OS Floating Banner & Lock Screen",
        isChineseCustomOs = true
    ),
    HUAWEI_HARMONYOS(
        id = "huawei_harmonyos",
        manufacturerDisplay = "Huawei",
        osDisplay = "HarmonyOS",
        liveIslandTerm = "HarmonyOS Live Window (实况窗) & Capsule",
        isChineseCustomOs = true
    ),
    HUAWEI_EMUI(
        id = "huawei_emui",
        manufacturerDisplay = "Huawei",
        osDisplay = "EMUI",
        liveIslandTerm = "EMUI Banners & Status Bar Live Indicator",
        isChineseCustomOs = true
    ),
    HONOR_MAGICOS(
        id = "honor_magicos",
        manufacturerDisplay = "Honor",
        osDisplay = "MagicOS",
        liveIslandTerm = "MagicOS Magic Capsule (灵动胶囊)",
        isChineseCustomOs = true
    ),
    SAMSUNG_ONEUI(
        id = "samsung_oneui",
        manufacturerDisplay = "Samsung",
        osDisplay = "One UI",
        liveIslandTerm = "One UI Ongoing Chip / Now Bar & Brief Pop-up",
        isChineseCustomOs = false
    ),
    GOOGLE_PIXEL(
        id = "google_pixel",
        manufacturerDisplay = "Google Pixel",
        osDisplay = "Stock Pixel Android",
        liveIslandTerm = "Android Status Bar Chip & Heads-Up Pop-up",
        isChineseCustomOs = false
    ),
    STANDARD_ANDROID(
        id = "standard_android",
        manufacturerDisplay = "Standard Android Device",
        osDisplay = "AOSP / Standard Android",
        liveIslandTerm = "Android Ongoing Status & Heads-Up Notification",
        isChineseCustomOs = false
    )
}

data class OemSetupStep(
    val stepNumber: Int,
    val title: String,
    val instruction: String,
    val settingsPath: String
)

data class OemSetupGuide(
    val osFamily: OemOsFamily,
    val summaryNote: String,
    val steps: List<OemSetupStep>
)

data class DeviceNotificationDiagnostics(
    val detectedOsFamily: OemOsFamily,
    val manufacturerRaw: String,
    val brandRaw: String,
    val modelRaw: String,
    val androidRelease: String,
    val sdkInt: Int,
    val notificationsEnabled: Boolean,
    val liveStatusChannelEnabled: Boolean,
    val calendarReminderChannelHighImportance: Boolean,
    val morningBriefingChannelHighImportance: Boolean,
    val ignoringBatteryOptimizations: Boolean,
    val exactAlarmsAllowed: Boolean
) {
    val isFullyConfigured: Boolean
        get() = notificationsEnabled &&
            liveStatusChannelEnabled &&
            calendarReminderChannelHighImportance &&
            morningBriefingChannelHighImportance &&
            ignoringBatteryOptimizations &&
            exactAlarmsAllowed
}

object OemNotificationCompatibility {

    /**
     * Pure, deterministic manufacturer & OS skin detector.
     * Supports unit testing with simulated Build properties and system property maps.
     */
    fun detectOemOsFamily(
        manufacturer: String = Build.MANUFACTURER ?: "",
        brand: String = Build.BRAND ?: "",
        display: String = Build.DISPLAY ?: "",
        sdkInt: Int = Build.VERSION.SDK_INT,
        systemProps: Map<String, String> = readRelevantSystemProperties()
    ): OemOsFamily {
        val m = manufacturer.trim().lowercase(Locale.ENGLISH)
        val b = brand.trim().lowercase(Locale.ENGLISH)
        val d = display.trim().lowercase(Locale.ENGLISH)
        val propsLower = systemProps.mapKeys { it.key.lowercase(Locale.ENGLISH) }
            .mapValues { it.value.trim() }

        val isXiaomiFamily = m.contains("xiaomi") || m.contains("redmi") || m.contains("poco") ||
            b.contains("xiaomi") || b.contains("redmi") || b.contains("poco")
        if (isXiaomiFamily) {
            val hyperOsVersion = propsLower["ro.mi.os.version.name"]
                ?: propsLower["ro.mi.os.version.code"]
                ?: ""
            val isHyperOs = hyperOsVersion.isNotBlank() ||
                d.contains("hyperos") ||
                d.contains(".os1.") ||
                d.contains(".os2.") ||
                propsLower["ro.miui.ui.version.name"]?.uppercase(Locale.ENGLISH)?.startsWith("V816") == true
            return if (isHyperOs) OemOsFamily.XIAOMI_HYPEROS else OemOsFamily.XIAOMI_MIUI
        }

        val isOnePlus = m.contains("oneplus") || b.contains("oneplus")
        if (isOnePlus) {
            return OemOsFamily.ONEPLUS_OXYGENOS
        }

        val isOppoOrRealme = m.contains("oppo") || m.contains("realme") ||
            b.contains("oppo") || b.contains("realme") ||
            !propsLower["ro.build.version.opporom"].isNullOrBlank()
        if (isOppoOrRealme) {
            return OemOsFamily.OPPO_COLOROS
        }

        val isVivoOrIqoo = m.contains("vivo") || m.contains("iqoo") ||
            b.contains("vivo") || b.contains("iqoo") ||
            !propsLower["ro.vivo.os.name"].isNullOrBlank()
        if (isVivoOrIqoo) {
            val vivoOs = (propsLower["ro.vivo.os.name"] ?: propsLower["ro.vivo.os.build.display.id"] ?: "").lowercase(Locale.ENGLISH)
            val isOriginOs = vivoOs.contains("origin") || d.contains("originos")
            return if (isOriginOs) OemOsFamily.VIVO_ORIGINOS else OemOsFamily.VIVO_FUNTOUCHOS
        }

        val isHonor = m.contains("honor") || b.contains("honor") ||
            !propsLower["ro.magic.api.version"].isNullOrBlank() ||
            d.contains("magicos") || d.contains("magicui")
        if (isHonor) {
            return OemOsFamily.HONOR_MAGICOS
        }

        val isHuawei = m.contains("huawei") || b.contains("huawei")
        if (isHuawei) {
            val harmonyVer = propsLower["hw_sc.build.platform.version"]
                ?: propsLower["ro.harmonyos.version"]
                ?: ""
            val isHarmony = harmonyVer.isNotBlank() || d.contains("harmony")
            return if (isHarmony) OemOsFamily.HUAWEI_HARMONYOS else OemOsFamily.HUAWEI_EMUI
        }

        val isSamsung = m.contains("samsung") || b.contains("samsung")
        if (isSamsung) {
            return OemOsFamily.SAMSUNG_ONEUI
        }

        val isGooglePixel = m.contains("google") || b.contains("google") || b.contains("pixel")
        if (isGooglePixel) {
            return OemOsFamily.GOOGLE_PIXEL
        }

        return OemOsFamily.STANDARD_ANDROID
    }

    private fun readRelevantSystemProperties(): Map<String, String> {
        val keys = listOf(
            "ro.mi.os.version.name",
            "ro.mi.os.version.code",
            "ro.miui.ui.version.name",
            "ro.build.version.opporom",
            "ro.vivo.os.name",
            "ro.vivo.os.build.display.id",
            "hw_sc.build.platform.version",
            "ro.harmonyos.version",
            "ro.magic.api.version"
        )
        val result = mutableMapOf<String, String>()
        for (key in keys) {
            val value = getSystemPropertySafe(key)
            if (value.isNotBlank()) {
                result[key] = value
            }
        }
        return result
    }

    private fun getSystemPropertySafe(key: String): String {
        return try {
            val clazz = Class.forName("android.os.SystemProperties")
            val getMethod = clazz.getMethod("get", String::class.java, String::class.java)
            (getMethod.invoke(null, key, "") as? String)?.trim().orEmpty()
        } catch (_: Exception) {
            ""
        }
    }

    /**
     * Builds concise status chip text (max ~14 chars) for Status Bar indicators,
     * Android Promoted Ongoing chips, HyperOS Dynamic Island pills, ColorOS Fluid Cloud,
     * OriginOS Atomic Island, and HarmonyOS/MagicOS Live Capsules.
     */
    fun buildStatusChipSummary(
        nepaliDateEnabled: Boolean,
        weatherEnabled: Boolean,
        bsDayNumber: String?,
        bsMonthShort: String?,
        tempFormatted: String?
    ): String {
        return when {
            weatherEnabled && !tempFormatted.isNullOrBlank() && nepaliDateEnabled && !bsDayNumber.isNullOrBlank() -> {
                "$tempFormatted • $bsDayNumber"
            }
            weatherEnabled && !tempFormatted.isNullOrBlank() -> {
                tempFormatted
            }
            nepaliDateEnabled && !bsDayNumber.isNullOrBlank() && !bsMonthShort.isNullOrBlank() -> {
                "$bsDayNumber $bsMonthShort"
            }
            nepaliDateEnabled && !bsDayNumber.isNullOrBlank() -> {
                bsDayNumber
            }
            else -> "Mornix"
        }
    }

    /**
     * Enriches an ongoing Live Status Notification with standard Android and OEM-compatible
     * metadata so supported devices can display it in:
     * - Dynamic Island-style notification areas (HyperOS Focus, ColorOS/OxygenOS Fluid Cloud, OriginOS Atomic Island, MagicOS Capsule)
     * - Status bar notification indicators & ongoing chips (`android.shortCriticalText`, `subText`)
     * - Lock screen notifications & Always-on display (`VISIBILITY_PUBLIC`, `miui.enableKeyguard`)
     * - Ongoing notification areas (`setOngoing(true)`, `CATEGORY_STATUS`)
     */
    fun applyLiveStatusOemCompatibility(
        builder: NotificationCompat.Builder,
        chipSummary: String,
        primaryTitle: String,
        secondarySummary: String
    ): NotificationCompat.Builder {
        val extras = Bundle().apply {
            // Android 15/16+ & Pixel/One UI status bar chip / promoted ongoing text
            putString("android.shortCriticalText", chipSummary)
            putBoolean("android.requestPromotedOngoing", true)

            // Xiaomi MIUI / HyperOS Focus Notification & Lockscreen / Status Bar compatibility
            putBoolean("miui.enableKeyguard", true)
            putBoolean("miui.showOnKeyguard", true)
            putString("miui.focus.ticker", chipSummary)
            putString(
                "miui.focus.param",
                """{"protocol":1,"scene":"mornix_live_status","ticker":"$chipSummary","title":"$primaryTitle","content":"$secondarySummary","enableFloat":false,"updatable":true}"""
            )

            // OPPO ColorOS & OnePlus OxygenOS Fluid Cloud / Aqua Dynamics capsule metadata
            putInt("oplink.live_notification.type", 1)
            putString("oplink.live_notification.capsule_text", chipSummary)
            putString("coloros.fluid_cloud.capsule_title", chipSummary)

            // Vivo / iQOO OriginOS Atomic Island & Funtouch OS status pill metadata
            putBoolean("vivo.summaryIconRes", true)
            putString("originos.atomic_island.summary", chipSummary)

            // Huawei HarmonyOS Live Window & Honor MagicOS Magic Capsule metadata
            putString("hw_live_window_capsule_title", chipSummary)
            putString("magic_capsule_summary", chipSummary)
        }

        return builder
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setAutoCancel(false)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setShowWhen(true)
            .setSubText(chipSummary)
            .setTicker("$primaryTitle • $chipSummary")
            .addExtras(extras)
    }

    /**
     * Enriches high-priority alert / reminder notifications (Calendar Event Reminders,
     * Morning Briefing, Disaster Alerts) with floating/banner/heads-up and lock screen
     * compatibility metadata across Chinese Android OS skins and standard Android.
     */
    fun applyFloatingAlertOemCompatibility(
        builder: NotificationCompat.Builder,
        category: String = NotificationCompat.CATEGORY_REMINDER,
        shortBannerTag: String = "Mornix"
    ): NotificationCompat.Builder {
        val extras = Bundle().apply {
            // Xiaomi MIUI / HyperOS floating notification & lockscreen wake hints
            putBoolean("miui.enableFloat", true)
            putBoolean("miui.enableKeyguard", true)
            putString("miui.focus.ticker", shortBannerTag)
            // ColorOS / OriginOS / EMUI heads-up banner hint
            putBoolean("headsup_notification_enabled", true)
        }

        return builder
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setCategory(category)
            .setSubText(shortBannerTag)
            .addExtras(extras)
    }

    /**
     * Inspects current device notification permissions, channels, battery optimization,
     * and exact alarm state without modifying any system settings.
     */
    fun inspectDeviceDiagnostics(
        context: Context,
        liveStatusChannelId: String = MornixNotificationHelper.CHANNEL_LIVE_STATUS_ID,
        calendarReminderChannelId: String = MornixNotificationHelper.CHANNEL_CALENDAR_REMINDER_ID,
        morningBriefingChannelId: String = MornixNotificationHelper.CHANNEL_BRIEFING_ID
    ): DeviceNotificationDiagnostics {
        val detectedOs = detectOemOsFamily()
        val notifCompat = NotificationManagerCompat.from(context)
        val notificationsEnabled = try {
            notifCompat.areNotificationsEnabled()
        } catch (_: Exception) {
            true
        }

        var liveChannelOk = true
        var reminderChannelHigh = true
        var briefingChannelHigh = true

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            if (nm != null) {
                nm.getNotificationChannel(liveStatusChannelId)?.let { ch ->
                    liveChannelOk = ch.importance != NotificationManager.IMPORTANCE_NONE
                }
                nm.getNotificationChannel(calendarReminderChannelId)?.let { ch ->
                    reminderChannelHigh = ch.importance >= NotificationManager.IMPORTANCE_HIGH
                }
                nm.getNotificationChannel(morningBriefingChannelId)?.let { ch ->
                    briefingChannelHigh = ch.importance >= NotificationManager.IMPORTANCE_HIGH
                }
            }
        }

        val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val ignoringBattery = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && pm != null) {
                pm.isIgnoringBatteryOptimizations(context.packageName)
            } else {
                true
            }
        } catch (_: Exception) {
            false
        }

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
        val exactAlarmsAllowed = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && alarmManager != null) {
                alarmManager.canScheduleExactAlarms()
            } else {
                true
            }
        } catch (_: Exception) {
            true
        }

        return DeviceNotificationDiagnostics(
            detectedOsFamily = detectedOs,
            manufacturerRaw = Build.MANUFACTURER ?: "Android",
            brandRaw = Build.BRAND ?: "Android",
            modelRaw = Build.MODEL ?: "Device",
            androidRelease = Build.VERSION.RELEASE ?: "${Build.VERSION.SDK_INT}",
            sdkInt = Build.VERSION.SDK_INT,
            notificationsEnabled = notificationsEnabled,
            liveStatusChannelEnabled = liveChannelOk,
            calendarReminderChannelHighImportance = reminderChannelHigh,
            morningBriefingChannelHighImportance = briefingChannelHigh,
            ignoringBatteryOptimizations = ignoringBattery,
            exactAlarmsAllowed = exactAlarmsAllowed
        )
    }

    /**
     * Returns clear, manufacturer-specific step-by-step instructions for enabling:
     * 1. Notifications & Lock Screen / AOD display
     * 2. Floating / Banner / Dynamic Island / Capsule notifications
     * 3. Background activity & Autostart after reboot
     */
    fun getSetupGuideForOs(osFamily: OemOsFamily): OemSetupGuide {
        return when (osFamily) {
            OemOsFamily.XIAOMI_HYPEROS -> OemSetupGuide(
                osFamily = osFamily,
                summaryNote = "Xiaomi HyperOS restricts background tasks, Autostart, and Floating/Lock Screen notifications by default. Enable these optional system settings so Mornix Live Status and reminders stay active.",
                steps = listOf(
                    OemSetupStep(
                        stepNumber = 1,
                        title = "Enable Lock Screen, Floating & Focus Notifications",
                        instruction = "Allow Mornix to display on the Lock Screen, Floating Notifications (banners), and HyperOS Focus / Status Bar.",
                        settingsPath = "Settings → Notifications & status bar → App notifications → Mornix → Enable 'Lock screen' & 'Floating notifications'"
                    ),
                    OemSetupStep(
                        stepNumber = 2,
                        title = "Enable Background Autostart",
                        instruction = "Allow Mornix to start automatically after device reboot or HyperOS memory cleanup.",
                        settingsPath = "Settings → Apps → Manage apps → Mornix → Background autostart (ON)"
                    ),
                    OemSetupStep(
                        stepNumber = 3,
                        title = "Set Battery Saver to 'No Restrictions'",
                        instruction = "Prevent HyperOS from stopping daily Nepali date updates and 1-day-before festival reminders.",
                        settingsPath = "Settings → Apps → Manage apps → Mornix → Battery saver → No restrictions"
                    )
                )
            )
            OemOsFamily.XIAOMI_MIUI -> OemSetupGuide(
                osFamily = osFamily,
                summaryNote = "MIUI disables Floating Notifications, Lock Screen cards, and Autostart for newly installed apps until enabled in system settings.",
                steps = listOf(
                    OemSetupStep(
                        stepNumber = 1,
                        title = "Allow Floating & Lock Screen Notifications",
                        instruction = "Turn on both 'Floating notifications' and 'Lock screen notifications' for Mornix.",
                        settingsPath = "Settings → Notifications & Control center → App notifications → Mornix"
                    ),
                    OemSetupStep(
                        stepNumber = 2,
                        title = "Turn On MIUI Autostart",
                        instruction = "Ensure Mornix restores the BS Date & Weather Live Notification after reboot.",
                        settingsPath = "Security App / Settings → Apps → Permissions → Autostart → Mornix (ON)"
                    ),
                    OemSetupStep(
                        stepNumber = 3,
                        title = "Disable MIUI Battery Restrictions",
                        instruction = "Choose 'No restrictions' so midnight Nepali date transitions run on time.",
                        settingsPath = "Settings → Apps → Manage apps → Mornix → Battery saver → No restrictions"
                    )
                )
            )
            OemOsFamily.OPPO_COLOROS -> OemSetupGuide(
                osFamily = osFamily,
                summaryNote = "ColorOS manages live status pills (Fluid Cloud / Aqua Dynamics), banners, and auto-launch in App Management.",
                steps = listOf(
                    OemSetupStep(
                        stepNumber = 1,
                        title = "Enable Banner, Lock Screen & Status Bar Icon",
                        instruction = "Enable 'Allow notifications', 'Lock screen', 'Banner', and 'Show icon in status bar'.",
                        settingsPath = "Settings → Notifications & Status Bar → Manage Notifications → Mornix"
                    ),
                    OemSetupStep(
                        stepNumber = 2,
                        title = "Allow Background Activity & Auto-Launch",
                        instruction = "Enable 'Allow background activity' and 'Auto-launch' so Live Status survives restarts.",
                        settingsPath = "Settings → Apps → App Management → Mornix → Battery Usage → Allow background activity"
                    ),
                    OemSetupStep(
                        stepNumber = 3,
                        title = "Enable Fluid Cloud / Live Alerts (ColorOS 14+)",
                        instruction = "Allow ongoing status indicators in the status bar and Fluid Cloud area where supported.",
                        settingsPath = "Settings → Notifications & Status Bar → Smart Services / Fluid Cloud"
                    )
                )
            )
            OemOsFamily.ONEPLUS_OXYGENOS -> OemSetupGuide(
                osFamily = osFamily,
                summaryNote = "OxygenOS uses Deep Optimization and Sleep Standby Optimization which can pause ongoing notifications if background activity is restricted.",
                steps = listOf(
                    OemSetupStep(
                        stepNumber = 1,
                        title = "Allow Lock Screen, Banners & Status Bar Chip",
                        instruction = "Ensure Lock screen, Banner notifications, and Status bar icons are enabled for Mornix channels.",
                        settingsPath = "Settings → Notifications & Quick Settings → App notifications → Mornix"
                    ),
                    OemSetupStep(
                        stepNumber = 2,
                        title = "Allow Background Activity",
                        instruction = "Turn on 'Allow background activity' and 'Allow auto Launch' for uninterrupted daily updates.",
                        settingsPath = "Settings → Apps → App Management → Mornix → Battery usage"
                    ),
                    OemSetupStep(
                        stepNumber = 3,
                        title = "Keep Ongoing Live Status Visible",
                        instruction = "Do not swipe-dismiss or mute the 'Live Daily Status' channel so the BS date & weather stay pinned.",
                        settingsPath = "Settings → Apps → App Management → Mornix → Manage notifications → Live Daily Status"
                    )
                )
            )
            OemOsFamily.VIVO_ORIGINOS -> OemSetupGuide(
                osFamily = osFamily,
                summaryNote = "OriginOS supports Atomic Island status pills and floating banners, but requires Floating Notification and High Background Power permissions.",
                steps = listOf(
                    OemSetupStep(
                        stepNumber = 1,
                        title = "Enable Floating, Lock Screen & Atomic Island Display",
                        instruction = "Turn on 'Allow Notifications', 'Floating notifications', 'Lock screen notifications', and status bar display.",
                        settingsPath = "Settings → Notifications & Status Bar → App notifications → Mornix"
                    ),
                    OemSetupStep(
                        stepNumber = 2,
                        title = "Enable Autostart & Associated Startup",
                        instruction = "Allow Mornix to auto-start after device reboot or system cleanup.",
                        settingsPath = "iManager / Settings → Apps & Permissions → Permission management → Autostart → Mornix"
                    ),
                    OemSetupStep(
                        stepNumber = 3,
                        title = "Allow High Background Power Usage",
                        instruction = "Set battery background control to 'Don't restrict background power usage'.",
                        settingsPath = "Settings → Battery → Background power consumption management → Mornix"
                    )
                )
            )
            OemOsFamily.VIVO_FUNTOUCHOS -> OemSetupGuide(
                osFamily = osFamily,
                summaryNote = "Funtouch OS restricts background wakeups and floating banners unless enabled in App & Battery settings.",
                steps = listOf(
                    OemSetupStep(
                        stepNumber = 1,
                        title = "Enable Floating & Lock Screen Notifications",
                        instruction = "Enable top preview / floating banners and lock screen visibility for Mornix.",
                        settingsPath = "Settings → Apps & Notifications → See all apps → Mornix → Notifications"
                    ),
                    OemSetupStep(
                        stepNumber = 2,
                        title = "Turn On Autostart",
                        instruction = "Allow Mornix to restart its Live Status & Calendar Reminder alarms after reboot.",
                        settingsPath = "Settings → More settings / App manager → Autostart → Mornix (ON)"
                    ),
                    OemSetupStep(
                        stepNumber = 3,
                        title = "Set Battery Usage to Unrestricted",
                        instruction = "Select 'Unrestricted' or 'High background power usage' for Mornix.",
                        settingsPath = "Settings → Battery → Background power consumption management → Mornix"
                    )
                )
            )
            OemOsFamily.HUAWEI_HARMONYOS -> OemSetupGuide(
                osFamily = osFamily,
                summaryNote = "HarmonyOS supports Live Window (实况窗), Banners, and Lock Screen notifications when App Launch is managed manually.",
                steps = listOf(
                    OemSetupStep(
                        stepNumber = 1,
                        title = "Enable Banners, Lock Screen & Live Window / Status Bar",
                        instruction = "Turn on 'Allow notifications', 'Lock screen notifications', 'Banners', and Live Window / Status bar icon.",
                        settingsPath = "Settings → Notifications & status bar → Mornix"
                    ),
                    OemSetupStep(
                        stepNumber = 2,
                        title = "Set App Launch to 'Manage Manually'",
                        instruction = "Turn OFF 'Manage automatically' and enable Auto-launch, Secondary launch, and Run in background.",
                        settingsPath = "Settings → Apps & services → App launch → Mornix → Manage manually (All 3 ON)"
                    ),
                    OemSetupStep(
                        stepNumber = 3,
                        title = "Ignore Battery Optimization",
                        instruction = "Allow Mornix in Battery Optimization so scheduled reminders fire on time.",
                        settingsPath = "Settings → Apps → Apps → Special access → Battery optimization → Mornix → Allow"
                    )
                )
            )
            OemOsFamily.HUAWEI_EMUI -> OemSetupGuide(
                osFamily = osFamily,
                summaryNote = "EMUI automatically closes background apps unless App Launch is switched to Manual Management.",
                steps = listOf(
                    OemSetupStep(
                        stepNumber = 1,
                        title = "Allow Banners & Lock Screen Notifications",
                        instruction = "Enable 'Display in status bar', 'Banners', and 'Lock screen notifications' for Mornix.",
                        settingsPath = "Settings → Notifications → Mornix"
                    ),
                    OemSetupStep(
                        stepNumber = 2,
                        title = "Configure Manual App Launch",
                        instruction = "Disable automatic management for Mornix and keep Auto-launch & Run in background enabled.",
                        settingsPath = "Settings → Battery → App launch → Mornix → Manage manually"
                    ),
                    OemSetupStep(
                        stepNumber = 3,
                        title = "Allow Ignore Battery Optimizations",
                        instruction = "Select 'Allow' under Battery Optimization for reliable daily date & festival reminders.",
                        settingsPath = "Settings → Apps → Special access → Battery optimization → Mornix"
                    )
                )
            )
            OemOsFamily.HONOR_MAGICOS -> OemSetupGuide(
                osFamily = osFamily,
                summaryNote = "Honor MagicOS supports Magic Capsule (灵动胶囊), floating banners, and lock screen cards when background launch is allowed.",
                steps = listOf(
                    OemSetupStep(
                        stepNumber = 1,
                        title = "Enable Banners, Lock Screen & Magic Capsule / Status Bar",
                        instruction = "Turn on Allow Notifications, Banners, Lock Screen, and Status Bar / Capsule indicators.",
                        settingsPath = "Settings → Notifications & status bar → Mornix"
                    ),
                    OemSetupStep(
                        stepNumber = 2,
                        title = "Set App Launch to Manual",
                        instruction = "Switch Mornix to Manual management with Auto-launch and Run in background enabled.",
                        settingsPath = "Settings → Battery → App launch → Mornix → Manage manually"
                    ),
                    OemSetupStep(
                        stepNumber = 3,
                        title = "Disable Battery Optimization",
                        instruction = "Allow Mornix to bypass aggressive standby restrictions.",
                        settingsPath = "Settings → Apps → Special access → Battery optimization → Mornix"
                    )
                )
            )
            OemOsFamily.SAMSUNG_ONEUI -> OemSetupGuide(
                osFamily = osFamily,
                summaryNote = "Samsung One UI supports Ongoing Status Chips, Lock Screen & Always-On Display cards, and pop-up reminders when Mornix is not placed in Deep Sleep.",
                steps = listOf(
                    OemSetupStep(
                        stepNumber = 1,
                        title = "Enable Lock Screen, Pop-up & Notification Categories",
                        instruction = "Ensure Lock screen notifications, Badge/Status bar icons, and Pop-up alerts are enabled.",
                        settingsPath = "Settings → Notifications → App notifications → Mornix"
                    ),
                    OemSetupStep(
                        stepNumber = 2,
                        title = "Set Battery to 'Unrestricted'",
                        instruction = "Prevent One UI from putting Mornix into 'Sleeping' or 'Deep sleeping' apps.",
                        settingsPath = "Settings → Apps → Mornix → Battery → Unrestricted"
                    ),
                    OemSetupStep(
                        stepNumber = 3,
                        title = "Enable Always-On Display (AOD) Notification Icons",
                        instruction = "View the Nepali date & weather notification icon directly on Samsung Always-On Display.",
                        settingsPath = "Settings → Lock screen and AOD → Always On Display"
                    )
                )
            )
            OemOsFamily.GOOGLE_PIXEL -> OemSetupGuide(
                osFamily = osFamily,
                summaryNote = "Google Pixel supports ongoing status bar chips, lock screen & Always-On Display visibility, and heads-up pop-up reminders natively.",
                steps = listOf(
                    OemSetupStep(
                        stepNumber = 1,
                        title = "Enable All Mornix Notification Channels",
                        instruction = "Keep 'Live Daily Status', 'Calendar Event Reminders', and 'Daily Morning Briefing' enabled.",
                        settingsPath = "Settings → Apps → See all apps → Mornix → Notifications"
                    ),
                    OemSetupStep(
                        stepNumber = 2,
                        title = "Show Content on Lock Screen",
                        instruction = "Allow sensitive/public notifications on the lock screen so BS Date & Weather are visible at a glance.",
                        settingsPath = "Settings → Notifications → Notifications on lock screen → Show conversations, default, and silent"
                    ),
                    OemSetupStep(
                        stepNumber = 3,
                        title = "Allow Background Battery Usage",
                        instruction = "Keep background usage enabled (Unrestricted recommended) for exact midnight BS date updates.",
                        settingsPath = "Settings → Apps → Mornix → App battery usage → Allow background usage"
                    )
                )
            )
            OemOsFamily.STANDARD_ANDROID -> OemSetupGuide(
                osFamily = osFamily,
                summaryNote = "Mornix uses standard Android ongoing and high-priority notification channels for maximum compatibility across all Android devices.",
                steps = listOf(
                    OemSetupStep(
                        stepNumber = 1,
                        title = "Allow Notifications & Lock Screen Display",
                        instruction = "Ensure Mornix notifications and lock screen visibility are enabled.",
                        settingsPath = "Settings → Apps → Mornix → Notifications"
                    ),
                    OemSetupStep(
                        stepNumber = 2,
                        title = "Enable Pop-up / Heads-Up for Reminders",
                        instruction = "Keep 'Calendar Event Reminders' and 'Daily Morning Briefing' channels set to High importance.",
                        settingsPath = "Settings → Apps → Mornix → Notifications → Notification categories"
                    ),
                    OemSetupStep(
                        stepNumber = 3,
                        title = "Set Battery Usage to Unrestricted",
                        instruction = "Disable battery optimization for Mornix so daily alarms and live weather updates are not delayed.",
                        settingsPath = "Settings → Apps → Mornix → Battery → Unrestricted"
                    )
                )
            )
        }
    }

    /**
     * Opens the app's system Notification Settings screen safely, falling back to App Info.
     */
    fun openAppNotificationSettings(context: Context) {
        try {
            val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                    putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            } else {
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.fromParts("package", context.packageName, null)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            openAppDetailsSettings(context)
        }
    }

    /**
     * Opens a specific notification channel's system settings screen (where users can toggle
     * Floating/Banner, Lock Screen, and Sound on MIUI/HyperOS/ColorOS/OriginOS/One UI).
     */
    fun openChannelNotificationSettings(context: Context, channelId: String) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val intent = Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS).apply {
                    putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                    putExtra(Settings.EXTRA_CHANNEL_ID, channelId)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return
            }
        } catch (_: Exception) {
        }
        openAppNotificationSettings(context)
    }

    /**
     * Opens Battery Optimization settings so the user can optionally exempt Mornix.
     * Does NOT automatically modify system settings.
     */
    fun openBatteryOptimizationSettings(context: Context) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return
            }
        } catch (_: Exception) {
        }
        openAppDetailsSettings(context)
    }

    /**
     * Attempts to open the manufacturer-specific Autostart / Background Startup manager if
     * available on the device, falling back cleanly to App Details settings.
     */
    fun openOemAutostartOrAppSettings(context: Context, osFamily: OemOsFamily = detectOemOsFamily()) {
        val candidateComponents = when (osFamily) {
            OemOsFamily.XIAOMI_HYPEROS, OemOsFamily.XIAOMI_MIUI -> listOf(
                ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"),
                ComponentName("com.miui.securitycenter", "com.miui.powercenter.PowerSettings")
            )
            OemOsFamily.OPPO_COLOROS, OemOsFamily.ONEPLUS_OXYGENOS -> listOf(
                ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"),
                ComponentName("com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity"),
                ComponentName("com.oneplus.security", "com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity")
            )
            OemOsFamily.VIVO_ORIGINOS, OemOsFamily.VIVO_FUNTOUCHOS -> listOf(
                ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity"),
                ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity")
            )
            OemOsFamily.HUAWEI_HARMONYOS, OemOsFamily.HUAWEI_EMUI -> listOf(
                ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
                ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.appcontrol.activity.StartupAppControlActivity")
            )
            OemOsFamily.HONOR_MAGICOS -> listOf(
                ComponentName("com.hihonor.systemmanager", "com.hihonor.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
                ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity")
            )
            OemOsFamily.SAMSUNG_ONEUI -> listOf(
                ComponentName("com.samsung.android.lool", "com.samsung.android.sm.battery.ui.BatteryActivity"),
                ComponentName("com.samsung.android.sm", "com.samsung.android.sm.battery.ui.BatteryActivity")
            )
            else -> emptyList()
        }

        for (component in candidateComponents) {
            try {
                val intent = Intent().apply {
                    this.component = component
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return
            } catch (_: Exception) {
            }
        }
        openAppDetailsSettings(context)
    }

    fun openAppDetailsSettings(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", context.packageName, null)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
        }
    }
}
