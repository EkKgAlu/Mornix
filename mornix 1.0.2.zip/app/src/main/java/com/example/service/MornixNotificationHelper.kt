package com.example.service

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.calendar.EnglishDate
import com.example.data.calendar.FestivalCategory
import com.example.data.calendar.HolidayScope
import com.example.data.calendar.NepaliDate
import com.example.data.calendar.NepaliDateConverter
import com.example.data.calendar.NepaliFestival
import com.example.data.calendar.NepaliFestivalData
import com.example.data.model.DisasterAlert
import com.example.data.model.FreshnessStatus
import com.example.data.model.MorningBriefing
import com.example.data.model.TemperatureUnit
import com.example.data.model.WeatherInfo
import java.text.SimpleDateFormat
import java.time.ZonedDateTime
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

data class LiveStatusNotificationContent(
    val title: String,
    val collapsedText: String,
    val expandedText: String,
    val dateLine: String?,
    val weatherLine: String?,
    val locationLine: String?,
    val statusChipText: String = "Mornix"
)

data class CalendarEventReminderContent(
    val title: String,
    val collapsedText: String,
    val expandedText: String,
    val bsDate: NepaliDate,
    val adDate: EnglishDate,
    val dateFormattedLine: String,
    val eventKeys: List<String>,
    val events: List<NepaliFestival>
)

object MornixNotificationHelper {

    const val CHANNEL_BRIEFING_ID = "mornix_morning_briefing_channel"
    const val CHANNEL_DISASTER_ID = "mornix_disaster_alerts_channel"
    const val CHANNEL_AUDIO_ID = "mornix_audio_playback_channel"
    const val CHANNEL_LIVE_STATUS_ID = "mornix_live_status_channel"
    const val CHANNEL_CALENDAR_REMINDER_ID = "mornix_calendar_reminder_channel"

    const val NOTIFICATION_BRIEFING_ID = 1001
    const val NOTIFICATION_DISASTER_BASE_ID = 2000
    const val NOTIFICATION_AUDIO_ID = 3001
    const val NOTIFICATION_LIVE_STATUS_ID = 4001
    const val NOTIFICATION_CALENDAR_REMINDER_ID = 5001

    const val PREF_NOTIFIED_CALENDAR_KEYS = "pref_notified_calendar_event_keys"

    const val EXTRA_OPEN_TAB = "com.example.mornix.EXTRA_OPEN_TAB"
    const val TAB_HOME = 0
    const val TAB_CALENDAR = 3
    const val TAB_WEATHER = 4

    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return

            // Channel 1: Morning Briefing
            val briefingChannel = NotificationChannel(
                CHANNEL_BRIEFING_ID,
                "Daily Morning Briefings",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Daily scheduled morning news, financial markets, and weather briefing"
                enableVibration(true)
                enableLights(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            // Channel 2: Disaster & Hazard Alerts
            val disasterChannel = NotificationChannel(
                CHANNEL_DISASTER_ID,
                "Emergency & Disaster Hazards",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Critical earthquake, seismic, and severe weather disaster advisories"
                enableVibration(true)
                enableLights(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            // Channel 3: Audio Playback
            val audioChannel = NotificationChannel(
                CHANNEL_AUDIO_ID,
                "Briefing Audio Playback",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Controls and status for reading morning briefings aloud"
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            // Channel 4: Persistent Live Status (Nepali Date & Weather)
            val liveStatusChannel = NotificationChannel(
                CHANNEL_LIVE_STATUS_ID,
                "Live Status Notification",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Persistent ongoing notification showing current Nepali date (BS) and local weather"
                enableVibration(false)
                setSound(null, null)
                setShowBadge(false)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            // Channel 5: Calendar Event Reminders (1 Day Before Upcoming Events)
            val calendarReminderChannel = NotificationChannel(
                CHANNEL_CALENDAR_REMINDER_ID,
                "Calendar Event Reminders",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Reminders sent one day before upcoming Nepali festivals, public holidays, and calendar events"
                enableVibration(true)
                enableLights(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            nm.createNotificationChannel(briefingChannel)
            nm.createNotificationChannel(disasterChannel)
            nm.createNotificationChannel(audioChannel)
            nm.createNotificationChannel(liveStatusChannel)
            nm.createNotificationChannel(calendarReminderChannel)
        }
    }

    fun getWeatherEmoji(weatherCode: Int): String {
        return when (weatherCode) {
            0 -> "☀️"
            1, 2 -> "🌤️"
            3 -> "☁️"
            45, 48 -> "🌫️"
            in 51..67, in 80..82 -> "🌧️"
            in 71..77, 85, 86 -> "❄️"
            in 95..99 -> "⛈️"
            else -> "🌤️"
        }
    }

    fun formatTemperature(tempC: Double, unit: TemperatureUnit): String {
        return if (unit == TemperatureUnit.FAHRENHEIT) {
            val tempF = (tempC * 9.0 / 5.0 + 32.0).roundToInt()
            "${tempF}°F"
        } else {
            "${tempC.roundToInt()}°C"
        }
    }

    /**
     * Pure, deterministic formatter for the Live Status Notification.
     * Returns null when both switches are OFF (meaning the notification must be cancelled).
     */
    fun buildLiveStatusContent(
        nepaliDateEnabled: Boolean,
        weatherEnabled: Boolean,
        weather: WeatherInfo?,
        tempUnit: TemperatureUnit = TemperatureUnit.CELSIUS,
        fallbackCity: String = "Kathmandu",
        bsDate: NepaliDate = NepaliDateConverter.todayBs()
    ): LiveStatusNotificationContent? {
        if (!nepaliDateEnabled && !weatherEnabled) {
            return null
        }

        val title = "Mornix • Daily Status"

        val dateLine = if (nepaliDateEnabled) {
            NepaliDateConverter.formatNepaliDateStatusLine(bsDate)
        } else {
            null
        }

        var weatherLine: String? = null
        var locationLine: String? = null

        if (weatherEnabled) {
            if (weather != null) {
                val emoji = getWeatherEmoji(weather.weatherCode)
                val currentTempStr = formatTemperature(weather.currentTempC, tempUnit)
                val feelsLikeStr = formatTemperature(weather.feelsLikeC, tempUnit)
                weatherLine = "$emoji $currentTempStr  |  Feels like $feelsLikeStr"

                val cleanCity = weather.cityName.trim()
                val baseLocation = if (cleanCity.contains(weather.country, ignoreCase = true)) {
                    cleanCity
                } else {
                    "$cleanCity, ${weather.country}"
                }

                locationLine = if (weather.freshnessStatus == FreshnessStatus.STALE && weather.retrievedAtMillis > 0L) {
                    val timeFmt = SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Date(weather.retrievedAtMillis))
                    "$baseLocation • Updated $timeFmt"
                } else {
                    baseLocation
                }
            } else {
                weatherLine = "🌤️ Weather unavailable  |  Tap Refresh"
                val cityDisplay = if (fallbackCity.equals("Current Location", ignoreCase = true)) {
                    "Nepal"
                } else if (fallbackCity.contains("Nepal", ignoreCase = true)) {
                    fallbackCity
                } else {
                    "$fallbackCity, Nepal"
                }
                locationLine = cityDisplay
            }
        }

        val collapsedText = when {
            dateLine != null && weatherLine != null -> "$dateLine  •  $weatherLine"
            dateLine != null -> dateLine
            weatherLine != null && locationLine != null -> "$weatherLine  •  $locationLine"
            weatherLine != null -> weatherLine
            else -> ""
        }

        val expandedLines = buildList {
            if (dateLine != null) add(dateLine)
            if (weatherLine != null) add(weatherLine)
            if (locationLine != null) add(locationLine)
        }

        val chipTempStr = if (weatherEnabled && weather != null) {
            formatTemperature(weather.currentTempC, tempUnit)
        } else {
            null
        }
        val bsDayNe = if (nepaliDateEnabled) {
            bsDate.dayNe
        } else {
            null
        }
        val bsMonthNe = if (nepaliDateEnabled) {
            bsDate.monthNameNe
        } else {
            null
        }
        val statusChipText = OemNotificationCompatibility.buildStatusChipSummary(
            nepaliDateEnabled = nepaliDateEnabled,
            weatherEnabled = weatherEnabled,
            bsDayNumber = bsDayNe,
            bsMonthShort = bsMonthNe,
            tempFormatted = chipTempStr
        )

        return LiveStatusNotificationContent(
            title = title,
            collapsedText = collapsedText,
            expandedText = expandedLines.joinToString("\n"),
            dateLine = dateLine,
            weatherLine = weatherLine,
            locationLine = locationLine,
            statusChipText = statusChipText
        )
    }

    fun updateOrCancelLiveStatusNotification(
        context: Context,
        nepaliDateEnabled: Boolean,
        weatherEnabled: Boolean,
        weather: WeatherInfo?,
        tempUnit: TemperatureUnit = TemperatureUnit.CELSIUS,
        fallbackCity: String = "Kathmandu"
    ) {
        createNotificationChannels(context)
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return

        val content = buildLiveStatusContent(
            nepaliDateEnabled = nepaliDateEnabled,
            weatherEnabled = weatherEnabled,
            weather = weather,
            tempUnit = tempUnit,
            fallbackCity = fallbackCity
        )

        if (content == null) {
            nm.cancel(NOTIFICATION_LIVE_STATUS_ID)
            cancelNepalMidnightUpdate(context)
            cancelPeriodicLiveWeatherRefresh(context)
            return
        }

        // Schedule or cancel background alarms based on individual switches
        if (nepaliDateEnabled) {
            scheduleNextNepalMidnightUpdate(context)
        } else {
            cancelNepalMidnightUpdate(context)
        }

        if (weatherEnabled) {
            schedulePeriodicLiveWeatherRefresh(context)
        } else {
            cancelPeriodicLiveWeatherRefresh(context)
        }

        // Default tap action: if only Calendar is on, open Calendar; if only Weather is on, open Weather; if both, open Home
        val defaultTab = when {
            nepaliDateEnabled && !weatherEnabled -> TAB_CALENDAR
            !nepaliDateEnabled && weatherEnabled -> TAB_WEATHER
            else -> TAB_HOME
        }

        val contentIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_OPEN_TAB, defaultTab)
        }
        val contentPendingIntent = PendingIntent.getActivity(
            context,
            401,
            contentIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_LIVE_STATUS_ID)
            .setSmallIcon(R.drawable.mornix_logo)
            .setContentTitle(content.title)
            .setContentText(content.collapsedText)
            .setStyle(NotificationCompat.BigTextStyle().bigText(content.expandedText))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setContentIntent(contentPendingIntent)

        OemNotificationCompatibility.applyLiveStatusOemCompatibility(
            builder = builder,
            chipSummary = content.statusChipText,
            primaryTitle = content.dateLine ?: content.title,
            secondarySummary = content.weatherLine ?: content.collapsedText
        )

        // Action 1: Open Nepali Calendar (if Nepali Date is enabled)
        if (nepaliDateEnabled) {
            val calendarIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra(EXTRA_OPEN_TAB, TAB_CALENDAR)
            }
            val calendarPendingIntent = PendingIntent.getActivity(
                context,
                402,
                calendarIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            builder.addAction(
                android.R.drawable.ic_menu_my_calendar,
                "Calendar",
                calendarPendingIntent
            )
        }

        // Action 2: Open Weather Details (if Weather is enabled)
        if (weatherEnabled) {
            val weatherIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra(EXTRA_OPEN_TAB, TAB_WEATHER)
            }
            val weatherPendingIntent = PendingIntent.getActivity(
                context,
                403,
                weatherIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            builder.addAction(
                android.R.drawable.ic_menu_compass,
                "Weather",
                weatherPendingIntent
            )
        }

        // Action 3: Manual Refresh
        val refreshIntent = Intent(context, MorningAlarmReceiver::class.java).apply {
            action = MorningAlarmReceiver.ACTION_LIVE_STATUS_REFRESH
        }
        val refreshPendingIntent = PendingIntent.getBroadcast(
            context,
            404,
            refreshIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        builder.addAction(
            android.R.drawable.ic_popup_sync,
            "Refresh",
            refreshPendingIntent
        )

        try {
            nm.notify(NOTIFICATION_LIVE_STATUS_ID, builder.build())
        } catch (_: SecurityException) {
            // Notification permission not granted yet
        }
    }

    fun scheduleNextNepalMidnightUpdate(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, MorningAlarmReceiver::class.java).apply {
            action = MorningAlarmReceiver.ACTION_MIDNIGHT_DATE_UPDATE
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            202,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Calculate next midnight + 5 seconds in Nepal Standard Time (Asia/Kathmandu)
        val nowNepal = ZonedDateTime.now(NepaliDateConverter.NEPAL_ZONE_ID)
        val nextMidnightNepal = nowNepal.toLocalDate()
            .plusDays(1)
            .atStartOfDay(NepaliDateConverter.NEPAL_ZONE_ID)
            .plusSeconds(5)
        val triggerAtMillis = nextMidnightNepal.toInstant().toEpochMilli()

        try {
            val canExact = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                alarmManager.canScheduleExactAlarms()
            } else {
                true
            }
            if (canExact) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerAtMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerAtMillis,
                    pendingIntent
                )
            }
        } catch (_: SecurityException) {
            alarmManager.setAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                triggerAtMillis,
                pendingIntent
            )
        }
    }

    fun cancelNepalMidnightUpdate(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, MorningAlarmReceiver::class.java).apply {
            action = MorningAlarmReceiver.ACTION_MIDNIGHT_DATE_UPDATE
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            202,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
    }

    fun schedulePeriodicLiveWeatherRefresh(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, MorningAlarmReceiver::class.java).apply {
            action = MorningAlarmReceiver.ACTION_LIVE_STATUS_REFRESH
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            203,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val triggerAtMillis = System.currentTimeMillis() + AlarmManager.INTERVAL_HALF_HOUR
        alarmManager.setInexactRepeating(
            AlarmManager.RTC,
            triggerAtMillis,
            AlarmManager.INTERVAL_HALF_HOUR,
            pendingIntent
        )
    }

    fun cancelPeriodicLiveWeatherRefresh(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, MorningAlarmReceiver::class.java).apply {
            action = MorningAlarmReceiver.ACTION_LIVE_STATUS_REFRESH
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            203,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
    }

    fun showMorningBriefingNotification(context: Context, briefing: MorningBriefing) {
        createNotificationChannels(context)

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return

        // 1. Content Intent: Open MainActivity
        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            context,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // 2. Action Intent: Listen to Briefing Audio
        val listenIntent = Intent(context, BriefingAudioService::class.java).apply {
            action = BriefingAudioService.ACTION_PLAY
            putExtra(BriefingAudioService.EXTRA_SCRIPT, briefing.spokenScript)
            putExtra(BriefingAudioService.EXTRA_TITLE, "Mornix Daily Briefing • ${briefing.formattedDate}")
        }
        val listenPendingIntent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            PendingIntent.getForegroundService(
                context,
                1,
                listenIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        } else {
            PendingIntent.getService(
                context,
                1,
                listenIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        val builder = NotificationCompat.Builder(context, CHANNEL_BRIEFING_ID)
            .setSmallIcon(R.drawable.mornix_logo)
            .setContentTitle("☀️ ${briefing.greeting} • Mornix Briefing")
            .setContentText(briefing.executiveSummary)
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText(
                        "${briefing.executiveSummary}\n\n" +
                                "📊 Gold & Forex: ${briefing.goldForexSnippet}\n" +
                                "🌦️ Weather: ${briefing.weatherSnippet}"
                    )
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOnlyAlertOnce(true)
            .setAutoCancel(true)
            .setContentIntent(openPendingIntent)
            .addAction(
                android.R.drawable.ic_media_play,
                "▶ Listen to Briefing",
                listenPendingIntent
            )
            .addAction(
                android.R.drawable.ic_menu_view,
                "Open Mornix",
                openPendingIntent
            )

        OemNotificationCompatibility.applyFloatingAlertOemCompatibility(
            builder = builder,
            category = NotificationCompat.CATEGORY_RECOMMENDATION,
            shortBannerTag = "Daily Briefing"
        )

        try {
            nm.notify(NOTIFICATION_BRIEFING_ID, builder.build())
        } catch (_: SecurityException) {
        }
    }

    fun showDisasterNotification(context: Context, alert: DisasterAlert) {
        createNotificationChannels(context)

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            context,
            alert.id.hashCode(),
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_DISASTER_ID)
            .setSmallIcon(R.drawable.mornix_logo)
            .setContentTitle("🚨 ${alert.severity}: ${alert.title}")
            .setContentText(alert.description)
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("${alert.description}\n\nLocation: ${alert.affectedLocation}\nAuthority: ${alert.issuingAuthority}\nTime: ${alert.pubDateFormatted}")
            )
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(openPendingIntent)

        OemNotificationCompatibility.applyFloatingAlertOemCompatibility(
            builder = builder,
            category = NotificationCompat.CATEGORY_ALARM,
            shortBannerTag = alert.severity
        )

        try {
            nm.notify(NOTIFICATION_DISASTER_BASE_ID + (alert.id.hashCode() % 1000), builder.build())
        } catch (_: SecurityException) {
        }
    }

    fun scheduleDailyBriefingAlarm(context: Context, hour: Int, minute: Int) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return

        val intent = Intent(context, MorningAlarmReceiver::class.java).apply {
            action = MorningAlarmReceiver.ACTION_MORNING_ALARM
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            201,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val calendar = Calendar.getInstance().apply {
            timeInMillis = System.currentTimeMillis()
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)

            // If selected time has already passed today, schedule for tomorrow
            if (timeInMillis <= System.currentTimeMillis()) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        try {
            val canExact = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                alarmManager.canScheduleExactAlarms()
            } else {
                true
            }
            if (canExact) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    calendar.timeInMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    calendar.timeInMillis,
                    pendingIntent
                )
            }
        } catch (_: SecurityException) {
            alarmManager.setInexactRepeating(
                AlarmManager.RTC_WAKEUP,
                calendar.timeInMillis,
                AlarmManager.INTERVAL_DAY,
                pendingIntent
            )
        }
    }

    fun cancelDailyBriefingAlarm(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, MorningAlarmReceiver::class.java).apply {
            action = MorningAlarmReceiver.ACTION_MORNING_ALARM
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            201,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
    }

    /**
     * Pure, deterministic formatter for Calendar Event Reminder notifications (1 day before an event).
     * Filters out any provisional/unverified events or events already notified for that date.
     * Supports single and multiple events occurring on the same day.
     */
    fun buildCalendarEventReminderContent(
        events: List<NepaliFestival>,
        bsDate: NepaliDate,
        adDate: EnglishDate = NepaliDateConverter.bsToAd(bsDate),
        alreadyNotifiedKeys: Set<String> = emptySet()
    ): CalendarEventReminderContent? {
        if (!NepaliDateConverter.isBsYearSupported(bsDate.year)) return null
        val maxDays = NepaliDateConverter.getDaysInBsMonth(bsDate.year, bsDate.month)
        if (bsDate.month !in 1..12 || bsDate.day !in 1..maxDays) return null

        val verifiedEvents = events
            .filter { ev ->
                !ev.isProvisional &&
                    ev.bsYear == bsDate.year &&
                    ev.bsMonth == bsDate.month &&
                    ev.bsDay == bsDate.day &&
                    ev.nameEn.isNotBlank() &&
                    "${bsDate.isoFormatted}:${ev.id}" !in alreadyNotifiedKeys
            }
            .distinctBy { it.id }

        if (verifiedEvents.isEmpty()) return null

        val dateFormattedLine = "${bsDate.formattedNe} (${bsDate.formattedEn}) • ${adDate.formatted}"
        val eventKeys = verifiedEvents.map { "${bsDate.isoFormatted}:${it.id}" }

        return if (verifiedEvents.size == 1) {
            val ev = verifiedEvents.first()
            val holidayBadge = if (ev.isPublicHoliday) " • Official Public Holiday" else ""
            val title = "📅 Tomorrow: ${ev.nameNe} (${ev.nameEn})"
            val collapsedText = "Happening tomorrow • ${bsDate.formattedNeCompact} (${adDate.formatted})"
            val expandedLines = buildList {
                add("Happening Tomorrow$holidayBadge")
                add("Event: ${ev.nameNe} (${ev.nameEn})")
                add("📅 Date: $dateFormattedLine")
                if (ev.description.isNotBlank()) {
                    add(ev.description)
                }
            }
            CalendarEventReminderContent(
                title = title,
                collapsedText = collapsedText,
                expandedText = expandedLines.joinToString("\n"),
                bsDate = bsDate,
                adDate = adDate,
                dateFormattedLine = dateFormattedLine,
                eventKeys = eventKeys,
                events = verifiedEvents
            )
        } else {
            val title = "📅 Tomorrow (${verifiedEvents.size} Events): ${verifiedEvents.joinToString(", ") { it.nameEn }}"
            val collapsedText = "Happening tomorrow (${bsDate.formattedNeCompact} • ${adDate.formatted}): " +
                verifiedEvents.joinToString(" & ") { "${it.nameNe} (${it.nameEn})" }
            val expandedLines = buildList {
                add("Happening Tomorrow • ${verifiedEvents.size} Calendar Events")
                add("📅 Date: $dateFormattedLine")
                verifiedEvents.forEach { ev ->
                    val tag = if (ev.isPublicHoliday) " [Public Holiday]" else ""
                    add("• ${ev.nameNe} (${ev.nameEn})$tag")
                }
            }
            CalendarEventReminderContent(
                title = title,
                collapsedText = collapsedText,
                expandedText = expandedLines.joinToString("\n"),
                bsDate = bsDate,
                adDate = adDate,
                dateFormattedLine = dateFormattedLine,
                eventKeys = eventKeys,
                events = verifiedEvents
            )
        }
    }

    /**
     * Collects all verified calendar events occurring tomorrow (1 day after todayAd in Asia/Kathmandu),
     * including festivals, public holidays, and any verified saved birthday in Mornix Calendar.
     */
    fun getTomorrowVerifiedCalendarEvents(
        sp: android.content.SharedPreferences? = null,
        todayAd: EnglishDate = NepaliDateConverter.todayAd(NepaliDateConverter.NEPAL_ZONE_ID)
    ): Triple<NepaliDate, EnglishDate, List<NepaliFestival>> {
        val (tomorrowBs, tomorrowAd, baseEvents) = NepaliFestivalData.getTomorrowVerifiedEvents(todayAd)
        val combined = baseEvents.toMutableList()

        if (sp != null) {
            try {
                val dobType = sp.getString("pref_dob_calendar_type", null)
                val dobY = sp.getInt("pref_dob_year", 0)
                val dobM = sp.getInt("pref_dob_month", 0)
                val dobD = sp.getInt("pref_dob_day", 0)
                if (dobType != null && dobY > 0 && dobM in 1..12 && dobD in 1..32) {
                    val ageRes = if (dobType == "BS") {
                        NepaliDateConverter.calculateAge(NepaliDate(dobY, dobM, dobD), todayAd)
                    } else {
                        NepaliDateConverter.calculateAge(EnglishDate(dobY, dobM, dobD), todayAd)
                    }
                    if (ageRes.nextBirthdayDays == 1L && ageRes.nextBirthdayBs == tomorrowBs) {
                        combined.add(
                            NepaliFestival(
                                id = "saved_birthday_${tomorrowBs.year}",
                                nameNe = "जन्मदिन",
                                nameEn = "Birthday Reminder",
                                bsYear = tomorrowBs.year,
                                bsMonth = tomorrowBs.month,
                                bsDay = tomorrowBs.day,
                                isPublicHoliday = false,
                                holidayScope = HolidayScope.NATIONWIDE,
                                category = FestivalCategory.CULTURAL_EVENT,
                                description = "Your saved birthday in Mornix Calendar is happening tomorrow.",
                                significance = "Personal Calendar Event",
                                isProvisional = false
                            )
                        )
                    }
                }
            } catch (_: Exception) {}
        }

        return Triple(tomorrowBs, tomorrowAd, combined.distinctBy { it.id })
    }

    /**
     * Calculates the next alarm trigger timestamp in milliseconds using Asia/Kathmandu local time.
     */
    fun calculateNextCalendarReminderMillis(
        nowNepal: ZonedDateTime = ZonedDateTime.now(NepaliDateConverter.NEPAL_ZONE_ID)
    ): Long {
        val todayMorningEightNepal = nowNepal.toLocalDate()
            .atTime(8, 0)
            .atZone(NepaliDateConverter.NEPAL_ZONE_ID)

        val nextEightAmNepal = if (nowNepal.isBefore(todayMorningEightNepal)) {
            todayMorningEightNepal
        } else {
            todayMorningEightNepal.plusDays(1)
        }

        val nextMidnightNepal = nowNepal.toLocalDate()
            .plusDays(1)
            .atStartOfDay(NepaliDateConverter.NEPAL_ZONE_ID)
            .plusSeconds(15)

        val earliestCheck = if (nextEightAmNepal.isBefore(nextMidnightNepal)) {
            nextEightAmNepal
        } else {
            nextMidnightNepal
        }

        return earliestCheck.toInstant().toEpochMilli()
    }

    fun scheduleNextCalendarEventReminderAlarm(
        context: Context,
        nowNepal: ZonedDateTime = ZonedDateTime.now(NepaliDateConverter.NEPAL_ZONE_ID)
    ) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, MorningAlarmReceiver::class.java).apply {
            action = MorningAlarmReceiver.ACTION_CALENDAR_EVENT_REMINDER
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            205,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val triggerAtMillis = calculateNextCalendarReminderMillis(nowNepal)

        try {
            val canExact = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                alarmManager.canScheduleExactAlarms()
            } else {
                true
            }
            if (canExact) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerAtMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerAtMillis,
                    pendingIntent
                )
            }
        } catch (_: SecurityException) {
            alarmManager.setAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                triggerAtMillis,
                pendingIntent
            )
        }
    }

    fun cancelCalendarEventReminderAlarm(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, MorningAlarmReceiver::class.java).apply {
            action = MorningAlarmReceiver.ACTION_CALENDAR_EVENT_REMINDER
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            205,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
    }

    fun showCalendarEventReminderNotification(
        context: Context,
        content: CalendarEventReminderContent
    ) {
        createNotificationChannels(context)
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return

        val openCalendarIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_OPEN_TAB, TAB_CALENDAR)
        }
        val openCalendarPendingIntent = PendingIntent.getActivity(
            context,
            501,
            openCalendarIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_CALENDAR_REMINDER_ID)
            .setSmallIcon(R.drawable.mornix_logo)
            .setContentTitle(content.title)
            .setContentText(content.collapsedText)
            .setStyle(NotificationCompat.BigTextStyle().bigText(content.expandedText))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setOnlyAlertOnce(true)
            .setAutoCancel(true)
            .setContentIntent(openCalendarPendingIntent)
            .addAction(
                android.R.drawable.ic_menu_my_calendar,
                "Open Calendar",
                openCalendarPendingIntent
            )

        OemNotificationCompatibility.applyFloatingAlertOemCompatibility(
            builder = builder,
            category = NotificationCompat.CATEGORY_REMINDER,
            shortBannerTag = "Tomorrow • ${content.bsDate.formattedNeCompact}"
        )

        try {
            nm.notify(NOTIFICATION_CALENDAR_REMINDER_ID, builder.build())
        } catch (_: SecurityException) {
            // Notification permission not granted yet
        }
    }

    /**
     * Synchronizes Calendar Event Reminders:
     * - If disabled: cancels scheduled reminder alarms and removes any active calendar reminder notification.
     * - If enabled: schedules the next reminder check in Asia/Kathmandu time zone, checks if any verified
     *   calendar events are happening tomorrow, and notifies once per event without duplicates.
     */
    fun syncCalendarEventReminders(
        context: Context,
        enabled: Boolean,
        todayAd: EnglishDate = NepaliDateConverter.todayAd(NepaliDateConverter.NEPAL_ZONE_ID)
    ) {
        createNotificationChannels(context)
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        val sp = context.getSharedPreferences("mornix_secure_prefs", Context.MODE_PRIVATE)

        if (!enabled) {
            cancelCalendarEventReminderAlarm(context)
            nm?.cancel(NOTIFICATION_CALENDAR_REMINDER_ID)
            return
        }

        // 1. Schedule next Asia/Kathmandu check alarm
        scheduleNextCalendarEventReminderAlarm(context)

        // 2. Check if there are verified calendar events happening tomorrow (1 day before event)
        val (tomorrowBs, tomorrowAd, tomorrowEvents) = getTomorrowVerifiedCalendarEvents(sp, todayAd)
        if (tomorrowEvents.isEmpty()) return

        val existingKeys = sp.getStringSet(PREF_NOTIFIED_CALENDAR_KEYS, emptySet()) ?: emptySet()
        // Keep only keys for tomorrowBs so outdated keys from past dates don't accumulate forever
        val currentRelevantKeys = existingKeys.filter { it.startsWith("${tomorrowBs.isoFormatted}:") }.toSet()

        val reminderContent = buildCalendarEventReminderContent(
            events = tomorrowEvents,
            bsDate = tomorrowBs,
            adDate = tomorrowAd,
            alreadyNotifiedKeys = currentRelevantKeys
        ) ?: return

        showCalendarEventReminderNotification(context, reminderContent)

        val updatedKeys = currentRelevantKeys + reminderContent.eventKeys
        sp.edit().putStringSet(PREF_NOTIFIED_CALENDAR_KEYS, updatedKeys).apply()
    }
}

