package com.example

import com.example.data.calendar.EnglishDate
import com.example.data.calendar.NepaliDate
import com.example.data.calendar.NepaliDateConverter
import com.example.data.local.toEntity
import com.example.data.model.UserPreferences
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class NepaliCalendarAndWidgetTest {

    @Test
    fun testBsToAdAnchorDate() {
        val bsDate = NepaliDate(2000, 1, 1)
        val adDate = NepaliDateConverter.bsToAd(bsDate)
        assertEquals(1943, adDate.year)
        assertEquals(4, adDate.month)
        assertEquals(14, adDate.day)
    }

    @Test
    fun testAdToBsAnchorDate() {
        val adDate = EnglishDate(1943, 4, 14)
        val bsDate = NepaliDateConverter.adToBs(adDate)
        assertEquals(2000, bsDate.year)
        assertEquals(1, bsDate.month)
        assertEquals(1, bsDate.day)
    }

    @Test
    fun testModernNepaliNewYears() {
        // 2081-01-01 BS = April 13, 2024 AD
        val bs2081 = NepaliDate(2081, 1, 1)
        val ad2081 = NepaliDateConverter.bsToAd(bs2081)
        assertEquals(2024, ad2081.year)
        assertEquals(4, ad2081.month)
        assertEquals(13, ad2081.day)

        val roundtripBs2081 = NepaliDateConverter.adToBs(ad2081)
        assertEquals(bs2081, roundtripBs2081)

        // 2080-01-01 BS = April 14, 2023 AD
        val bs2080 = NepaliDate(2080, 1, 1)
        val ad2080 = NepaliDateConverter.bsToAd(bs2080)
        assertEquals(2023, ad2080.year)
        assertEquals(4, ad2080.month)
        assertEquals(14, ad2080.day)

        val roundtripBs2080 = NepaliDateConverter.adToBs(ad2080)
        assertEquals(bs2080, roundtripBs2080)
    }

    @Test
    fun testRoundtripConversionsAcrossCenturies() {
        // Sample distinct years and months across the 100-year table
        val sampleYears = listOf(2001, 2015, 2030, 2050, 2065, 2080, 2095)
        for (year in sampleYears) {
            for (month in 1..12) {
                val maxDay = NepaliDateConverter.getDaysInBsMonth(year, month)
                val testDays = listOf(1, 15, maxDay)
                for (day in testDays) {
                    val originalBs = NepaliDate(year, month, day)
                    val convertedAd = NepaliDateConverter.bsToAd(originalBs)
                    val roundtripBs = NepaliDateConverter.adToBs(convertedAd)
                    assertEquals("Mismatch for $originalBs", originalBs, roundtripBs)
                }
            }
        }
    }

    @Test
    fun testAdToBsRoundtrip() {
        val sampleDates = listOf(
            EnglishDate(1950, 1, 1),
            EnglishDate(1975, 7, 20),
            EnglishDate(2000, 2, 29), // Leap year
            EnglishDate(2015, 12, 31),
            EnglishDate(2024, 2, 29), // Leap year
            EnglishDate(2026, 10, 31)
        )

        for (ad in sampleDates) {
            val bs = NepaliDateConverter.adToBs(ad)
            val roundtripAd = NepaliDateConverter.bsToAd(bs)
            assertEquals("Mismatch for AD date $ad", ad, roundtripAd)
        }
    }

    @Test
    fun testAgeCalculationExact() {
        val dobAd = EnglishDate(2000, 5, 10)
        val targetDate = EnglishDate(2025, 6, 15)

        val age = NepaliDateConverter.calculateAge(dobAd, targetDate)
        assertEquals(25, age.years)
        assertEquals(1, age.months)
        assertEquals(5, age.days)
        assertTrue(age.totalDays > 9000)
        assertEquals(25 * 12L + 1, age.totalMonths)
        assertEquals(age.totalDays / 7L, age.totalWeeks)
    }

    @Test
    fun testAgeCalculationFromBs() {
        val dobBs = NepaliDate(2055, 2, 10) // Jestha 10, 2055 BS
        val targetDate = EnglishDate(2026, 1, 1)

        val age = NepaliDateConverter.calculateAge(dobBs, targetDate)
        assertNotNull(age)
        assertTrue(age.years >= 27)
        assertTrue(age.totalDays > 0)
        assertTrue(age.nextBirthdayDays in 0..366)
    }

    @Test
    fun testNextBirthdayCountdown() {
        val dobAd = EnglishDate(1995, 10, 20)
        val targetDate = EnglishDate(2025, 10, 15) // 5 days before birthday

        val age = NepaliDateConverter.calculateAge(dobAd, targetDate)
        assertEquals(5L, age.nextBirthdayDays)
        assertEquals(2025, age.nextBirthdayAd.year)
        assertEquals(10, age.nextBirthdayAd.month)
        assertEquals(20, age.nextBirthdayAd.day)
    }

    @Test
    fun testMonthlyCalendarGridGeneration() {
        // Generate month for Baishakh 2081 BS
        val days = NepaliDateConverter.generateCalendarMonthBs(2081, 1)
        assertTrue(days.isNotEmpty())
        assertEquals(0, days.size % 7) // Multiple of 7 for complete grid weeks

        val currentMonthDays = days.filter { it.isCurrentMonth }
        val expectedLength = NepaliDateConverter.getDaysInBsMonth(2081, 1)
        assertEquals(expectedLength, currentMonthDays.size)

        // Ensure Saturday is marked as weekend in Nepal
        val saturdays = days.filter { it.isWeekend }
        assertTrue(saturdays.isNotEmpty())
    }

    @Test
    fun testUserPreferencesWidgetOrderAndDefaults() {
        val prefs = UserPreferences()

        // Crypto and Calendar MUST be disabled by default in enabledWidgets
        assertFalse(prefs.enabledWidgets.contains("crypto"))
        assertFalse(prefs.enabledWidgets.contains("calendar"))

        // Calendar should be in default widget order
        assertTrue(prefs.widgetOrder.contains("calendar"))
        assertTrue(prefs.widgetOrder.contains("crypto"))

        // Verify reordering: moving calendar up or down
        val initialOrder = prefs.widgetOrder
        val calendarIndex = initialOrder.indexOf("calendar")
        assertTrue(calendarIndex >= 0)

        // Move up
        if (calendarIndex > 0) {
            val movedUp = initialOrder.toMutableList()
            java.util.Collections.swap(movedUp, calendarIndex, calendarIndex - 1)
            assertEquals(initialOrder[calendarIndex], movedUp[calendarIndex - 1])
        }

        // Verify weather snapshot is the second widget in default widgetOrder
        assertEquals("briefing", prefs.widgetOrder[0])
        assertEquals("weather", prefs.widgetOrder[1])
    }

    @Test
    fun testExpandedMarketsAndCryptoCatalog() {
        val markets = com.example.data.remote.MarketsService().getDefaultMarkets()
        assertTrue(markets.size >= 25)

        val cryptos = markets.filter { it.category == "Crypto" }
        assertTrue("Expected 10+ cryptocurrencies", cryptos.size >= 10)
        assertTrue(cryptos.any { it.symbol == "BTC" })
        assertTrue(cryptos.any { it.symbol == "ETH" })
        assertTrue(cryptos.any { it.symbol == "SOL" })
        assertTrue(cryptos.any { it.symbol == "BNB" })
        assertTrue(cryptos.any { it.symbol == "DOGE" })

        val indices = markets.filter { it.category == "Index" }
        assertTrue("Expected 6+ global indices", indices.size >= 6)
        assertTrue(indices.any { it.symbol == "^GSPC" })
        assertTrue(indices.any { it.symbol == "^NDX" })
        assertTrue(indices.any { it.symbol == "^DJI" })
        assertTrue(indices.any { it.symbol == "^N225" })

        val commodities = markets.filter { it.category == "Commodity" }
        assertTrue("Expected 5+ commodities", commodities.size >= 5)
        assertTrue(commodities.any { it.symbol == "GC=F" })
        assertTrue(commodities.any { it.symbol == "SI=F" })
        assertTrue(commodities.any { it.symbol == "CL=F" })

        val forex = markets.filter { it.category == "Forex" }
        assertTrue("Expected 4+ forex pairs", forex.size >= 4)
        assertTrue(forex.any { it.symbol == "EURUSD=X" })
        assertTrue(forex.any { it.symbol == "USDJPY=X" })
    }

    @Test
    fun testNepaliFestivalsLookupAndAccuracy() {
        // Vijaya Dashami 2081 BS (Ashwin 27 / 2081-06-27)
        val dashami2081 = NepaliDate(2081, 6, 27)
        val dashamiFestivals = com.example.data.calendar.NepaliFestivalData.getFestivalsForBsDate(dashami2081)
        assertTrue(dashamiFestivals.isNotEmpty())
        val vijaya = dashamiFestivals.first { it.nameEn.contains("Vijaya Dashami", ignoreCase = true) }
        assertTrue("Vijaya Dashami must be an official public holiday", vijaya.isPublicHoliday)
        assertEquals(com.example.data.calendar.HolidayScope.NATIONWIDE, vijaya.holidayScope)

        // Bhai Tika 2081 BS (2081-07-18)
        val bhaiTika2081 = NepaliDate(2081, 7, 18)
        val tiharFestivals = com.example.data.calendar.NepaliFestivalData.getFestivalsForBsDate(bhaiTika2081)
        assertTrue(tiharFestivals.isNotEmpty())
        val bhaiTika = tiharFestivals.first { it.nameEn.contains("Bhai Tika", ignoreCase = true) }
        assertTrue(bhaiTika.isPublicHoliday)

        // Shivaratri 2081 BS (Falgun 14 / 2081-11-14)
        val shivaratri2081 = NepaliDate(2081, 11, 14)
        val shivaFestivals = com.example.data.calendar.NepaliFestivalData.getFestivalsForBsDate(shivaratri2081)
        assertTrue(shivaFestivals.isNotEmpty())
        assertTrue(shivaFestivals.any { it.nameEn.contains("Shivaratri", ignoreCase = true) && it.isPublicHoliday })

        // Buddha Jayanti 2081 BS (2081-02-10)
        val buddhaJayanti2081 = NepaliDate(2081, 2, 10)
        val buddhaFestivals = com.example.data.calendar.NepaliFestivalData.getFestivalsForBsDate(buddhaJayanti2081)
        assertTrue(buddhaFestivals.isNotEmpty())
        assertTrue(buddhaFestivals.any { it.nameEn.contains("Buddha Jayanti", ignoreCase = true) && it.isPublicHoliday })

        // Sambidhan Diwas (Constitution Day) 2081 BS (Ashwin 3 / 2081-06-03)
        val constDay = NepaliDate(2081, 6, 3)
        val constFestivals = com.example.data.calendar.NepaliFestivalData.getFestivalsForBsDate(constDay)
        assertTrue(constFestivals.any { it.nameEn.contains("Constitution Day", ignoreCase = true) && it.isPublicHoliday })
    }

    @Test
    fun testDistinctionBetweenFestivalAndOfficialPublicHoliday() {
        // Kag Tihar 2081 BS (2081-07-13) is a cultural festival, NOT an official government public holiday
        val kagTihar2081 = NepaliDate(2081, 7, 13)
        val kagFestivals = com.example.data.calendar.NepaliFestivalData.getFestivalsForBsDate(kagTihar2081)
        val kag = kagFestivals.firstOrNull { it.nameEn.contains("Kag Tihar", ignoreCase = true) }
        assertNotNull(kag)
        assertFalse("Kag Tihar is a cultural event, not a public holiday", kag!!.isPublicHoliday)

        // Laxmi Puja 2081 BS (2081-07-15) IS an official government public holiday
        val laxmiPuja2081 = NepaliDate(2081, 7, 15)
        val laxmiFestivals = com.example.data.calendar.NepaliFestivalData.getFestivalsForBsDate(laxmiPuja2081)
        val laxmi = laxmiFestivals.firstOrNull { it.nameEn.contains("Laxmi Puja", ignoreCase = true) }
        assertNotNull(laxmi)
        assertTrue("Laxmi Puja must be an official public holiday", laxmi!!.isPublicHoliday)
    }

    @Test
    fun testUpcomingFestivalsAndCountdown() {
        val testBaseDate = NepaliDate(2081, 5, 1) // Bhadra 1, 2081 BS
        val upcoming = com.example.data.calendar.NepaliFestivalData.getUpcomingFestivals(testBaseDate, limit = 10)
        assertTrue(upcoming.isNotEmpty())

        val upcomingHolidays = com.example.data.calendar.NepaliFestivalData.getUpcomingPublicHolidays(testBaseDate, limit = 10)
        assertTrue(upcomingHolidays.isNotEmpty())
        assertTrue("All returned public holidays must have isPublicHoliday == true", upcomingHolidays.all { it.isPublicHoliday })

        val nextMajor = com.example.data.calendar.NepaliFestivalData.getNextMajorFestival(testBaseDate)
        assertNotNull(nextMajor)
        assertTrue(nextMajor!!.second > 0)
    }

    @Test
    fun testRoomBriefingEntityOfflineCacheMappingAndUpcomingEventsPref() {
        val original = com.example.data.model.MorningBriefing(
            generatedAtMillis = 1730360000000L,
            formattedDate = "2026-10-31",
            greeting = "Good Morning, Nepal",
            executiveSummary = "Gold steady, clear skies in Kathmandu.",
            newsHighlights = listOf("Headline 1", "Headline 2"),
            goldForexSnippet = "Fine Gold NPR 165,000/tola",
            weatherSnippet = "22°C Sunny",
            alertsSnippet = "No severe alerts",
            spokenScript = "Good morning, here is your daily report.",
            isAiGenerated = true,
            bibleVerse = com.example.data.model.BibleVerse(
                reference = "Psalm 118:24",
                text = "This is the day the Lord has made.",
                translation = "NIV",
                theme = "Gratitude",
                dateFormatted = "2026-10-31"
            )
        )

        val entity = original.toEntity()
        assertEquals("2026-10-31", entity.dateKey)

        val restoredOffline = entity.toDomainModel(isOfflineCached = true)
        assertTrue(restoredOffline.isOfflineCached)
        assertEquals(original.executiveSummary, restoredOffline.executiveSummary)
        assertEquals(2, restoredOffline.newsHighlights.size)
        assertEquals("Psalm 118:24", restoredOffline.bibleVerse?.reference)

        val prefs = UserPreferences()
        assertTrue("Upcoming calendar events in briefing must be ON by default", prefs.showUpcomingEventsInBriefing)
        val toggledOff = prefs.copy(showUpcomingEventsInBriefing = false)
        assertFalse(toggledOff.showUpcomingEventsInBriefing)
    }

    @Test
    fun testLiveStatusNotificationFourStateMatrixAndFormatting() {
        val sampleBsDate = NepaliDate(2083, 7, 15) // 15 Kartik 2083 BS = Oct 31, 2026 AD (Saturday)
        assertEquals("१५ कात्तिक २०८३", sampleBsDate.formattedNeCompact)
        assertEquals("📅 १५ कात्तिक २०८३ (Saturday)", NepaliDateConverter.formatNepaliDateStatusLine(sampleBsDate))

        val sundayBsDate = NepaliDate(2083, 7, 16) // 16 Kartik 2083 BS = Nov 1, 2026 AD (Sunday)
        assertEquals("📅 १६ कात्तिक २०८३ (Sunday)", NepaliDateConverter.formatNepaliDateStatusLine(sundayBsDate))

        val sampleWeather = com.example.data.model.WeatherInfo(
            cityName = "Biratnagar",
            country = "Nepal",
            latitude = 26.4525,
            longitude = 87.2718,
            currentTempC = 28.0,
            feelsLikeC = 31.0,
            humidityPercent = 65,
            windSpeedKmh = 10.0,
            windDirection = "SE",
            precipitationMm = 0.0,
            rainProbability = 10,
            uvIndex = 6.0,
            aqi = 42,
            aqiStatus = "Good",
            weatherCode = 1,
            conditionDescription = "Mainly Clear",
            sunriseTime = "06:05 AM",
            sunsetTime = "05:25 PM",
            hourlyForecast = emptyList(),
            dailyForecast = emptyList()
        )

        // Case 1: ON / ON -> Show Nepali Date + Weather
        val bothOn = com.example.service.MornixNotificationHelper.buildLiveStatusContent(
            nepaliDateEnabled = true,
            weatherEnabled = true,
            weather = sampleWeather,
            tempUnit = com.example.data.model.TemperatureUnit.CELSIUS,
            fallbackCity = "Biratnagar",
            bsDate = sampleBsDate
        )
        assertNotNull(bothOn)
        assertEquals("Mornix • Daily Status", bothOn!!.title)
        assertEquals("📅 १५ कात्तिक २०८३ (Saturday)", bothOn.dateLine)
        assertEquals("🌤️ 28°C  |  Feels like 31°C", bothOn.weatherLine)
        assertEquals("Biratnagar, Nepal", bothOn.locationLine)
        assertTrue(bothOn.expandedText.contains("📅 १५ कात्तिक २०८३ (Saturday)"))
        assertTrue(bothOn.expandedText.contains("🌤️ 28°C  |  Feels like 31°C"))
        assertTrue(bothOn.expandedText.contains("Biratnagar, Nepal"))

        // Case 2: ON / OFF -> Show Nepali Date only
        val dateOnly = com.example.service.MornixNotificationHelper.buildLiveStatusContent(
            nepaliDateEnabled = true,
            weatherEnabled = false,
            weather = sampleWeather,
            bsDate = sampleBsDate
        )
        assertNotNull(dateOnly)
        assertEquals("📅 १५ कात्तिक २०८३ (Saturday)", dateOnly!!.dateLine)
        assertEquals(null, dateOnly.weatherLine)
        assertEquals(null, dateOnly.locationLine)
        assertEquals("📅 १५ कात्तिक २०८३ (Saturday)", dateOnly.expandedText)

        // Case 3: OFF / ON -> Show Weather only (also test Fahrenheit)
        val weatherOnlyF = com.example.service.MornixNotificationHelper.buildLiveStatusContent(
            nepaliDateEnabled = false,
            weatherEnabled = true,
            weather = sampleWeather,
            tempUnit = com.example.data.model.TemperatureUnit.FAHRENHEIT,
            bsDate = sampleBsDate
        )
        assertNotNull(weatherOnlyF)
        assertEquals(null, weatherOnlyF!!.dateLine)
        assertEquals("🌤️ 82°F  |  Feels like 88°F", weatherOnlyF.weatherLine)
        assertEquals("Biratnagar, Nepal", weatherOnlyF.locationLine)

        // Case 4: OFF / OFF -> Returns null so ongoing notification is cancelled completely
        val bothOff = com.example.service.MornixNotificationHelper.buildLiveStatusContent(
            nepaliDateEnabled = false,
            weatherEnabled = false,
            weather = sampleWeather,
            bsDate = sampleBsDate
        )
        assertEquals(null, bothOff)
    }

    @Test
    fun testOnboardingPreferencesAndBriefingDateFormatting() {
        // 1. Verify Morning Briefing Date line combines Nepali BS date (in Devanagari) + full English AD date
        val sampleBs = NepaliDate(2083, 7, 15)
        val sampleAd = NepaliDateConverter.bsToAd(sampleBs)
        val briefingDateLine = "${sampleBs.formattedNe} • ${sampleAd.formatted}"
        assertEquals("१५ कात्तिक २०८३ बि.सं. • October 31, 2026 AD", briefingDateLine)

        // 2. Verify First-Time Setup Onboarding defaults and transitions
        val initialPrefs = UserPreferences()
        assertFalse("Onboarding should be false on first launch", initialPrefs.hasCompletedOnboarding)

        val allCategories = com.example.ui.screens.ALL_MORNIX_NEWS_CATEGORIES
        assertEquals(12, allCategories.size)

        val completedPrefs = initialPrefs.copy(
            nepaliDateNotificationEnabled = false,
            weatherNotificationEnabled = false,
            dailyBibleVerseEnabled = true,
            selectedNewsCategories = allCategories,
            hasCompletedOnboarding = true
        )
        assertTrue(completedPrefs.hasCompletedOnboarding)
        assertFalse(completedPrefs.nepaliDateNotificationEnabled)
        assertFalse(completedPrefs.weatherNotificationEnabled)
        assertTrue(completedPrefs.dailyBibleVerseEnabled)
        assertEquals(12, completedPrefs.selectedNewsCategories.size)
    }

    @Test
    fun testDailyBriefingShareSummaryFormatting() {
        val sampleBs = NepaliDate(2083, 7, 15)
        val sampleAd = NepaliDateConverter.bsToAd(sampleBs)
        val briefing = com.example.data.model.MorningBriefing(
            generatedAtMillis = 1730360000000L,
            formattedDate = "Saturday, October 31, 2026",
            greeting = "Good Morning",
            executiveSummary = "Nepal gold rates hold steady while Kathmandu enjoys clear autumn skies.",
            newsHighlights = listOf(
                "NRB releases updated monetary policy review",
                "Hydropower exports reach seasonal high"
            ),
            goldForexSnippet = "Fine Gold NPR 165,200/tola",
            weatherSnippet = "Kathmandu 24°C, Clear",
            alertsSnippet = "No severe alerts",
            spokenScript = "Good morning.",
            isAiGenerated = true
        )

        val shareText = com.example.ui.screens.formatDailyBriefingShareText(
            briefing = briefing,
            bsDate = sampleBs,
            adDate = sampleAd
        )

        assertTrue(shareText.contains("Mornix Daily Briefing"))
        assertTrue(shareText.contains("१५ कात्तिक २०८३ बि.सं. • October 31, 2026 AD"))
        assertTrue(shareText.contains("Nepal gold rates hold steady"))
        assertTrue(shareText.contains("• NRB releases updated monetary policy review"))
        assertTrue(shareText.contains("• Hydropower exports reach seasonal high"))
        assertTrue(shareText.contains("Fine Gold NPR 165,200/tola"))
        assertTrue(shareText.contains("Kathmandu 24°C, Clear"))
        assertTrue(shareText.contains("Shared via Mornix"))
    }

    @Test
    fun testCalendarEventReminderNotificationAndIndependence() {
        val tomorrowBs = NepaliDate(2083, 7, 16)
        val tomorrowAd = NepaliDateConverter.bsToAd(tomorrowBs)

        val event1 = com.example.data.calendar.NepaliFestival(
            id = "tihar_laxmi_puja",
            nameEn = "Laxmi Puja",
            nameNe = "लक्ष्मी पूजा",
            bsYear = 2083,
            bsMonth = 7,
            bsDay = 16,
            isPublicHoliday = true,
            holidayScope = com.example.data.calendar.HolidayScope.NATIONWIDE,
            category = com.example.data.calendar.FestivalCategory.MAJOR_FESTIVAL,
            description = "Festival of lights honoring Goddess Laxmi",
            significance = "Worship of Goddess Laxmi",
            isProvisional = false
        )

        val event2 = com.example.data.calendar.NepaliFestival(
            id = "mahakavi_jayanti",
            nameEn = "Laxmi Prasad Devkota Jayanti",
            nameNe = "महाकवि देवकोटा जयन्ती",
            bsYear = 2083,
            bsMonth = 7,
            bsDay = 16,
            isPublicHoliday = false,
            holidayScope = com.example.data.calendar.HolidayScope.NATIONWIDE,
            category = com.example.data.calendar.FestivalCategory.CULTURAL_EVENT,
            description = "Birth anniversary of Mahakavi Laxmi Prasad Devkota",
            significance = "Literary observance",
            isProvisional = false
        )

        val provisionalEvent = com.example.data.calendar.NepaliFestival(
            id = "unverified_event",
            nameEn = "Unverified Local Fair",
            nameNe = "अप्रमाणित मेला",
            bsYear = 2083,
            bsMonth = 7,
            bsDay = 16,
            isPublicHoliday = false,
            holidayScope = com.example.data.calendar.HolidayScope.COMMUNITY_SPECIFIC,
            category = com.example.data.calendar.FestivalCategory.REGIONAL_HOLIDAY,
            description = "Provisional date",
            significance = "Local observance",
            isProvisional = true
        )

        // 1. Single verified event happening tomorrow
        val singleReminder = com.example.service.MornixNotificationHelper.buildCalendarEventReminderContent(
            events = listOf(event1),
            bsDate = tomorrowBs,
            adDate = tomorrowAd,
            alreadyNotifiedKeys = emptySet()
        )
        assertNotNull(singleReminder)
        assertTrue(singleReminder!!.title.contains("Tomorrow"))
        assertTrue(singleReminder.title.contains("Laxmi Puja"))
        assertTrue(singleReminder.collapsedText.contains("Happening tomorrow"))
        assertTrue(singleReminder.expandedText.contains("Happening Tomorrow"))
        assertTrue(singleReminder.expandedText.contains("Laxmi Puja"))
        assertTrue(singleReminder.expandedText.contains("16 Kartik 2083 BS"))
        assertTrue(singleReminder.expandedText.contains("November 1, 2026 AD"))
        assertEquals(listOf("2083-07-16:tihar_laxmi_puja"), singleReminder.eventKeys)

        // 2. Multiple verified events on the same day tomorrow (ignores provisional event)
        val multiReminder = com.example.service.MornixNotificationHelper.buildCalendarEventReminderContent(
            events = listOf(event1, event2, provisionalEvent),
            bsDate = tomorrowBs,
            adDate = tomorrowAd,
            alreadyNotifiedKeys = emptySet()
        )
        assertNotNull(multiReminder)
        assertTrue(multiReminder!!.title.contains("Tomorrow (2 Events)"))
        assertTrue(multiReminder.expandedText.contains("Happening Tomorrow • 2 Calendar Events"))
        assertTrue(multiReminder.expandedText.contains("Laxmi Puja"))
        assertTrue(multiReminder.expandedText.contains("Laxmi Prasad Devkota Jayanti"))
        assertFalse("Provisional/unverified events must not be included", multiReminder.expandedText.contains("Unverified Local Fair"))
        assertEquals(2, multiReminder.eventKeys.size)

        // 3. Avoid duplicate notifications if already notified
        val duplicateCheck = com.example.service.MornixNotificationHelper.buildCalendarEventReminderContent(
            events = listOf(event1, event2),
            bsDate = tomorrowBs,
            adDate = tomorrowAd,
            alreadyNotifiedKeys = multiReminder.eventKeys.toSet()
        )
        assertEquals(null, duplicateCheck)

        // 4. Rejects reminders when only unverified/provisional events exist
        val provisionalOnly = com.example.service.MornixNotificationHelper.buildCalendarEventReminderContent(
            events = listOf(provisionalEvent),
            bsDate = tomorrowBs,
            adDate = tomorrowAd,
            alreadyNotifiedKeys = emptySet()
        )
        assertEquals(null, provisionalOnly)

        // 5. Verify Nepal timezone (Asia/Kathmandu) scheduling calculation
        val nowNepal = java.time.ZonedDateTime.of(2026, 10, 31, 7, 30, 0, 0, NepaliDateConverter.NEPAL_ZONE_ID)
        val nextAlarm = com.example.service.MornixNotificationHelper.calculateNextCalendarReminderMillis(
            nowNepal = nowNepal
        )
        assertTrue("Scheduled reminder alarm must be in the future", nextAlarm > nowNepal.toInstant().toEpochMilli())

        // 6. Verify Calendar Event Reminder preference is independent of Live Status & Bible Verse
        val prefs = UserPreferences(
            nepaliDateNotificationEnabled = false,
            weatherNotificationEnabled = false,
            dailyBibleVerseEnabled = false,
            calendarEventReminderEnabled = true
        )
        assertTrue(prefs.calendarEventReminderEnabled)
        assertFalse(prefs.nepaliDateNotificationEnabled)
        assertFalse(prefs.weatherNotificationEnabled)
        assertFalse(prefs.dailyBibleVerseEnabled)
    }

    @Test
    fun testChineseAndroidOsNotificationCompatibilityAndGuides() {
        // 1. Xiaomi / Redmi / POCO - HyperOS vs MIUI detection
        val hyperOs = com.example.service.OemNotificationCompatibility.detectOemOsFamily(
            manufacturer = "Xiaomi",
            brand = "Redmi",
            display = "UKQ1.230804.001.OS1.0.4.0.UNACNXM",
            sdkInt = 34,
            systemProps = mapOf("ro.mi.os.version.name" to "OS1.0")
        )
        assertEquals(com.example.service.OemOsFamily.XIAOMI_HYPEROS, hyperOs)

        val miui = com.example.service.OemNotificationCompatibility.detectOemOsFamily(
            manufacturer = "Xiaomi",
            brand = "POCO",
            display = "TKQ1.221114.001",
            sdkInt = 33,
            systemProps = mapOf("ro.miui.ui.version.name" to "V140")
        )
        assertEquals(com.example.service.OemOsFamily.XIAOMI_MIUI, miui)

        // 2. OPPO ColorOS & OnePlus OxygenOS detection
        val colorOs = com.example.service.OemNotificationCompatibility.detectOemOsFamily(
            manufacturer = "OPPO",
            brand = "OPPO",
            display = "CPH2581_14.0.0",
            sdkInt = 34,
            systemProps = emptyMap()
        )
        assertEquals(com.example.service.OemOsFamily.OPPO_COLOROS, colorOs)

        val oxygenOs = com.example.service.OemNotificationCompatibility.detectOemOsFamily(
            manufacturer = "OnePlus",
            brand = "OnePlus",
            display = "CPH2449_14.0",
            sdkInt = 34,
            systemProps = emptyMap()
        )
        assertEquals(com.example.service.OemOsFamily.ONEPLUS_OXYGENOS, oxygenOs)

        // 3. Vivo / iQOO - OriginOS vs Funtouch OS detection
        val originOs = com.example.service.OemNotificationCompatibility.detectOemOsFamily(
            manufacturer = "vivo",
            brand = "iQOO",
            display = "PD2324_A_14.0",
            sdkInt = 34,
            systemProps = mapOf("ro.vivo.os.name" to "OriginOS 4")
        )
        assertEquals(com.example.service.OemOsFamily.VIVO_ORIGINOS, originOs)

        val funtouchOs = com.example.service.OemNotificationCompatibility.detectOemOsFamily(
            manufacturer = "vivo",
            brand = "vivo",
            display = "PD2281F_EX_A_14.1",
            sdkInt = 34,
            systemProps = mapOf("ro.vivo.os.name" to "Funtouch OS 14")
        )
        assertEquals(com.example.service.OemOsFamily.VIVO_FUNTOUCHOS, funtouchOs)

        // 4. Huawei - HarmonyOS vs EMUI & Honor MagicOS detection
        val harmonyOs = com.example.service.OemNotificationCompatibility.detectOemOsFamily(
            manufacturer = "HUAWEI",
            brand = "HUAWEI",
            display = "ALN-AL00 4.0.0",
            sdkInt = 31,
            systemProps = mapOf("hw_sc.build.platform.version" to "4.0.0")
        )
        assertEquals(com.example.service.OemOsFamily.HUAWEI_HARMONYOS, harmonyOs)

        val emui = com.example.service.OemNotificationCompatibility.detectOemOsFamily(
            manufacturer = "HUAWEI",
            brand = "HUAWEI",
            display = "ELS-NX9 12.0.0",
            sdkInt = 29,
            systemProps = emptyMap()
        )
        assertEquals(com.example.service.OemOsFamily.HUAWEI_EMUI, emui)

        val magicOs = com.example.service.OemNotificationCompatibility.detectOemOsFamily(
            manufacturer = "HONOR",
            brand = "HONOR",
            display = "BVL-AN16 8.0.0",
            sdkInt = 34,
            systemProps = mapOf("ro.magic.api.version" to "35")
        )
        assertEquals(com.example.service.OemOsFamily.HONOR_MAGICOS, magicOs)

        // 5. Samsung One UI, Google Pixel, and Standard Android detection
        val oneUi = com.example.service.OemNotificationCompatibility.detectOemOsFamily(
            manufacturer = "samsung",
            brand = "samsung",
            display = "UP1A.231005.007",
            sdkInt = 34,
            systemProps = emptyMap()
        )
        assertEquals(com.example.service.OemOsFamily.SAMSUNG_ONEUI, oneUi)

        val pixel = com.example.service.OemNotificationCompatibility.detectOemOsFamily(
            manufacturer = "Google",
            brand = "google",
            display = "AP2A.240805.005",
            sdkInt = 35,
            systemProps = emptyMap()
        )
        assertEquals(com.example.service.OemOsFamily.GOOGLE_PIXEL, pixel)

        val standard = com.example.service.OemNotificationCompatibility.detectOemOsFamily(
            manufacturer = "Motorola",
            brand = "motorola",
            display = "U1TZS34",
            sdkInt = 34,
            systemProps = emptyMap()
        )
        assertEquals(com.example.service.OemOsFamily.STANDARD_ANDROID, standard)

        // 6. Status Chip / Dynamic Island Pill summary formatting
        val sampleWeather = com.example.data.model.WeatherInfo(
            cityName = "Biratnagar",
            country = "Nepal",
            latitude = 26.45,
            longitude = 87.27,
            currentTempC = 28.0,
            feelsLikeC = 31.0,
            humidityPercent = 65,
            windSpeedKmh = 10.0,
            windDirection = "E",
            precipitationMm = 0.0,
            rainProbability = 10,
            uvIndex = 6.0,
            aqi = 42,
            aqiStatus = "Good",
            weatherCode = 1,
            conditionDescription = "Partly Cloudy",
            sunriseTime = "06:00 AM",
            sunsetTime = "05:30 PM",
            hourlyForecast = emptyList(),
            dailyForecast = emptyList(),
            freshnessStatus = com.example.data.model.FreshnessStatus.LIVE,
            retrievedAtMillis = 1730000000000L
        )
        val liveContent = com.example.service.MornixNotificationHelper.buildLiveStatusContent(
            nepaliDateEnabled = true,
            weatherEnabled = true,
            weather = sampleWeather,
            tempUnit = com.example.data.model.TemperatureUnit.CELSIUS,
            fallbackCity = "Biratnagar",
            bsDate = NepaliDate(2083, 7, 15)
        )
        assertNotNull(liveContent)
        assertEquals("28°C • १५", liveContent!!.statusChipText)

        // 7. Verify every OemOsFamily has a complete 3-step setup guide
        for (family in com.example.service.OemOsFamily.entries) {
            val guide = com.example.service.OemNotificationCompatibility.getSetupGuideForOs(family)
            assertEquals(family, guide.osFamily)
            assertTrue(guide.summaryNote.isNotBlank())
            assertEquals(3, guide.steps.size)
            guide.steps.forEach { step ->
                assertTrue(step.title.isNotBlank())
                assertTrue(step.instruction.isNotBlank())
                assertTrue(step.settingsPath.isNotBlank())
            }
        }
    }
}





